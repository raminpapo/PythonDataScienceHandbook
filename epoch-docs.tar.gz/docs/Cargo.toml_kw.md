# Keywords: Cargo.toml

## Extracted Keywords

Total keywords extracted: 52


### A

- **anyhow**: Identifier found in `Cargo.toml`
- **apache**: Identifier found in `Cargo.toml`
- **assert_cmd**: Identifier found in `Cargo.toml`
- **authors**: Identifier found in `Cargo.toml`

### B

- **bin**: Identifier found in `Cargo.toml`

### C

- **categories**: Identifier found in `Cargo.toml`
- **category_slugs**: Identifier found in `Cargo.toml`
- **chrono**: Identifier found in `Cargo.toml`
- **clap**: Identifier found in `Cargo.toml`
- **cli**: Identifier found in `Cargo.toml`
- **com**: Identifier found in `Cargo.toml`
- **command**: Identifier found in `Cargo.toml`
- **converting**: Identifier found in `Cargo.toml`
- **crates**: Identifier found in `Cargo.toml`

### D

- **databento**: Identifier found in `Cargo.toml`
- **date**: Identifier found in `Cargo.toml`
- **dependencies**: Identifier found in `Cargo.toml`
- **derive**: Identifier found in `Cargo.toml`
- **description**: Identifier found in `Cargo.toml`
- **dev**: Identifier found in `Cargo.toml`

### E

- **edition**: Identifier found in `Cargo.toml`
- **epoch**: Identifier found in `Cargo.toml`

### F

- **features**: Identifier found in `Cargo.toml`
- **formatting**: Identifier found in `Cargo.toml`

### G

- **github**: Identifier found in `Cargo.toml`

### H

- **https**: Identifier found in `Cargo.toml`
- **human**: Identifier found in `Cargo.toml`

### I

- **integration**: Identifier found in `Cargo.toml`

### K

- **keywords**: Identifier found in `Cargo.toml`

### L

- **license**: Identifier found in `Cargo.toml`
- **line**: Identifier found in `Cargo.toml`

### M

- **main**: Identifier found in `Cargo.toml`
- **maximum**: Identifier found in `Cargo.toml`

### N

- **name**: Identifier found in `Cargo.toml`

### P

- **package**: Identifier found in `Cargo.toml`
- **path**: Identifier found in `Cargo.toml`
- **predicates**: Identifier found in `Cargo.toml`

### R

- **readable**: Identifier found in `Cargo.toml`
- **repository**: Identifier found in `Cargo.toml`
- **rstest**: Identifier found in `Cargo.toml`

### S

- **src**: Identifier found in `Cargo.toml`
- **strings**: Identifier found in `Cargo.toml`
- **support**: Identifier found in `Cargo.toml`

### T

- **tests**: Identifier found in `Cargo.toml`
- **time**: Identifier found in `Cargo.toml`
- **timestamps**: Identifier found in `Cargo.toml`
- **tool**: Identifier found in `Cargo.toml`

### U

- **unix**: Identifier found in `Cargo.toml`
- **utilities**: Identifier found in `Cargo.toml`

### V

- **value**: Identifier found in `Cargo.toml`
- **version**: Identifier found in `Cargo.toml`

### W

- **wrap_help**: Identifier found in `Cargo.toml`
