# Documentation: src

## Folder Overview

**Path**: `src`
**Files**: 1
**Subdirectories**: 0

## Purpose

This folder is located at `src`.

## Contents Summary


### Files:
- `main.rs` (6183 bytes)
