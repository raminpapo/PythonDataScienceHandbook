# Keywords: main.rs

## Extracted Keywords

Total keywords extracted: 171


### A

- **Args**: Identifier found in `src/main.rs`
- **about**: Identifier found in `src/main.rs`
- **abs**: Identifier found in `src/main.rs`
- **after**: Identifier found in `src/main.rs`
- **and_then**: Identifier found in `src/main.rs`
- **anyhow**: Identifier found in `src/main.rs`
- **approximate**: Identifier found in `src/main.rs`
- **arg**: Identifier found in `src/main.rs`
- **args**: Identifier found in `src/main.rs`
- **arguments**: Identifier found in `src/main.rs`
- **as_bytes**: Identifier found in `src/main.rs`

### B

- **bool**: Identifier found in `src/main.rs`
- **bound**: Identifier found in `src/main.rs`
- **bound_ms**: Identifier found in `src/main.rs`
- **bound_ns**: Identifier found in `src/main.rs`
- **bound_s**: Identifier found in `src/main.rs`
- **box**: Identifier found in `src/main.rs`
- **break**: Identifier found in `src/main.rs`
- **bufread**: Identifier found in `src/main.rs`
- **bufreader**: Identifier found in `src/main.rs`
- **bufwriter**: Identifier found in `src/main.rs`

### C

- **char**: Identifier found in `src/main.rs`
- **char_indices**: Identifier found in `src/main.rs`
- **character**: Identifier found in `src/main.rs`
- **chrono**: Identifier found in `src/main.rs`
- **clap**: Identifier found in `src/main.rs`
- **command**: Identifier found in `src/main.rs`
- **const**: Identifier found in `src/main.rs`
- **contains**: Identifier found in `src/main.rs`
- **continue**: Identifier found in `src/main.rs`
- **convert**: Identifier found in `src/main.rs`
- **create**: Identifier found in `src/main.rs`

### D

- **dates**: Identifier found in `src/main.rs`
- **datetime**: Identifier found in `src/main.rs`
- **days**: Identifier found in `src/main.rs`
- **debug**: Identifier found in `src/main.rs`
- **default_value_t**: Identifier found in `src/main.rs`
- **derive**: Identifier found in `src/main.rs`
- **detecting**: Identifier found in `src/main.rs`
- **duration**: Identifier found in `src/main.rs`
- **dyn**: Identifier found in `src/main.rs`

### E

- **else**: Identifier found in `src/main.rs`

### F

- **false**: Identifier found in `src/main.rs`
- **file**: Identifier found in `src/main.rs`
- **find**: Identifier found in `src/main.rs`
- **first**: Identifier found in `src/main.rs`
- **flush**: Identifier found in `src/main.rs`
- **format**: Identifier found in `src/main.rs`
- **formatted**: Identifier found in `src/main.rs`
- **found**: Identifier found in `src/main.rs`
- **from**: Identifier found in `src/main.rs`

### G

- **generous**: Identifier found in `src/main.rs`

### H

- **here**: Identifier found in `src/main.rs`
- **heuristic**: Identifier found in `src/main.rs`

### I

- **i32**: Identifier found in `src/main.rs`
- **i64**: Identifier found in `src/main.rs`
- **impl**: Identifier found in `src/main.rs`
- **index**: Identifier found in `src/main.rs`
- **input**: Identifier found in `src/main.rs`
- **input_file**: Identifier found in `src/main.rs`
- **instead**: Identifier found in `src/main.rs`
- **isn**: Identifier found in `src/main.rs`

### K

- **know**: Identifier found in `src/main.rs`

### L

- **LOCALIZE**: Identifier found in `src/main.rs`
- **last**: Identifier found in `src/main.rs`
- **len**: Identifier found in `src/main.rs`
- **length**: Identifier found in `src/main.rs`
- **less**: Identifier found in `src/main.rs`
- **line**: Identifier found in `src/main.rs`
- **lines**: Identifier found in `src/main.rs`
- **local**: Identifier found in `src/main.rs`
- **localize**: Identifier found in `src/main.rs`
- **lock**: Identifier found in `src/main.rs`
- **long**: Identifier found in `src/main.rs`
- **lower**: Identifier found in `src/main.rs`
- **lower_s**: Identifier found in `src/main.rs`

### M

- **main**: Identifier found in `src/main.rs`
- **map**: Identifier found in `src/main.rs`
- **match**: Identifier found in `src/main.rs`
- **millis**: Identifier found in `src/main.rs`
- **min**: Identifier found in `src/main.rs`
- **min_len**: Identifier found in `src/main.rs`
- **mut**: Identifier found in `src/main.rs`

### N

- **NUMBERS**: Identifier found in `src/main.rs`
- **nanos**: Identifier found in `src/main.rs`
- **non**: Identifier found in `src/main.rs`
- **none**: Identifier found in `src/main.rs`
- **number**: Identifier found in `src/main.rs`
- **number_end**: Identifier found in `src/main.rs`
- **number_start**: Identifier found in `src/main.rs`
- **numbers**: Identifier found in `src/main.rs`

### O

- **offset**: Identifier found in `src/main.rs`
- **omit**: Identifier found in `src/main.rs`
- **only**: Identifier found in `src/main.rs`
- **open**: Identifier found in `src/main.rs`
- **ops**: Identifier found in `src/main.rs`
- **option**: Identifier found in `src/main.rs`
- **otherwise**: Identifier found in `src/main.rs`
- **output**: Identifier found in `src/main.rs`

### P

- **parse**: Identifier found in `src/main.rs`
- **parse_result**: Identifier found in `src/main.rs`
- **parser**: Identifier found in `src/main.rs`
- **parsing**: Identifier found in `src/main.rs`
- **path**: Identifier found in `src/main.rs`
- **pathbuf**: Identifier found in `src/main.rs`
- **peek**: Identifier found in `src/main.rs`
- **peekable**: Identifier found in `src/main.rs`
- **plus**: Identifier found in `src/main.rs`
- **print**: Identifier found in `src/main.rs`
- **provided**: Identifier found in `src/main.rs`

### Q

- **quote**: Identifier found in `src/main.rs`

### R

- **Reformatter**: Identifier found in `src/main.rs`
- **range**: Identifier found in `src/main.rs`
- **rangeinclusive**: Identifier found in `src/main.rs`
- **read**: Identifier found in `src/main.rs`
- **reading**: Identifier found in `src/main.rs`
- **reformatter**: Identifier found in `src/main.rs`
- **rest**: Identifier found in `src/main.rs`
- **result**: Identifier found in `src/main.rs`
- **rfc_format**: Identifier found in `src/main.rs`

### S

- **STDIN**: Identifier found in `src/main.rs`
- **Some**: Identifier found in `src/main.rs`
- **sec_fmt**: Identifier found in `src/main.rs`
- **second**: Identifier found in `src/main.rs`
- **secondsformat**: Identifier found in `src/main.rs`
- **secs**: Identifier found in `src/main.rs`
- **self**: Identifier found in `src/main.rs`
- **short**: Identifier found in `src/main.rs`
- **skip**: Identifier found in `src/main.rs`
- **some**: Identifier found in `src/main.rs`
- **split_last**: Identifier found in `src/main.rs`
- **static**: Identifier found in `src/main.rs`
- **std**: Identifier found in `src/main.rs`
- **stdin**: Identifier found in `src/main.rs`
- **stdout**: Identifier found in `src/main.rs`
- **str**: Identifier found in `src/main.rs`
- **string**: Identifier found in `src/main.rs`
- **strings**: Identifier found in `src/main.rs`
- **struct**: Identifier found in `src/main.rs`

### T

- **text**: Identifier found in `src/main.rs`
- **text_after**: Identifier found in `src/main.rs`
- **text_before**: Identifier found in `src/main.rs`
- **text_iter**: Identifier found in `src/main.rs`
- **text_start**: Identifier found in `src/main.rs`
- **than**: Identifier found in `src/main.rs`
- **that**: Identifier found in `src/main.rs`
- **this**: Identifier found in `src/main.rs`
- **threshold**: Identifier found in `src/main.rs`
- **threshold_years**: Identifier found in `src/main.rs`
- **time**: Identifier found in `src/main.rs`
- **time_ns**: Identifier found in `src/main.rs`
- **timestamp**: Identifier found in `src/main.rs`
- **timestamp_nanos**: Identifier found in `src/main.rs`
- **timestamps**: Identifier found in `src/main.rs`
- **timezone**: Identifier found in `src/main.rs`
- **true**: Identifier found in `src/main.rs`

### U

- **unwrap_or_else**: Identifier found in `src/main.rs`
- **upper_s**: Identifier found in `src/main.rs`
- **used**: Identifier found in `src/main.rs`
- **usize**: Identifier found in `src/main.rs`
- **utc**: Identifier found in `src/main.rs`

### V

- **value_name**: Identifier found in `src/main.rs`
- **vec**: Identifier found in `src/main.rs`
- **version**: Identifier found in `src/main.rs`

### W

- **while**: Identifier found in `src/main.rs`
- **with**: Identifier found in `src/main.rs`
- **write**: Identifier found in `src/main.rs`
- **write_all**: Identifier found in `src/main.rs`
- **writer**: Identifier found in `src/main.rs`
- **writing**: Identifier found in `src/main.rs`

### Y

- **years**: Identifier found in `src/main.rs`
