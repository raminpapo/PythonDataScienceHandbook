# Keywords: build.sh

## Extracted Keywords

Total keywords extracted: 10


### B

- **bash**: Identifier found in `scripts/build.sh`
- **bin**: Identifier found in `scripts/build.sh`
- **build**: Identifier found in `scripts/build.sh`

### C

- **cargo**: Identifier found in `scripts/build.sh`

### E

- **echo**: Identifier found in `scripts/build.sh`
- **env**: Identifier found in `scripts/build.sh`

### F

- **features**: Identifier found in `scripts/build.sh`

### S

- **set**: Identifier found in `scripts/build.sh`

### U

- **usr**: Identifier found in `scripts/build.sh`

### V

- **version**: Identifier found in `scripts/build.sh`
