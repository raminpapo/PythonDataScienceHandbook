# Keywords: lint.sh

## Extracted Keywords

Total keywords extracted: 11


### B

- **bash**: Identifier found in `scripts/lint.sh`
- **bin**: Identifier found in `scripts/lint.sh`

### C

- **cargo**: Identifier found in `scripts/lint.sh`
- **clippy**: Identifier found in `scripts/lint.sh`

### D

- **deny**: Identifier found in `scripts/lint.sh`

### E

- **env**: Identifier found in `scripts/lint.sh`

### F

- **features**: Identifier found in `scripts/lint.sh`

### S

- **set**: Identifier found in `scripts/lint.sh`

### U

- **usr**: Identifier found in `scripts/lint.sh`

### V

- **version**: Identifier found in `scripts/lint.sh`

### W

- **warnings**: Identifier found in `scripts/lint.sh`
