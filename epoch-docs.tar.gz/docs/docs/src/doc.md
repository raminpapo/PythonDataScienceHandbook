# Documentation: docs/src

## Folder Overview

**Path**: `docs/src`
**Files**: 2
**Subdirectories**: 0

## Purpose

This folder is located at `docs/src`.

## Contents Summary


### Files:
- `main.rs_docs.md` (6946 bytes)
- `main.rs_kw.md` (8507 bytes)
