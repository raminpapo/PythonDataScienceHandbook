# Index: docs

## Contents

### Subdirectories

- [docs/](./docs/index.md)
- [scripts/](./scripts/index.md)
- [src/](./src/index.md)
- [tests/](./tests/index.md)

### Files

- [CHANGELOG.md_docs.md](./CHANGELOG.md_docs.md_docs.md)
- [CHANGELOG.md_kw.md](./CHANGELOG.md_kw.md_docs.md)
- [CODE_OF_CONDUCT.md_docs.md](./CODE_OF_CONDUCT.md_docs.md_docs.md)
- [CODE_OF_CONDUCT.md_kw.md](./CODE_OF_CONDUCT.md_kw.md_docs.md)
- [CONTRIBUTING.md_docs.md](./CONTRIBUTING.md_docs.md_docs.md)
- [CONTRIBUTING.md_kw.md](./CONTRIBUTING.md_kw.md_docs.md)
- [Cargo.toml_docs.md](./Cargo.toml_docs.md_docs.md)
- [Cargo.toml_kw.md](./Cargo.toml_kw.md_docs.md)
- [LICENSE_docs.md](./LICENSE_docs.md_docs.md)
- [LICENSE_kw.md](./LICENSE_kw.md_docs.md)
- [README.md_docs.md](./README.md_docs.md_docs.md)
- [README.md_kw.md](./README.md_kw.md_docs.md)
- [doc.md](./doc.md_docs.md)
- [index.md](./index.md_docs.md)
- [repo_book_gen.py_docs.md](./repo_book_gen.py_docs.md_docs.md)
- [repo_book_gen.py_kw.md](./repo_book_gen.py_kw.md_docs.md)
- [sub.md](./sub.md_docs.md)
