# Documentation: docs

## Folder Overview

**Path**: `docs`
**Files**: 17
**Subdirectories**: 4

## Purpose

This folder is located at `docs`.

## Contents Summary

### Subdirectories:
- `docs/`
- `scripts/`
- `src/`
- `tests/`

### Files:
- `CHANGELOG.md_docs.md` (864 bytes)
- `CHANGELOG.md_kw.md` (311 bytes)
- `CODE_OF_CONDUCT.md_docs.md` (6443 bytes)
- `CODE_OF_CONDUCT.md_kw.md` (16011 bytes)
- `CONTRIBUTING.md_docs.md` (1510 bytes)
- `CONTRIBUTING.md_kw.md` (2255 bytes)
- `Cargo.toml_docs.md` (1464 bytes)
- `Cargo.toml_kw.md` (2719 bytes)
- `LICENSE_docs.md` (1823 bytes)
- `LICENSE_kw.md` (3620 bytes)
- `README.md_docs.md` (1562 bytes)
- `README.md_kw.md` (1359 bytes)
- `doc.md` (461 bytes)
- `index.md` (464 bytes)
- `repo_book_gen.py_docs.md` (30109 bytes)
- `repo_book_gen.py_kw.md` (25541 bytes)
- `sub.md` (74 bytes)
