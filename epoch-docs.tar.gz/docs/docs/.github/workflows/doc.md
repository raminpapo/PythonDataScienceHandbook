# Documentation: docs/.github/workflows

## Folder Overview

**Path**: `docs/.github/workflows`
**Files**: 7
**Subdirectories**: 0

## Purpose

This folder is located at `docs/.github/workflows`.

## Contents Summary


### Files:
- `build.yaml_docs.md` (1747 bytes)
- `build.yaml_kw.md` (3443 bytes)
- `doc.md` (272 bytes)
- `index.md` (131 bytes)
- `release.yaml_docs.md` (2861 bytes)
- `release.yaml_kw.md` (6262 bytes)
- `sub.md` (74 bytes)
