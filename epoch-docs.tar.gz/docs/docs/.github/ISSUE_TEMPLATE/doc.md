# Documentation: docs/.github/ISSUE_TEMPLATE

## Folder Overview

**Path**: `docs/.github/ISSUE_TEMPLATE`
**Files**: 9
**Subdirectories**: 0

## Purpose

This folder is located at `docs/.github/ISSUE_TEMPLATE`.

## Contents Summary


### Files:
- `bug_report.md_docs.md` (1121 bytes)
- `bug_report.md_kw.md` (1406 bytes)
- `config.yml_docs.md` (1097 bytes)
- `config.yml_kw.md` (1889 bytes)
- `doc.md` (322 bytes)
- `feature_request.md_docs.md` (1179 bytes)
- `feature_request.md_kw.md` (1514 bytes)
- `index.md` (191 bytes)
- `sub.md` (74 bytes)
