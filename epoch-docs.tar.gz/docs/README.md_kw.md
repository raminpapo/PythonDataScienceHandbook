# Keywords: README.md

## Extracted Keywords

Total keywords extracted: 25


### A

- **actions**: Identifier found in `README.md`

### B

- **badge**: Identifier found in `README.md`
- **blue**: Identifier found in `README.md`
- **build**: Identifier found in `README.md`

### C

- **color**: Identifier found in `README.md`
- **com**: Identifier found in `README.md`
- **crates**: Identifier found in `README.md`
- **current**: Identifier found in `README.md`

### D

- **databento**: Identifier found in `README.md`

### E

- **epoch**: Identifier found in `README.md`

### G

- **github**: Identifier found in `README.md`

### H

- **https**: Identifier found in `README.md`
- **human**: Identifier found in `README.md`

### I

- **img**: Identifier found in `README.md`

### L

- **license**: Identifier found in `README.md`

### M

- **making**: Identifier found in `README.md`

### R

- **readable**: Identifier found in `README.md`

### S

- **shields**: Identifier found in `README.md`
- **svg**: Identifier found in `README.md`

### T

- **timestamps**: Identifier found in `README.md`

### U

- **unix**: Identifier found in `README.md`
- **utility**: Identifier found in `README.md`

### V

- **version**: Identifier found in `README.md`

### W

- **workflows**: Identifier found in `README.md`

### Y

- **yaml**: Identifier found in `README.md`
