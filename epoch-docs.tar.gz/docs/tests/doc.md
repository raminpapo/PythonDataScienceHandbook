# Documentation: tests

## Folder Overview

**Path**: `tests`
**Files**: 1
**Subdirectories**: 0

## Purpose

This folder is located at `tests`.

## Contents Summary


### Files:
- `integration_tests.rs` (1193 bytes)
