# Global Keyword Index

Total unique keywords: 1126


## A

### Args

Found in:
- `src/main.rs`
### about

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/main.rs`
### above

Found in:
- `LICENSE`
- `repo_book_gen.py`
### abs

Found in:
- `src/main.rs`
### abusive

Found in:
- `CODE_OF_CONDUCT.md`
### acceptable

Found in:
- `CODE_OF_CONDUCT.md`
### accepting

Found in:
- `CODE_OF_CONDUCT.md`
### account

Found in:
- `CODE_OF_CONDUCT.md`
### achieve

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### act

Found in:
- `CODE_OF_CONDUCT.md`
### acting

Found in:
- `CODE_OF_CONDUCT.md`
### action

Found in:
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### actions

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `README.md`
### actual

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `repo_book_gen.py`
### adapted

Found in:
- `CODE_OF_CONDUCT.md`
### add

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### add_argument

Found in:
- `repo_book_gen.py`
### added

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `.gitignore`
### address

Found in:
- `CODE_OF_CONDUCT.md`
### adds

Found in:
- `.github/pull_request_template.md`
### advances

Found in:
- `CODE_OF_CONDUCT.md`
### affected

Found in:
- `CODE_OF_CONDUCT.md`
### after

Found in:
- `src/main.rs`
### age

Found in:
- `CODE_OF_CONDUCT.md`
### aggression

Found in:
- `CODE_OF_CONDUCT.md`
### aligned

Found in:
- `CODE_OF_CONDUCT.md`
### allowed

Found in:
- `CODE_OF_CONDUCT.md`
### alphabetically

Found in:
- `repo_book_gen.py`
### also

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
### always

Found in:
- `repo_book_gen.py`
### analysis

Found in:
- `repo_book_gen.py`
### and_then

Found in:
- `src/main.rs`
### answers

Found in:
- `CODE_OF_CONDUCT.md`
### any

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### anyhow

Found in:
- `Cargo.toml`
- `src/main.rs`
### anything

Found in:
- `scripts/format.sh`
### apache

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
### api

Found in:
- `repo_book_gen.py`
### apologizing

Found in:
- `CODE_OF_CONDUCT.md`
### apology

Found in:
- `CODE_OF_CONDUCT.md`
### appearance

Found in:
- `CODE_OF_CONDUCT.md`
### appears

Found in:
- `repo_book_gen.py`
### append

Found in:
- `repo_book_gen.py`
### append_body

Found in:
- `.github/workflows/release.yaml`
### applies

Found in:
- `CODE_OF_CONDUCT.md`
### appointed

Found in:
- `CODE_OF_CONDUCT.md`
### appropriate

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### approximate

Found in:
- `src/main.rs`
### arg

Found in:
- `src/main.rs`
- `tests/integration_tests.rs`
### argparse

Found in:
- `repo_book_gen.py`
### args

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### argumentparser

Found in:
- `repo_book_gen.py`
### arguments

Found in:
- `src/main.rs`
### arising

Found in:
- `LICENSE`
### around

Found in:
- `CODE_OF_CONDUCT.md`
### as_bytes

Found in:
- `src/main.rs`
### ask

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### assert

Found in:
- `tests/integration_tests.rs`
### assert_cmd

Found in:
- `Cargo.toml`
- `tests/integration_tests.rs`
### associated

Found in:
- `LICENSE`
### attacks

Found in:
- `CODE_OF_CONDUCT.md`
### attention

Found in:
- `CODE_OF_CONDUCT.md`
### attribution

Found in:
- `CODE_OF_CONDUCT.md`
### author

Found in:
- `CONTRIBUTING.md`
### authority

Found in:
- `.github/pull_request_template.md`
### authors

Found in:
- `Cargo.toml`
- `LICENSE`
### available

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### avoiding

Found in:
- `CODE_OF_CONDUCT.md`

## B

### backup

Found in:
- `.gitignore`
### badge

Found in:
- `README.md`
### ban

Found in:
- `CODE_OF_CONDUCT.md`
### banks

Found in:
- `LICENSE`
### bash

Found in:
- `.github/workflows/build.yaml`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### been

Found in:
- `.github/pull_request_template.md`
### behalf

Found in:
- `.github/pull_request_template.md`
### behavior

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `CODE_OF_CONDUCT.md`
### being

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### best

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### bin

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### binary

Found in:
- `repo_book_gen.py`
### binary_files

Found in:
- `repo_book_gen.py`
### blank_issues_enabled

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### block

Found in:
- `repo_book_gen.py`
### blue

Found in:
- `README.md`
### body

Found in:
- `CODE_OF_CONDUCT.md`
### body_path

Found in:
- `.github/workflows/release.yaml`
### book

Found in:
- `repo_book_gen.py`
### book_path

Found in:
- `repo_book_gen.py`
### bool

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### boolean

Found in:
- `tests/integration_tests.rs`
### bootstrap

Found in:
- `repo_book_gen.py`
### bound

Found in:
- `src/main.rs`
### bound_ms

Found in:
- `src/main.rs`
### bound_ns

Found in:
- `src/main.rs`
### bound_s

Found in:
- `src/main.rs`
### box

Found in:
- `src/main.rs`
### branches

Found in:
- `.github/workflows/release.yaml`
### break

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### breaking

Found in:
- `.github/pull_request_template.md`
### bufread

Found in:
- `src/main.rs`
### bufreader

Found in:
- `src/main.rs`
### bufwriter

Found in:
- `src/main.rs`
### bug

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
### build

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `README.md`
- `repo_book_gen.py`
- `scripts/build.sh`
### builder

Found in:
- `repo_book_gen.py`
### builds

Found in:
- `.github/pull_request_template.md`
### bytes

Found in:
- `repo_book_gen.py`
### bytes_written

Found in:
- `repo_book_gen.py`

## C

### cache

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### camelcase

Found in:
- `repo_book_gen.py`
### cannot

Found in:
- `repo_book_gen.py`
### cargo

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### cargo_bin

Found in:
- `tests/integration_tests.rs`
### cargo_registry_token

Found in:
- `.github/workflows/release.yaml`
### case

Found in:
- `repo_book_gen.py`
- `tests/integration_tests.rs`
### categories

Found in:
- `Cargo.toml`
### category_slugs

Found in:
- `Cargo.toml`
### cause

Found in:
- `.github/pull_request_template.md`
### cells

Found in:
- `repo_book_gen.py`
### change

Found in:
- `.github/pull_request_template.md`
### changelog

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
### changes

Found in:
- `.github/pull_request_template.md`
- `CONTRIBUTING.md`
### channels

Found in:
- `CODE_OF_CONDUCT.md`
### chapter

Found in:
- `repo_book_gen.py`
### char

Found in:
- `src/main.rs`
### char_indices

Found in:
- `src/main.rs`
### character

Found in:
- `src/main.rs`
### characteristics

Found in:
- `CODE_OF_CONDUCT.md`
### charge

Found in:
- `LICENSE`
### check

Found in:
- `repo_book_gen.py`
- `scripts/format.sh`
### checklist

Found in:
- `.github/pull_request_template.md`
### checkout

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### checksums

Found in:
- `repo_book_gen.py`
### chrono

Found in:
- `Cargo.toml`
- `src/main.rs`
### chunk

Found in:
- `repo_book_gen.py`
### claim

Found in:
- `LICENSE`
### clap

Found in:
- `Cargo.toml`
- `src/main.rs`
### clarifying

Found in:
- `CODE_OF_CONDUCT.md`
### clarity

Found in:
- `CODE_OF_CONDUCT.md`
### class

Found in:
- `repo_book_gen.py`
### class_count

Found in:
- `repo_book_gen.py`
### classes

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### classify

Found in:
- `repo_book_gen.py`
### classify_file

Found in:
- `repo_book_gen.py`
### classifying

Found in:
- `repo_book_gen.py`
### cli

Found in:
- `Cargo.toml`
### clippy

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `scripts/lint.sh`
### cls

Found in:
- `repo_book_gen.py`
### cmd

Found in:
- `tests/integration_tests.rs`
### code

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### code_of_conduct

Found in:
- `CODE_OF_CONDUCT.md`
### codebase

Found in:
- `CONTRIBUTING.md`
### collections

Found in:
- `repo_book_gen.py`
### color

Found in:
- `README.md`
### com

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
### combining

Found in:
- `repo_book_gen.py`
### command

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `src/main.rs`
- `tests/integration_tests.rs`
### comments

Found in:
- `CODE_OF_CONDUCT.md`
### commit

Found in:
- `.github/workflows/release.yaml`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### commits

Found in:
- `CODE_OF_CONDUCT.md`
### common

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### common_words

Found in:
- `repo_book_gen.py`
### communicate

Found in:
- `CODE_OF_CONDUCT.md`
### communication

Found in:
- `CODE_OF_CONDUCT.md`
### community

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### compiled

Found in:
- `.gitignore`
### complaints

Found in:
- `CODE_OF_CONDUCT.md`
### complete

Found in:
- `repo_book_gen.py`
### completed

Found in:
- `.github/workflows/release.yaml`
### component

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### comprehensive

Found in:
- `repo_book_gen.py`
### comprehensive_book

Found in:
- `repo_book_gen.py`
### compute

Found in:
- `repo_book_gen.py`
### compute_repo_fingerprint

Found in:
- `repo_book_gen.py`
### concerns

Found in:
- `repo_book_gen.py`
### conclusion

Found in:
- `.github/workflows/release.yaml`
### conditions

Found in:
- `LICENSE`
### conduct

Found in:
- `CODE_OF_CONDUCT.md`
### configuration

Found in:
- `.github/pull_request_template.md`
### confirm

Found in:
- `.github/pull_request_template.md`
### connection

Found in:
- `LICENSE`
### consequence

Found in:
- `CODE_OF_CONDUCT.md`
### consequences

Found in:
- `CODE_OF_CONDUCT.md`
### considered

Found in:
- `CODE_OF_CONDUCT.md`
### const

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### constructive

Found in:
- `CODE_OF_CONDUCT.md`
### contact_links

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### containing

Found in:
- `repo_book_gen.py`
### contains

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### content

Found in:
- `repo_book_gen.py`
### contents

Found in:
- `repo_book_gen.py`
### context

Found in:
- `.github/pull_request_template.md`
### continue

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### continued

Found in:
- `CODE_OF_CONDUCT.md`
### contract

Found in:
- `LICENSE`
### contribute

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### contributes

Found in:
- `CODE_OF_CONDUCT.md`
### contribution

Found in:
- `.github/pull_request_template.md`
### contributions

Found in:
- `CODE_OF_CONDUCT.md`
### contributor

Found in:
- `CODE_OF_CONDUCT.md`
### contributors

Found in:
- `CODE_OF_CONDUCT.md`
### convert

Found in:
- `src/main.rs`
### converting

Found in:
- `Cargo.toml`
### copies

Found in:
- `LICENSE`
### copy

Found in:
- `LICENSE`
### copyright

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### correction

Found in:
- `CODE_OF_CONDUCT.md`
### corrective

Found in:
- `CODE_OF_CONDUCT.md`
### corresponding

Found in:
- `.github/pull_request_template.md`
### could

Found in:
- `CODE_OF_CONDUCT.md`
### count

Found in:
- `repo_book_gen.py`
### covenant

Found in:
- `CODE_OF_CONDUCT.md`
### cpp

Found in:
- `repo_book_gen.py`
- `tests/integration_tests.rs`
### crates

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `README.md`
### create

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/main.rs`
### created

Found in:
- `repo_book_gen.py`
### creating

Found in:
- `.gitignore`
### current

Found in:
- `README.md`
### cut

Found in:
- `scripts/get_version.sh`

## D

### Dict

Found in:
- `repo_book_gen.py`
### damages

Found in:
- `LICENSE`
### dangerous

Found in:
- `repo_book_gen.py`
### databento

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
### databentohq

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### date

Found in:
- `Cargo.toml`
### dates

Found in:
- `src/main.rs`
### datetime

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### days

Found in:
- `src/main.rs`
### deal

Found in:
- `LICENSE`
### dealings

Found in:
- `LICENSE`
### debug

Found in:
- `src/main.rs`
### decisions

Found in:
- `CODE_OF_CONDUCT.md`
### declaration

Found in:
- `.github/pull_request_template.md`
### deem

Found in:
- `CODE_OF_CONDUCT.md`
### deemed

Found in:
- `CODE_OF_CONDUCT.md`
### def

Found in:
- `repo_book_gen.py`
### default

Found in:
- `repo_book_gen.py`
### default_value_t

Found in:
- `src/main.rs`
### defaultdict

Found in:
- `repo_book_gen.py`
### delete

Found in:
- `.github/pull_request_template.md`
### demonstrating

Found in:
- `CODE_OF_CONDUCT.md`
### deny

Found in:
- `scripts/lint.sh`
### dependencies

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
### depth

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### derive

Found in:
- `Cargo.toml`
- `src/main.rs`
### derogatory

Found in:
- `CODE_OF_CONDUCT.md`
### describe

Found in:
- `.github/pull_request_template.md`
### description

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `Cargo.toml`
- `repo_book_gen.py`
### detailed

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `repo_book_gen.py`
### details

Found in:
- `.github/pull_request_template.md`
### detect

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### detected

Found in:
- `repo_book_gen.py`
### detecting

Found in:
- `src/main.rs`
### determined

Found in:
- `repo_book_gen.py`
### determining

Found in:
- `CODE_OF_CONDUCT.md`
### dev

Found in:
- `Cargo.toml`
### dict

Found in:
- `repo_book_gen.py`
### differing

Found in:
- `CODE_OF_CONDUCT.md`
### directly

Found in:
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### directories

Found in:
- `repo_book_gen.py`
### directory

Found in:
- `repo_book_gen.py`
### dirname

Found in:
- `scripts/get_version.sh`
### dirs

Found in:
- `repo_book_gen.py`
### disability

Found in:
- `CODE_OF_CONDUCT.md`
### discussions

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CONTRIBUTING.md`
### disparagement

Found in:
- `CODE_OF_CONDUCT.md`
### distribute

Found in:
- `LICENSE`
### diverse

Found in:
- `CODE_OF_CONDUCT.md`
### diversity

Found in:
- `CODE_OF_CONDUCT.md`
### doc

Found in:
- `.gitignore`
- `repo_book_gen.py`
### doc_content

Found in:
- `repo_book_gen.py`
### doc_name

Found in:
- `repo_book_gen.py`
### doc_path

Found in:
- `repo_book_gen.py`
### docs

Found in:
- `repo_book_gen.py`
### docs_count

Found in:
- `repo_book_gen.py`
### docs_created

Found in:
- `repo_book_gen.py`
### docstring

Found in:
- `repo_book_gen.py`
### docstring_lines

Found in:
- `repo_book_gen.py`
### documentation

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
- `repo_book_gen.py`
### documented

Found in:
- `repo_book_gen.py`
### doesn

Found in:
- `.github/workflows/release.yaml`
### don

Found in:
- `CONTRIBUTING.md`
### downstream

Found in:
- `CONTRIBUTING.md`
### due

Found in:
- `CONTRIBUTING.md`
### dump

Found in:
- `repo_book_gen.py`
### dumps

Found in:
- `repo_book_gen.py`
### duration

Found in:
- `src/main.rs`
### during

Found in:
- `CODE_OF_CONDUCT.md`
### dyn

Found in:
- `src/main.rs`

## E

### each

Found in:
- `repo_book_gen.py`
### echo

Found in:
- `.github/workflows/release.yaml`
- `scripts/build.sh`
### economic

Found in:
- `CODE_OF_CONDUCT.md`
### edit

Found in:
- `CODE_OF_CONDUCT.md`
### edition

Found in:
- `Cargo.toml`
### edits

Found in:
- `CODE_OF_CONDUCT.md`
### education

Found in:
- `CODE_OF_CONDUCT.md`
### effective

Found in:
- `.github/pull_request_template.md`
### elif

Found in:
- `repo_book_gen.py`
### else

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### email

Found in:
- `CODE_OF_CONDUCT.md`
### empathy

Found in:
- `CODE_OF_CONDUCT.md`
### encode

Found in:
- `repo_book_gen.py`
### encoding

Found in:
- `repo_book_gen.py`
### encountered

Found in:
- `repo_book_gen.py`
### end

Found in:
- `tests/integration_tests.rs`
### ends_with

Found in:
- `tests/integration_tests.rs`
### enforcement

Found in:
- `CODE_OF_CONDUCT.md`
### enforcing

Found in:
- `CODE_OF_CONDUCT.md`
### enhancement

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
### entries

Found in:
- `tests/integration_tests.rs`
### entry

Found in:
- `repo_book_gen.py`
### enum

Found in:
- `repo_book_gen.py`
### enumerate

Found in:
- `repo_book_gen.py`
### env

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### environment

Found in:
- `CODE_OF_CONDUCT.md`
### epoch

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `Cargo.toml`
- `README.md`
- `tests/integration_tests.rs`
### err

Found in:
- `repo_book_gen.py`
### error

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### errors

Found in:
- `repo_book_gen.py`
### estimate

Found in:
- `repo_book_gen.py`
### etc

Found in:
- `repo_book_gen.py`
### ethnicity

Found in:
- `CODE_OF_CONDUCT.md`
### eval

Found in:
- `repo_book_gen.py`
### event

Found in:
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `tests/integration_tests.rs`
### everyone

Found in:
- `CODE_OF_CONDUCT.md`
### examples

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### except

Found in:
- `repo_book_gen.py`
### exception

Found in:
- `repo_book_gen.py`
### exec

Found in:
- `repo_book_gen.py`
### executable

Found in:
- `.gitignore`
### executables

Found in:
- `.gitignore`
### execution

Found in:
- `repo_book_gen.py`
### exist

Found in:
- `.github/workflows/release.yaml`
### exist_ok

Found in:
- `repo_book_gen.py`
### existing

Found in:
- `.github/pull_request_template.md`
### exists

Found in:
- `repo_book_gen.py`
### exit

Found in:
- `scripts/get_version.sh`
### expected

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
### experience

Found in:
- `CODE_OF_CONDUCT.md`
### experiences

Found in:
- `CODE_OF_CONDUCT.md`
### explanation

Found in:
- `CODE_OF_CONDUCT.md`
### explicit

Found in:
- `CODE_OF_CONDUCT.md`
### express

Found in:
- `LICENSE`
### expression

Found in:
- `CODE_OF_CONDUCT.md`
### ext

Found in:
- `repo_book_gen.py`
### extension

Found in:
- `repo_book_gen.py`
### external

Found in:
- `CODE_OF_CONDUCT.md`
### extra

Found in:
- `tests/integration_tests.rs`
### extract

Found in:
- `repo_book_gen.py`
### extract_keywords

Found in:
- `repo_book_gen.py`
### extracted

Found in:
- `repo_book_gen.py`

## F

### fail

Found in:
- `.github/workflows/build.yaml`
### fails

Found in:
- `scripts/format.sh`
### fair

Found in:
- `CODE_OF_CONDUCT.md`
### fairly

Found in:
- `CODE_OF_CONDUCT.md`
### fallback

Found in:
- `repo_book_gen.py`
### false

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/main.rs`
### faq

Found in:
- `CODE_OF_CONDUCT.md`
### fast

Found in:
- `.github/workflows/build.yaml`
### feature

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
### features

Found in:
- `Cargo.toml`
- `scripts/build.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### feedback

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### fetch

Found in:
- `.github/workflows/release.yaml`
### few

Found in:
- `repo_book_gen.py`
### file

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### file_class

Found in:
- `repo_book_gen.py`
### file_count

Found in:
- `repo_book_gen.py`
### file_list

Found in:
- `repo_book_gen.py`
### file_path

Found in:
- `repo_book_gen.py`
### file_str

Found in:
- `repo_book_gen.py`
### filename

Found in:
- `repo_book_gen.py`
### filenames

Found in:
- `repo_book_gen.py`
### files

Found in:
- `.gitignore`
- `LICENSE`
- `repo_book_gen.py`
### files_scanned

Found in:
- `repo_book_gen.py`
### find

Found in:
- `src/main.rs`
### findall

Found in:
- `repo_book_gen.py`
### fingerprint

Found in:
- `repo_book_gen.py`
### first

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### first_letter

Found in:
- `repo_book_gen.py`
### fitness

Found in:
- `LICENSE`
### fix

Found in:
- `.github/pull_request_template.md`
### fixes

Found in:
- `.github/pull_request_template.md`
### flush

Found in:
- `src/main.rs`
### fmt

Found in:
- `scripts/format.sh`
### focusing

Found in:
- `CODE_OF_CONDUCT.md`
### folder

Found in:
- `repo_book_gen.py`
### folder_path

Found in:
- `repo_book_gen.py`
### folders

Found in:
- `repo_book_gen.py`
### follow

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CODE_OF_CONDUCT.md`
### following

Found in:
- `LICENSE`
### follows

Found in:
- `.github/pull_request_template.md`
### force

Found in:
- `.github/workflows/release.yaml`
### format

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `src/main.rs`
- `tests/integration_tests.rs`
### formatted

Found in:
- `src/main.rs`
### formatting

Found in:
- `Cargo.toml`
### found

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### framework

Found in:
- `repo_book_gen.py`
### free

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### from

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/main.rs`
### func

Found in:
- `repo_book_gen.py`
### func_count

Found in:
- `repo_book_gen.py`
### function

Found in:
- `repo_book_gen.py`
### functionality

Found in:
- `.github/pull_request_template.md`
### functions

Found in:
- `repo_book_gen.py`
### furnished

Found in:
- `LICENSE`

## G

### gender

Found in:
- `CODE_OF_CONDUCT.md`
### general

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `repo_book_gen.py`
### generate

Found in:
- `repo_book_gen.py`
### generate_comprehensive_book

Found in:
- `repo_book_gen.py`
### generate_file_docs

Found in:
- `repo_book_gen.py`
### generate_file_keywords

Found in:
- `repo_book_gen.py`
### generate_folder_doc

Found in:
- `repo_book_gen.py`
### generate_folder_index

Found in:
- `repo_book_gen.py`
### generate_folder_sub

Found in:
- `repo_book_gen.py`
### generate_global_index

Found in:
- `repo_book_gen.py`
### generate_global_keyword_index

Found in:
- `repo_book_gen.py`
### generate_overview

Found in:
- `repo_book_gen.py`
### generate_performance_security_notes

Found in:
- `repo_book_gen.py`
### generate_readme

Found in:
- `repo_book_gen.py`
### generate_related_files

Found in:
- `repo_book_gen.py`
### generate_test_info

Found in:
- `repo_book_gen.py`
### generate_usage_examples

Found in:
- `repo_book_gen.py`
### generate_verification_report

Found in:
- `repo_book_gen.py`
### generate_walkthrough

Found in:
- `repo_book_gen.py`
### generated

Found in:
- `.gitignore`
- `repo_book_gen.py`
### generating

Found in:
- `repo_book_gen.py`
### generation

Found in:
- `repo_book_gen.py`
### generator

Found in:
- `repo_book_gen.py`
### generator_version

Found in:
- `repo_book_gen.py`
### generous

Found in:
- `src/main.rs`
### get_version

Found in:
- `.github/workflows/release.yaml`
### getting

Found in:
- `repo_book_gen.py`
### git

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### git_dir

Found in:
- `repo_book_gen.py`
### github

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `repo_book_gen.py`
### github_env

Found in:
- `.github/workflows/release.yaml`
### gitignore

Found in:
- `.gitignore`
### giving

Found in:
- `CODE_OF_CONDUCT.md`
### global

Found in:
- `repo_book_gen.py`
### gracefully

Found in:
- `CODE_OF_CONDUCT.md`
### granted

Found in:
- `LICENSE`
### grep

Found in:
- `scripts/get_version.sh`
### group

Found in:
- `repo_book_gen.py`
### grouped

Found in:
- `repo_book_gen.py`
### guess_type

Found in:
- `repo_book_gen.py`
### guide

Found in:
- `.gitignore`
### guidelines

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`

## H

### handletradesummary

Found in:
- `tests/integration_tests.rs`
### harassing

Found in:
- `CODE_OF_CONDUCT.md`
### harassment

Found in:
- `CODE_OF_CONDUCT.md`
### hardcoded

Found in:
- `repo_book_gen.py`
### harmful

Found in:
- `CODE_OF_CONDUCT.md`
### hash

Found in:
- `repo_book_gen.py`
### hashfiles

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### hashlib

Found in:
- `repo_book_gen.py`
### have

Found in:
- `.github/pull_request_template.md`
- `.gitignore`
- `CODE_OF_CONDUCT.md`
### head

Found in:
- `repo_book_gen.py`
### head_file

Found in:
- `repo_book_gen.py`
### healthy

Found in:
- `CODE_OF_CONDUCT.md`
### help

Found in:
- `repo_book_gen.py`
### here

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.gitignore`
- `src/main.rs`
### hereby

Found in:
- `LICENSE`
### heuristic

Found in:
- `src/main.rs`
### hexdigest

Found in:
- `repo_book_gen.py`
### high

Found in:
- `repo_book_gen.py`
### holders

Found in:
- `LICENSE`
### homepage

Found in:
- `CODE_OF_CONDUCT.md`
### html

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
### https

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.gitignore`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
### human

Found in:
- `Cargo.toml`
- `README.md`

## I

### i32

Found in:
- `src/main.rs`
### i64

Found in:
- `src/main.rs`
### identifier

Found in:
- `repo_book_gen.py`
### identifiers

Found in:
- `repo_book_gen.py`
### identity

Found in:
- `CODE_OF_CONDUCT.md`
### ignore_patterns

Found in:
- `repo_book_gen.py`
### ignorecase

Found in:
- `repo_book_gen.py`
### ignored

Found in:
- `repo_book_gen.py`
### imagery

Found in:
- `CODE_OF_CONDUCT.md`
### img

Found in:
- `README.md`
### impact

Found in:
- `CODE_OF_CONDUCT.md`
### impl

Found in:
- `src/main.rs`
### implied

Found in:
- `LICENSE`
### import

Found in:
- `repo_book_gen.py`
### import_count

Found in:
- `repo_book_gen.py`
### in_docstring

Found in:
- `repo_book_gen.py`
### inappropriate

Found in:
- `CODE_OF_CONDUCT.md`
### incident

Found in:
- `CODE_OF_CONDUCT.md`
### include

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
### included

Found in:
- `LICENSE`
### includes

Found in:
- `CODE_OF_CONDUCT.md`
### including

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### inclusive

Found in:
- `CODE_OF_CONDUCT.md`
### indent

Found in:
- `repo_book_gen.py`
### index

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### index_content

Found in:
- `repo_book_gen.py`
### index_path

Found in:
- `repo_book_gen.py`
### indexes

Found in:
- `repo_book_gen.py`
### individual

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### individuals

Found in:
- `CODE_OF_CONDUCT.md`
### info

Found in:
- `CODE_OF_CONDUCT.md`
### information

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### initial

Found in:
- `CHANGELOG.md`
### input

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### input_file

Found in:
- `src/main.rs`
### inspired

Found in:
- `CODE_OF_CONDUCT.md`
### instances

Found in:
- `CODE_OF_CONDUCT.md`
### instead

Found in:
- `src/main.rs`
### instructions

Found in:
- `.github/pull_request_template.md`
### insulting

Found in:
- `CODE_OF_CONDUCT.md`
### integration

Found in:
- `Cargo.toml`
### interact

Found in:
- `CODE_OF_CONDUCT.md`
### interaction

Found in:
- `CODE_OF_CONDUCT.md`
### interactions

Found in:
- `CODE_OF_CONDUCT.md`
### interactive

Found in:
- `repo_book_gen.py`
### internal

Found in:
- `CONTRIBUTING.md`
### investigated

Found in:
- `CODE_OF_CONDUCT.md`
### invisible

Found in:
- `CODE_OF_CONDUCT.md`
### involved

Found in:
- `CODE_OF_CONDUCT.md`
### ipynb

Found in:
- `repo_book_gen.py`
### is_binary

Found in:
- `repo_book_gen.py`
### is_dir

Found in:
- `repo_book_gen.py`
### is_empty

Found in:
- `tests/integration_tests.rs`
### is_file

Found in:
- `repo_book_gen.py`
### isn

Found in:
- `src/main.rs`
### isoformat

Found in:
- `repo_book_gen.py`
### issue

Found in:
- `.github/pull_request_template.md`
### issues

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### iterdir

Found in:
- `repo_book_gen.py`

## J

### java

Found in:
- `repo_book_gen.py`
### javascript

Found in:
- `repo_book_gen.py`
### jobs

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### join

Found in:
- `repo_book_gen.py`
### json

Found in:
- `repo_book_gen.py`
### jupyter

Found in:
- `repo_book_gen.py`
### just

Found in:
- `CODE_OF_CONDUCT.md`

## K

### key

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### keys

Found in:
- `repo_book_gen.py`
### keyword

Found in:
- `repo_book_gen.py`
### keywords

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
### keywords_global

Found in:
- `repo_book_gen.py`
### kind

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### kindness

Found in:
- `CODE_OF_CONDUCT.md`
### know

Found in:
- `src/main.rs`
### kw_content

Found in:
- `repo_book_gen.py`
### kw_doc

Found in:
- `repo_book_gen.py`
### kw_path

Found in:
- `repo_book_gen.py`

## L

### LOCALIZE

Found in:
- `src/main.rs`
### labels

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/feature_request.md`
### ladder

Found in:
- `CODE_OF_CONDUCT.md`
### lang

Found in:
- `.gitignore`
- `repo_book_gen.py`
### lang_map

Found in:
- `repo_book_gen.py`
### language

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### large

Found in:
- `repo_book_gen.py`
### large_blob

Found in:
- `repo_book_gen.py`
### last

Found in:
- `src/main.rs`
### latest

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### latin

Found in:
- `repo_book_gen.py`
### lead

Found in:
- `CODE_OF_CONDUCT.md`
### leaders

Found in:
- `CODE_OF_CONDUCT.md`
### learning

Found in:
- `CODE_OF_CONDUCT.md`
### leave

Found in:
- `.gitignore`
### len

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### length

Found in:
- `src/main.rs`
### less

Found in:
- `src/main.rs`
### letter

Found in:
- `repo_book_gen.py`
### level

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### liability

Found in:
- `LICENSE`
### liable

Found in:
- `LICENSE`
### libraries

Found in:
- `.gitignore`
### library

Found in:
- `.github/workflows/release.yaml`
### license

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
- `LICENSE`
- `README.md`
### like

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CODE_OF_CONDUCT.md`
### limit

Found in:
- `repo_book_gen.py`
### limitation

Found in:
- `LICENSE`
### limited

Found in:
- `LICENSE`
### line

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
- `src/main.rs`
### lines

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### linking

Found in:
- `repo_book_gen.py`
### links

Found in:
- `repo_book_gen.py`
### lint

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
### list

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### local

Found in:
- `src/main.rs`
- `tests/integration_tests.rs`
### localize

Found in:
- `src/main.rs`
### locally

Found in:
- `.github/pull_request_template.md`
### located

Found in:
- `repo_book_gen.py`
### lock

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
- `src/main.rs`
### long

Found in:
- `src/main.rs`
### look

Found in:
- `repo_book_gen.py`
### lower

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### lower_s

Found in:
- `src/main.rs`

## M

### macos

Found in:
- `.github/workflows/build.yaml`
### made

Found in:
- `.github/pull_request_template.md`
### mail

Found in:
- `CODE_OF_CONDUCT.md`
### main

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/main.rs`
### make

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
### making

Found in:
- `README.md`
### manifest

Found in:
- `repo_book_gen.py`
### manifest_path

Found in:
- `repo_book_gen.py`
### map

Found in:
- `src/main.rs`
### markdown

Found in:
- `repo_book_gen.py`
### marker

Found in:
- `repo_book_gen.py`
### match

Found in:
- `src/main.rs`
### matrix

Found in:
- `.github/workflows/build.yaml`
### maximum

Found in:
- `Cargo.toml`
### may

Found in:
- `CODE_OF_CONDUCT.md`
### mdp30

Found in:
- `tests/integration_tests.rs`
### media

Found in:
- `CODE_OF_CONDUCT.md`
### members

Found in:
- `CODE_OF_CONDUCT.md`
### merchantability

Found in:
- `LICENSE`
### merge

Found in:
- `CONTRIBUTING.md`
- `LICENSE`
### merged

Found in:
- `repo_book_gen.py`
### merges

Found in:
- `repo_book_gen.py`
### metadata

Found in:
- `repo_book_gen.py`
### millis

Found in:
- `src/main.rs`
### mime

Found in:
- `repo_book_gen.py`
### mimetypes

Found in:
- `repo_book_gen.py`
### min

Found in:
- `src/main.rs`
### min_len

Found in:
- `src/main.rs`
### minimal

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### mirror

Found in:
- `CONTRIBUTING.md`
### misformatted

Found in:
- `scripts/format.sh`
### mistakes

Found in:
- `CODE_OF_CONDUCT.md`
### mit

Found in:
- `LICENSE`
### mkdir

Found in:
- `repo_book_gen.py`
### moderation

Found in:
- `CODE_OF_CONDUCT.md`
### modify

Found in:
- `LICENSE`
### module

Found in:
- `repo_book_gen.py`
### more

Found in:
- `.gitignore`
### motivation

Found in:
- `.github/pull_request_template.md`
### mozilla

Found in:
- `CODE_OF_CONDUCT.md`
### multiline

Found in:
- `repo_book_gen.py`
### multiprocessing

Found in:
- `repo_book_gen.py`
### mut

Found in:
- `src/main.rs`

## N

### NUMBERS

Found in:
- `src/main.rs`
### name

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `repo_book_gen.py`
### nanos

Found in:
- `src/main.rs`
### nationality

Found in:
- `CODE_OF_CONDUCT.md`
### nature

Found in:
- `CODE_OF_CONDUCT.md`
### nautechsystems

Found in:
- `CODE_OF_CONDUCT.md`
### navigate

Found in:
- `repo_book_gen.py`
### necessary

Found in:
- `.github/pull_request_template.md`
### need

Found in:
- `repo_book_gen.py`
### needed

Found in:
- `repo_book_gen.py`
### news

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### njson

Found in:
- `repo_book_gen.py`
### nkeywords

Found in:
- `repo_book_gen.py`
### node_modules

Found in:
- `repo_book_gen.py`
### non

Found in:
- `.github/pull_request_template.md`
- `src/main.rs`
### none

Found in:
- `src/main.rs`
### noninfringement

Found in:
- `LICENSE`
### notebook

Found in:
- `repo_book_gen.py`
### notes

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### notice

Found in:
- `LICENSE`
### number

Found in:
- `src/main.rs`
### number_end

Found in:
- `src/main.rs`
### number_start

Found in:
- `src/main.rs`
### numbers

Found in:
- `src/main.rs`

## O

### object

Found in:
- `repo_book_gen.py`
### obligated

Found in:
- `CODE_OF_CONDUCT.md`
### obtaining

Found in:
- `LICENSE`
### offensive

Found in:
- `CODE_OF_CONDUCT.md`
### official

Found in:
- `CODE_OF_CONDUCT.md`
### officially

Found in:
- `CODE_OF_CONDUCT.md`
### offline

Found in:
- `CODE_OF_CONDUCT.md`
### offset

Found in:
- `src/main.rs`
### omit

Found in:
- `src/main.rs`
### online

Found in:
- `CODE_OF_CONDUCT.md`
### only

Found in:
- `src/main.rs`
### open

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
- `src/main.rs`
### opinions

Found in:
- `CODE_OF_CONDUCT.md`
### ops

Found in:
- `src/main.rs`
### option

Found in:
- `src/main.rs`
### options

Found in:
- `.github/pull_request_template.md`
### ord

Found in:
- `tests/integration_tests.rs`
### order

Found in:
- `tests/integration_tests.rs`
### org

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
### organization

Found in:
- `repo_book_gen.py`
### orientation

Found in:
- `CODE_OF_CONDUCT.md`
### oriented

Found in:
- `repo_book_gen.py`
### original

Found in:
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### other

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### others

Found in:
- `CODE_OF_CONDUCT.md`
### otherwise

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/main.rs`
### out_dir

Found in:
- `repo_book_gen.py`
### output

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/main.rs`
### output_dir

Found in:
- `repo_book_gen.py`
### outputs

Found in:
- `.github/workflows/release.yaml`
### overall

Found in:
- `CODE_OF_CONDUCT.md`
### overview

Found in:
- `repo_book_gen.py`
### owner

Found in:
- `.github/pull_request_template.md`

## P

### Path

Found in:
- `repo_book_gen.py`
### package

Found in:
- `Cargo.toml`
### parallel

Found in:
- `repo_book_gen.py`
### parent

Found in:
- `repo_book_gen.py`
### parents

Found in:
- `repo_book_gen.py`
### parse

Found in:
- `src/main.rs`
### parse_args

Found in:
- `repo_book_gen.py`
### parse_result

Found in:
- `src/main.rs`
### parser

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### parsing

Found in:
- `src/main.rs`
### participation

Found in:
- `CODE_OF_CONDUCT.md`
### particular

Found in:
- `LICENSE`
### parts

Found in:
- `repo_book_gen.py`
### pass

Found in:
- `.github/pull_request_template.md`
### password

Found in:
- `repo_book_gen.py`
### path

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/main.rs`
### pathbuf

Found in:
- `src/main.rs`
### pathlib

Found in:
- `repo_book_gen.py`
### pattern

Found in:
- `CODE_OF_CONDUCT.md`
### patterns

Found in:
- `repo_book_gen.py`
### pcme

Found in:
- `tests/integration_tests.rs`
### peek

Found in:
- `src/main.rs`
### peekable

Found in:
- `src/main.rs`
### people

Found in:
- `CODE_OF_CONDUCT.md`
### per

Found in:
- `repo_book_gen.py`
### perf_sec

Found in:
- `repo_book_gen.py`
### performance

Found in:
- `repo_book_gen.py`
### period

Found in:
- `CODE_OF_CONDUCT.md`
### permanent

Found in:
- `CODE_OF_CONDUCT.md`
### permission

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### permit

Found in:
- `LICENSE`
### person

Found in:
- `LICENSE`
### personal

Found in:
- `CODE_OF_CONDUCT.md`
### persons

Found in:
- `LICENSE`
### pglbx

Found in:
- `tests/integration_tests.rs`
### physical

Found in:
- `CODE_OF_CONDUCT.md`
### placeholder

Found in:
- `repo_book_gen.py`
### platform

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
### please

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### pledge

Found in:
- `CODE_OF_CONDUCT.md`
### plus

Found in:
- `src/main.rs`
### point

Found in:
- `repo_book_gen.py`
### political

Found in:
- `CODE_OF_CONDUCT.md`
### portions

Found in:
- `LICENSE`
### positive

Found in:
- `CODE_OF_CONDUCT.md`
### posting

Found in:
- `CODE_OF_CONDUCT.md`
### potential

Found in:
- `repo_book_gen.py`
### predicatebooleanext

Found in:
- `tests/integration_tests.rs`
### predicates

Found in:
- `Cargo.toml`
- `tests/integration_tests.rs`
### prerelease

Found in:
- `.github/workflows/release.yaml`
### print

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### privacy

Found in:
- `CODE_OF_CONDUCT.md`
### private

Found in:
- `CODE_OF_CONDUCT.md`
### problem

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
### procedural

Found in:
- `repo_book_gen.py`
### process

Found in:
- `repo_book_gen.py`
### process_file

Found in:
- `repo_book_gen.py`
### process_folders

Found in:
- `repo_book_gen.py`
### processed

Found in:
- `repo_book_gen.py`
### processing

Found in:
- `repo_book_gen.py`
### professional

Found in:
- `CODE_OF_CONDUCT.md`
### profile

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### project

Found in:
- `CONTRIBUTING.md`
### project_root_dir

Found in:
- `scripts/get_version.sh`
### promptly

Found in:
- `CODE_OF_CONDUCT.md`
### proposal

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
### prove

Found in:
- `.github/pull_request_template.md`
### provide

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
### provided

Found in:
- `LICENSE`
- `src/main.rs`
### providing

Found in:
- `CODE_OF_CONDUCT.md`
### public

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### publish

Found in:
- `.github/workflows/release.yaml`
- `LICENSE`
### publishing

Found in:
- `CODE_OF_CONDUCT.md`
### pull

Found in:
- `.github/pull_request_template.md`
- `CONTRIBUTING.md`
### pull_request

Found in:
- `.github/workflows/build.yaml`
### purpose

Found in:
- `LICENSE`
- `repo_book_gen.py`
### push

Found in:
- `.github/workflows/build.yaml`
### pwd

Found in:
- `scripts/get_version.sh`
### pytest

Found in:
- `repo_book_gen.py`
### pytest_cache

Found in:
- `repo_book_gen.py`
### python

Found in:
- `repo_book_gen.py`
### python3

Found in:
- `repo_book_gen.py`

## Q

### questions

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CODE_OF_CONDUCT.md`
### quick

Found in:
- `repo_book_gen.py`
### quote

Found in:
- `src/main.rs`

## R

### Reformatter

Found in:
- `src/main.rs`
### RepoBookGenerator

Found in:
- `repo_book_gen.py`
### race

Found in:
- `CODE_OF_CONDUCT.md`
### ran

Found in:
- `.github/pull_request_template.md`
### range

Found in:
- `src/main.rs`
### rangeinclusive

Found in:
- `src/main.rs`
### read

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### read_file_safe

Found in:
- `repo_book_gen.py`
### readable

Found in:
- `Cargo.toml`
- `README.md`
- `repo_book_gen.py`
### reading

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### readme

Found in:
- `repo_book_gen.py`
### readme_path

Found in:
- `repo_book_gen.py`
### reasonably

Found in:
- `CODE_OF_CONDUCT.md`
### reasons

Found in:
- `CODE_OF_CONDUCT.md`
### recursively

Found in:
- `repo_book_gen.py`
### ref

Found in:
- `repo_book_gen.py`
### ref_path

Found in:
- `repo_book_gen.py`
### refer

Found in:
- `repo_book_gen.py`
### reformatter

Found in:
- `src/main.rs`
### regardless

Found in:
- `CODE_OF_CONDUCT.md`
### regenerate

Found in:
- `repo_book_gen.py`
### regenerating

Found in:
- `repo_book_gen.py`
### registry

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### reject

Found in:
- `CODE_OF_CONDUCT.md`
### rel_path

Found in:
- `repo_book_gen.py`
### related

Found in:
- `repo_book_gen.py`
### relative_to

Found in:
- `repo_book_gen.py`
### release

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
### release_name

Found in:
- `.github/workflows/release.yaml`
### relevant

Found in:
- `.github/pull_request_template.md`
### religion

Found in:
- `CODE_OF_CONDUCT.md`
### remove

Found in:
- `.github/workflows/release.yaml`
- `.gitignore`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### repo

Found in:
- `repo_book_gen.py`
### repo_book_gen

Found in:
- `repo_book_gen.py`
### repo_fingerprint

Found in:
- `repo_book_gen.py`
### repo_path

Found in:
- `repo_book_gen.py`
### repo_source

Found in:
- `repo_book_gen.py`
### repobookgenerator

Found in:
- `repo_book_gen.py`
### report

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `repo_book_gen.py`
### report_path

Found in:
- `repo_book_gen.py`
### reported

Found in:
- `CODE_OF_CONDUCT.md`
### reporter

Found in:
- `CODE_OF_CONDUCT.md`
### repositories

Found in:
- `repo_book_gen.py`
### repository

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `repo_book_gen.py`
### representative

Found in:
- `CODE_OF_CONDUCT.md`
### representing

Found in:
- `CODE_OF_CONDUCT.md`
### reproduce

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
### request

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
### requested

Found in:
- `CODE_OF_CONDUCT.md`
### requests

Found in:
- `CONTRIBUTING.md`
### required

Found in:
- `.github/pull_request_template.md`
### requires

Found in:
- `.github/pull_request_template.md`
### resolve

Found in:
- `repo_book_gen.py`
### respect

Found in:
- `CODE_OF_CONDUCT.md`
### respectful

Found in:
- `CODE_OF_CONDUCT.md`
### response

Found in:
- `CODE_OF_CONDUCT.md`
### responsibilities

Found in:
- `CODE_OF_CONDUCT.md`
### responsibility

Found in:
- `CODE_OF_CONDUCT.md`
### responsible

Found in:
- `CODE_OF_CONDUCT.md`
### rest

Found in:
- `src/main.rs`
### restriction

Found in:
- `LICENSE`
### result

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### return

Found in:
- `repo_book_gen.py`
### review

Found in:
- `repo_book_gen.py`
### reviewed

Found in:
- `CODE_OF_CONDUCT.md`
### rfc_format

Found in:
- `src/main.rs`
### right

Found in:
- `CODE_OF_CONDUCT.md`
### rights

Found in:
- `LICENSE`
### root

Found in:
- `repo_book_gen.py`
### root_doc_path

Found in:
- `repo_book_gen.py`
### root_path

Found in:
- `repo_book_gen.py`
### rough

Found in:
- `repo_book_gen.py`
### rstest

Found in:
- `Cargo.toml`
- `tests/integration_tests.rs`
### run

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### runner

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### runs

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### rust

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
- `repo_book_gen.py`
### rustfmt

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
### rustup

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`

## S

### STDIN

Found in:
- `src/main.rs`
### Some

Found in:
- `src/main.rs`
### safely

Found in:
- `repo_book_gen.py`
### salsify

Found in:
- `.github/workflows/release.yaml`
### save

Found in:
- `repo_book_gen.py`
### save_manifest

Found in:
- `repo_book_gen.py`
### saving

Found in:
- `repo_book_gen.py`
### scan

Found in:
- `repo_book_gen.py`
### scan_files

Found in:
- `repo_book_gen.py`
### scanned

Found in:
- `repo_book_gen.py`
### scanning

Found in:
- `repo_book_gen.py`
### scope

Found in:
- `CODE_OF_CONDUCT.md`
### script

Found in:
- `repo_book_gen.py`
### scripts

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### scripts_dir

Found in:
- `scripts/get_version.sh`
### search

Found in:
- `repo_book_gen.py`
### sec_fmt

Found in:
- `src/main.rs`
### second

Found in:
- `src/main.rs`
### secondsformat

Found in:
- `src/main.rs`
### secrets

Found in:
- `.github/workflows/release.yaml`
### secs

Found in:
- `src/main.rs`
### section

Found in:
- `repo_book_gen.py`
### sections

Found in:
- `repo_book_gen.py`
### security

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### sed

Found in:
- `.github/workflows/release.yaml`
### self

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### sell

Found in:
- `LICENSE`
### series

Found in:
- `CODE_OF_CONDUCT.md`
### serious

Found in:
- `CODE_OF_CONDUCT.md`
### set

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### setting

Found in:
- `CODE_OF_CONDUCT.md`
### setup

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### sex

Found in:
- `CODE_OF_CONDUCT.md`
### sexual

Found in:
- `CODE_OF_CONDUCT.md`
### sexualized

Found in:
- `CODE_OF_CONDUCT.md`
### sha

Found in:
- `repo_book_gen.py`
### sha256

Found in:
- `repo_book_gen.py`
### shall

Found in:
- `LICENSE`
### shell

Found in:
- `.github/workflows/build.yaml`
### shields

Found in:
- `README.md`
### short

Found in:
- `src/main.rs`
### significant

Found in:
- `repo_book_gen.py`
### single

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### size

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### skip

Found in:
- `src/main.rs`
### skipped

Found in:
- `repo_book_gen.py`
### skipped_files

Found in:
- `repo_book_gen.py`
### slack

Found in:
- `CONTRIBUTING.md`
### snake_case

Found in:
- `repo_book_gen.py`
### social

Found in:
- `CODE_OF_CONDUCT.md`
### socio

Found in:
- `CODE_OF_CONDUCT.md`
### softprops

Found in:
- `.github/workflows/release.yaml`
### software

Found in:
- `LICENSE`
### some

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `src/main.rs`
### sort

Found in:
- `CODE_OF_CONDUCT.md`
### sorted

Found in:
- `repo_book_gen.py`
### source

Found in:
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### spaces

Found in:
- `CODE_OF_CONDUCT.md`
### specific

Found in:
- `repo_book_gen.py`
### specifications

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
### specified

Found in:
- `CODE_OF_CONDUCT.md`
### split_last

Found in:
- `src/main.rs`
### splitlines

Found in:
- `repo_book_gen.py`
### src

Found in:
- `Cargo.toml`
### st_size

Found in:
- `repo_book_gen.py`
### stable

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### standards

Found in:
- `CODE_OF_CONDUCT.md`
### start

Found in:
- `repo_book_gen.py`
- `tests/integration_tests.rs`
### starting

Found in:
- `repo_book_gen.py`
### startswith

Found in:
- `repo_book_gen.py`
### stat

Found in:
- `repo_book_gen.py`
### statement

Found in:
- `repo_book_gen.py`
### static

Found in:
- `src/main.rs`
### status

Found in:
- `CODE_OF_CONDUCT.md`
### std

Found in:
- `src/main.rs`
### stderr

Found in:
- `tests/integration_tests.rs`
### stdin

Found in:
- `src/main.rs`
- `tests/integration_tests.rs`
### stdout

Found in:
- `src/main.rs`
- `tests/integration_tests.rs`
### step

Found in:
- `repo_book_gen.py`
### steps

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### str

Found in:
- `repo_book_gen.py`
- `src/main.rs`
- `tests/integration_tests.rs`
### strategy

Found in:
- `.github/workflows/build.yaml`
### string

Found in:
- `src/main.rs`
### strings

Found in:
- `Cargo.toml`
- `src/main.rs`
### strip

Found in:
- `repo_book_gen.py`
### struct

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### structure

Found in:
- `repo_book_gen.py`
### style

Found in:
- `.github/pull_request_template.md`
### sub

Found in:
- `repo_book_gen.py`
### sub_content

Found in:
- `repo_book_gen.py`
### sub_path

Found in:
- `repo_book_gen.py`
### subdir

Found in:
- `repo_book_gen.py`
### subdirectories

Found in:
- `repo_book_gen.py`
### subdirs

Found in:
- `repo_book_gen.py`
### subfolders

Found in:
- `repo_book_gen.py`
### subject

Found in:
- `LICENSE`
### sublicense

Found in:
- `LICENSE`
### substantial

Found in:
- `LICENSE`
### success

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `tests/integration_tests.rs`
### such

Found in:
- `CODE_OF_CONDUCT.md`
### suffix

Found in:
- `repo_book_gen.py`
### summary

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### support

Found in:
- `CONTRIBUTING.md`
- `Cargo.toml`
### sustained

Found in:
- `CODE_OF_CONDUCT.md`
### svg

Found in:
- `README.md`
### sys

Found in:
- `repo_book_gen.py`

## T

### tag

Found in:
- `.github/workflows/release.yaml`
### tag_name

Found in:
- `.github/workflows/release.yaml`
### take

Found in:
- `CODE_OF_CONDUCT.md`
### taking

Found in:
- `CONTRIBUTING.md`
### target

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
### temporary

Found in:
- `CODE_OF_CONDUCT.md`
### terms

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### test

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `repo_book_gen.py`
- `scripts/test.sh`
- `tests/integration_tests.rs`
### test_

Found in:
- `repo_book_gen.py`
### test_info

Found in:
- `repo_book_gen.py`
### test_localize

Found in:
- `tests/integration_tests.rs`
### test_replacement

Found in:
- `tests/integration_tests.rs`
### tested

Found in:
- `.github/pull_request_template.md`
### testing

Found in:
- `repo_book_gen.py`
### tests

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
- `repo_book_gen.py`
### text

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### text_after

Found in:
- `src/main.rs`
### text_before

Found in:
- `src/main.rs`
### text_iter

Found in:
- `src/main.rs`
### text_start

Found in:
- `src/main.rs`
### than

Found in:
- `src/main.rs`
### thank

Found in:
- `CONTRIBUTING.md`
### that

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `src/main.rs`
### their

Found in:
- `CODE_OF_CONDUCT.md`
### these

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
### they

Found in:
- `CODE_OF_CONDUCT.md`
### this

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/main.rs`
### those

Found in:
- `CODE_OF_CONDUCT.md`
### threading

Found in:
- `repo_book_gen.py`
### threatening

Found in:
- `CODE_OF_CONDUCT.md`
### threshold

Found in:
- `src/main.rs`
### threshold_years

Found in:
- `src/main.rs`
### through

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### time

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `src/main.rs`
- `tests/integration_tests.rs`
### time_ns

Found in:
- `src/main.rs`
### timestamp

Found in:
- `src/main.rs`
### timestamp_end

Found in:
- `repo_book_gen.py`
### timestamp_nanos

Found in:
- `src/main.rs`
### timestamp_start

Found in:
- `repo_book_gen.py`
### timestamps

Found in:
- `Cargo.toml`
- `README.md`
- `src/main.rs`
### timezone

Found in:
- `src/main.rs`
### token

Found in:
- `.github/workflows/release.yaml`
### toml

Found in:
- `.gitignore`
- `repo_book_gen.py`
- `scripts/get_version.sh`
### tool

Found in:
- `Cargo.toml`
### toolchain

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### tort

Found in:
- `LICENSE`
### total

Found in:
- `repo_book_gen.py`
### toward

Found in:
- `CODE_OF_CONDUCT.md`
### trait

Found in:
- `repo_book_gen.py`
### translations

Found in:
- `CODE_OF_CONDUCT.md`
### trolling

Found in:
- `CODE_OF_CONDUCT.md`
### true

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/main.rs`
### truncate

Found in:
- `repo_book_gen.py`
### truncated

Found in:
- `repo_book_gen.py`
### truncated_content

Found in:
- `repo_book_gen.py`
### try

Found in:
- `repo_book_gen.py`
### tuple

Found in:
- `repo_book_gen.py`
### twitter

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### txt

Found in:
- `repo_book_gen.py`
### type

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### types

Found in:
- `.github/workflows/release.yaml`
### typescript

Found in:
- `repo_book_gen.py`
### typing

Found in:
- `repo_book_gen.py`

## U

### ubuntu

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### unacceptable

Found in:
- `CODE_OF_CONDUCT.md`
### under

Found in:
- `.github/pull_request_template.md`
### unicode

Found in:
- `tests/integration_tests.rs`
### unicodedecodeerror

Found in:
- `repo_book_gen.py`
### unique

Found in:
- `repo_book_gen.py`
### unit

Found in:
- `.github/pull_request_template.md`
### unittest

Found in:
- `repo_book_gen.py`
### unix

Found in:
- `Cargo.toml`
- `README.md`
### unknown

Found in:
- `repo_book_gen.py`
### unprofessional

Found in:
- `CODE_OF_CONDUCT.md`
### unsolicited

Found in:
- `CODE_OF_CONDUCT.md`
### untrusted

Found in:
- `repo_book_gen.py`
### unwelcome

Found in:
- `CODE_OF_CONDUCT.md`
### unwrap

Found in:
- `tests/integration_tests.rs`
### unwrap_or_else

Found in:
- `src/main.rs`
### update

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### updates

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### upload_url

Found in:
- `.github/workflows/release.yaml`
### upper

Found in:
- `repo_book_gen.py`
### upper_s

Found in:
- `src/main.rs`
### upstream

Found in:
- `CONTRIBUTING.md`
### url

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `repo_book_gen.py`
### usage

Found in:
- `repo_book_gen.py`
### used

Found in:
- `src/main.rs`
### uses

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### using

Found in:
- `CODE_OF_CONDUCT.md`
### usize

Found in:
- `src/main.rs`
### usr

Found in:
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### utc

Found in:
- `src/main.rs`
### utf

Found in:
- `repo_book_gen.py`
### utilities

Found in:
- `Cargo.toml`
### utility

Found in:
- `README.md`

## V

### value

Found in:
- `Cargo.toml`
### value_name

Found in:
- `src/main.rs`
### var

Found in:
- `repo_book_gen.py`
### variables

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### vars

Found in:
- `.github/workflows/release.yaml`
### vec

Found in:
- `src/main.rs`
### venv

Found in:
- `repo_book_gen.py`
### verification

Found in:
- `repo_book_gen.py`
### verification_report

Found in:
- `repo_book_gen.py`
### verify

Found in:
- `.github/pull_request_template.md`
### version

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `Cargo.toml`
- `README.md`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### via

Found in:
- `CODE_OF_CONDUCT.md`
### viewpoints

Found in:
- `CODE_OF_CONDUCT.md`
### violating

Found in:
- `CODE_OF_CONDUCT.md`
### violation

Found in:
- `CODE_OF_CONDUCT.md`
### visible

Found in:
- `CODE_OF_CONDUCT.md`

## W

### walk

Found in:
- `repo_book_gen.py`
### walkthrough

Found in:
- `repo_book_gen.py`
### warn

Found in:
- `tests/integration_tests.rs`
### warning

Found in:
- `CODE_OF_CONDUCT.md`
### warnings

Found in:
- `.github/pull_request_template.md`
- `scripts/lint.sh`
### warranties

Found in:
- `LICENSE`
### warranty

Found in:
- `LICENSE`
### ways

Found in:
- `CODE_OF_CONDUCT.md`
### welcome

Found in:
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### welcoming

Found in:
- `CODE_OF_CONDUCT.md`
### well

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### were

Found in:
- `CODE_OF_CONDUCT.md`
### what

Found in:
- `CODE_OF_CONDUCT.md`
### when

Found in:
- `CODE_OF_CONDUCT.md`
### whether

Found in:
- `LICENSE`
### which

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### while

Found in:
- `CONTRIBUTING.md`
- `src/main.rs`
### whom

Found in:
- `LICENSE`
### why

Found in:
- `CODE_OF_CONDUCT.md`
### wiki

Found in:
- `CODE_OF_CONDUCT.md`
### will

Found in:
- `.gitignore`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### windows

Found in:
- `.github/workflows/build.yaml`
### with

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/main.rs`
### within

Found in:
- `CODE_OF_CONDUCT.md`
### without

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### words

Found in:
- `repo_book_gen.py`
### words_estimated

Found in:
- `repo_book_gen.py`
### work

Found in:
- `.github/pull_request_template.md`
### workflow_dispatch

Found in:
- `.github/workflows/release.yaml`
### workflow_run

Found in:
- `.github/workflows/release.yaml`
### workflows

Found in:
- `.github/workflows/release.yaml`
- `README.md`
### works

Found in:
- `.github/pull_request_template.md`
### world

Found in:
- `repo_book_gen.py`
### would

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### wrap_help

Found in:
- `Cargo.toml`
### write

Found in:
- `repo_book_gen.py`
- `src/main.rs`
### write_all

Found in:
- `src/main.rs`
### write_stdin

Found in:
- `tests/integration_tests.rs`
### writer

Found in:
- `src/main.rs`
### writing

Found in:
- `src/main.rs`
### written

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### www

Found in:
- `CODE_OF_CONDUCT.md`

## Y

### yaml

Found in:
- `README.md`
- `repo_book_gen.py`
### years

Found in:
- `src/main.rs`
### yml

Found in:
- `repo_book_gen.py`
### your

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `repo_book_gen.py`

## Z

### zach

Found in:
- `LICENSE`

## _

### __init__

Found in:
- `repo_book_gen.py`
### __main__

Found in:
- `repo_book_gen.py`
### __name__

Found in:
- `repo_book_gen.py`
### __pycache__

Found in:
- `repo_book_gen.py`
### _docs

Found in:
- `repo_book_gen.py`
### _kw

Found in:
- `repo_book_gen.py`
