# Keywords: Cargo.toml

## Extracted Keywords

Total keywords extracted: 92


### A

- **anyhow**: Identifier found in `Cargo.toml`
- **apache**: Identifier found in `Cargo.toml`
- **api**: Identifier found in `Cargo.toml`
- **args**: Identifier found in `Cargo.toml`
- **async**: Identifier found in `Cargo.toml`
- **authentication**: Identifier found in `Cargo.toml`
- **authors**: Identifier found in `Cargo.toml`

### B

- **bindings**: Identifier found in `Cargo.toml`
- **build**: Identifier found in `Cargo.toml`
- **builder**: Identifier found in `Cargo.toml`

### C

- **cargo**: Identifier found in `Cargo.toml`
- **categories**: Identifier found in `Cargo.toml`
- **category_slugs**: Identifier found in `Cargo.toml`
- **cfg**: Identifier found in `Cargo.toml`
- **checksums**: Identifier found in `Cargo.toml`
- **clap**: Identifier found in `Cargo.toml`
- **client**: Identifier found in `Cargo.toml`
- **com**: Identifier found in `Cargo.toml`
- **compression**: Identifier found in `Cargo.toml`
- **crates**: Identifier found in `Cargo.toml`

### D

- **data**: Identifier found in `Cargo.toml`
- **databento**: Identifier found in `Cargo.toml`
- **dbn**: Identifier found in `Cargo.toml`
- **default**: Identifier found in `Cargo.toml`
- **dep**: Identifier found in `Cargo.toml`
- **dependencies**: Identifier found in `Cargo.toml`
- **derive**: Identifier found in `Cargo.toml`
- **description**: Identifier found in `Cargo.toml`
- **dev**: Identifier found in `Cargo.toml`
- **doc**: Identifier found in `Cargo.toml`
- **docs**: Identifier found in `Cargo.toml`
- **docsrs**: Identifier found in `Cargo.toml`
- **document**: Identifier found in `Cargo.toml`

### E

- **edition**: Identifier found in `Cargo.toml`

### F

- **false**: Identifier found in `Cargo.toml`
- **features**: Identifier found in `Cargo.toml`
- **finance**: Identifier found in `Cargo.toml`
- **full**: Identifier found in `Cargo.toml`
- **futures**: Identifier found in `Cargo.toml`

### G

- **github**: Identifier found in `Cargo.toml`

### H

- **hex**: Identifier found in `Cargo.toml`
- **historical**: Identifier found in `Cargo.toml`
- **https**: Identifier found in `Cargo.toml`
- **human**: Identifier found in `Cargo.toml`

### J

- **json**: Identifier found in `Cargo.toml`

### K

- **keywords**: Identifier found in `Cargo.toml`

### L

- **library**: Identifier found in `Cargo.toml`
- **license**: Identifier found in `Cargo.toml`
- **live**: Identifier found in `Cargo.toml`
- **locally**: Identifier found in `Cargo.toml`

### M

- **macros**: Identifier found in `Cargo.toml`
- **market**: Identifier found in `Cargo.toml`
- **maximum**: Identifier found in `Cargo.toml`
- **metadata**: Identifier found in `Cargo.toml`

### N

- **name**: Identifier found in `Cargo.toml`
- **net**: Identifier found in `Cargo.toml`
- **nightly**: Identifier found in `Cargo.toml`

### O

- **official**: Identifier found in `Cargo.toml`
- **open**: Identifier found in `Cargo.toml`
- **optional**: Identifier found in `Cargo.toml`

### P

- **package**: Identifier found in `Cargo.toml`
- **parsing**: Identifier found in `Cargo.toml`

### R

- **readable**: Identifier found in `Cargo.toml`
- **real**: Identifier found in `Cargo.toml`
- **repository**: Identifier found in `Cargo.toml`
- **reqwest**: Identifier found in `Cargo.toml`
- **rstest**: Identifier found in `Cargo.toml`
- **rustdoc**: Identifier found in `Cargo.toml`
- **rustdocflags**: Identifier found in `Cargo.toml`

### S

- **serde**: Identifier found in `Cargo.toml`
- **serde_json**: Identifier found in `Cargo.toml`
- **sha2**: Identifier found in `Cargo.toml`
- **stream**: Identifier found in `Cargo.toml`
- **subscriber**: Identifier found in `Cargo.toml`
- **support**: Identifier found in `Cargo.toml`

### T

- **tempfile**: Identifier found in `Cargo.toml`
- **thiserror**: Identifier found in `Cargo.toml`
- **tick**: Identifier found in `Cargo.toml`
- **time**: Identifier found in `Cargo.toml`
- **tls**: Identifier found in `Cargo.toml`
- **tokio**: Identifier found in `Cargo.toml`
- **tracing**: Identifier found in `Cargo.toml`
- **trading**: Identifier found in `Cargo.toml`
- **trait**: Identifier found in `Cargo.toml`
- **true**: Identifier found in `Cargo.toml`
- **typed**: Identifier found in `Cargo.toml`

### U

- **used**: Identifier found in `Cargo.toml`
- **util**: Identifier found in `Cargo.toml`
- **utils**: Identifier found in `Cargo.toml`

### V

- **version**: Identifier found in `Cargo.toml`

### W

- **wiremock**: Identifier found in `Cargo.toml`

### Z

- **zstd**: Identifier found in `Cargo.toml`
