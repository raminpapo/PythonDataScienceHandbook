# Verification Report

Generated: 2025-11-18T22:28:55.536858

## Summary

- **Files scanned**: 41
- **Docs created**: 181
- **Errors**: 0
- **Skipped files**: 0
- **Binary files**: 24

## Binary Files

- `tests/data/test_data.definition.dbn`
- `tests/data/test_data.definition.dbn.zst`
- `tests/data/test_data.imbalance.dbn`
- `tests/data/test_data.imbalance.dbn.zst`
- `tests/data/test_data.mbo.dbn`
- `tests/data/test_data.mbo.dbn.zst`
- `tests/data/test_data.mbp-1.dbn`
- `tests/data/test_data.mbp-1.dbn.zst`
- `tests/data/test_data.mbp-10.dbn`
- `tests/data/test_data.mbp-10.dbn.zst`
- `tests/data/test_data.ohlcv-1d.dbn`
- `tests/data/test_data.ohlcv-1d.dbn.zst`
- `tests/data/test_data.ohlcv-1h.dbn`
- `tests/data/test_data.ohlcv-1h.dbn.zst`
- `tests/data/test_data.ohlcv-1m.dbn`
- `tests/data/test_data.ohlcv-1m.dbn.zst`
- `tests/data/test_data.ohlcv-1s.dbn`
- `tests/data/test_data.ohlcv-1s.dbn.zst`
- `tests/data/test_data.statistics.dbn`
- `tests/data/test_data.statistics.dbn.zst`
- `tests/data/test_data.tbbo.dbn`
- `tests/data/test_data.tbbo.dbn.zst`
- `tests/data/test_data.trades.dbn`
- `tests/data/test_data.trades.dbn.zst`

## Skipped Files


## Errors

No errors encountered.
