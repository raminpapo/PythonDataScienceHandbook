# Documentation: docs

## Folder Overview

**Path**: `docs`
**Files**: 17
**Subdirectories**: 5

## Purpose

This folder is located at `docs`.

## Contents Summary

### Subdirectories:
- `docs/`
- `examples/`
- `scripts/`
- `src/`
- `tests/`

### Files:
- `CHANGELOG.md_docs.md` (30075 bytes)
- `CHANGELOG.md_kw.md` (42029 bytes)
- `CODE_OF_CONDUCT.md_docs.md` (6443 bytes)
- `CODE_OF_CONDUCT.md_kw.md` (16011 bytes)
- `CONTRIBUTING.md_docs.md` (1510 bytes)
- `CONTRIBUTING.md_kw.md` (2255 bytes)
- `Cargo.toml_docs.md` (2875 bytes)
- `Cargo.toml_kw.md` (4608 bytes)
- `LICENSE_docs.md` (10452 bytes)
- `LICENSE_kw.md` (16993 bytes)
- `README.md_docs.md` (6132 bytes)
- `README.md_kw.md` (8772 bytes)
- `doc.md` (480 bytes)
- `index.md` (499 bytes)
- `repo_book_gen.py_docs.md` (30109 bytes)
- `repo_book_gen.py_kw.md` (25541 bytes)
- `sub.md` (74 bytes)
