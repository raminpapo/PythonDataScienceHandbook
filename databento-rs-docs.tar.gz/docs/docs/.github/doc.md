# Documentation: docs/.github

## Folder Overview

**Path**: `docs/.github`
**Files**: 5
**Subdirectories**: 2

## Purpose

This folder is located at `docs/.github`.

## Contents Summary

### Subdirectories:
- `ISSUE_TEMPLATE/`
- `workflows/`

### Files:
- `doc.md` (282 bytes)
- `index.md` (212 bytes)
- `pull_request_template.md_docs.md` (2336 bytes)
- `pull_request_template.md_kw.md` (6165 bytes)
- `sub.md` (74 bytes)
