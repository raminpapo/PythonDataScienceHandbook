# Index: docs/.github/ISSUE_TEMPLATE

## Contents


### Files

- [bug_report.md_docs.md](./bug_report.md_docs.md_docs.md)
- [bug_report.md_kw.md](./bug_report.md_kw.md_docs.md)
- [config.yml_docs.md](./config.yml_docs.md_docs.md)
- [config.yml_kw.md](./config.yml_kw.md_docs.md)
- [doc.md](./doc.md_docs.md)
- [feature_request.md_docs.md](./feature_request.md_docs.md_docs.md)
- [feature_request.md_kw.md](./feature_request.md_kw.md_docs.md)
- [index.md](./index.md_docs.md)
- [sub.md](./sub.md_docs.md)
