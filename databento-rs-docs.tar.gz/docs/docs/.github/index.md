# Index: docs/.github

## Contents

### Subdirectories

- [ISSUE_TEMPLATE/](./ISSUE_TEMPLATE/index.md)
- [workflows/](./workflows/index.md)

### Files

- [doc.md](./doc.md_docs.md)
- [index.md](./index.md_docs.md)
- [pull_request_template.md_docs.md](./pull_request_template.md_docs.md_docs.md)
- [pull_request_template.md_kw.md](./pull_request_template.md_kw.md_docs.md)
- [sub.md](./sub.md_docs.md)
