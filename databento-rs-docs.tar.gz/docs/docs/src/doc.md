# Documentation: docs/src

## Folder Overview

**Path**: `docs/src`
**Files**: 12
**Subdirectories**: 3

## Purpose

This folder is located at `docs/src`.

## Contents Summary

### Subdirectories:
- `historical/`
- `live/`
- `reference/`

### Files:
- `deserialize.rs_docs.md` (2918 bytes)
- `deserialize.rs_kw.md` (3252 bytes)
- `error.rs_docs.md` (4066 bytes)
- `error.rs_kw.md` (5199 bytes)
- `historical.rs_docs.md` (9292 bytes)
- `historical.rs_kw.md` (9037 bytes)
- `lib.rs_docs.md` (10442 bytes)
- `lib.rs_kw.md` (11066 bytes)
- `live.rs_docs.md` (7866 bytes)
- `live.rs_kw.md` (10973 bytes)
- `reference.rs_docs.md` (9298 bytes)
- `reference.rs_kw.md` (10555 bytes)
