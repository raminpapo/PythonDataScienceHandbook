# Index: docs/src/historical

## Contents


### Files

- [batch.rs_docs.md](./batch.rs_docs.md_docs.md)
- [batch.rs_kw.md](./batch.rs_kw.md_docs.md)
- [client.rs_docs.md](./client.rs_docs.md_docs.md)
- [client.rs_kw.md](./client.rs_kw.md_docs.md)
- [metadata.rs_docs.md](./metadata.rs_docs.md_docs.md)
- [metadata.rs_kw.md](./metadata.rs_kw.md_docs.md)
- [symbology.rs_docs.md](./symbology.rs_docs.md_docs.md)
- [symbology.rs_kw.md](./symbology.rs_kw.md_docs.md)
- [timeseries.rs_docs.md](./timeseries.rs_docs.md_docs.md)
- [timeseries.rs_kw.md](./timeseries.rs_kw.md_docs.md)
