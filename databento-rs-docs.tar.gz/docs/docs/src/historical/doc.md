# Documentation: docs/src/historical

## Folder Overview

**Path**: `docs/src/historical`
**Files**: 10
**Subdirectories**: 0

## Purpose

This folder is located at `docs/src/historical`.

## Contents Summary


### Files:
- `batch.rs_docs.md` (34587 bytes)
- `batch.rs_kw.md` (31291 bytes)
- `client.rs_docs.md` (13088 bytes)
- `client.rs_kw.md` (17233 bytes)
- `metadata.rs_docs.md` (25176 bytes)
- `metadata.rs_kw.md` (22091 bytes)
- `symbology.rs_docs.md` (10676 bytes)
- `symbology.rs_kw.md` (13782 bytes)
- `timeseries.rs_docs.md` (16863 bytes)
- `timeseries.rs_kw.md` (20844 bytes)
