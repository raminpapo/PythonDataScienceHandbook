# Documentation: docs/src/reference

## Folder Overview

**Path**: `docs/src/reference`
**Files**: 8
**Subdirectories**: 0

## Purpose

This folder is located at `docs/src/reference`.

## Contents Summary


### Files:
- `adjustment.rs_docs.md` (10759 bytes)
- `adjustment.rs_kw.md` (20739 bytes)
- `corporate.rs_docs.md` (25451 bytes)
- `corporate.rs_kw.md` (37694 bytes)
- `enums.rs_docs.md` (83228 bytes)
- `enums.rs_kw.md` (70103 bytes)
- `security.rs_docs.md` (16435 bytes)
- `security.rs_kw.md` (24322 bytes)
