# Index: docs/src

## Contents

### Subdirectories

- [historical/](./historical/index.md)
- [live/](./live/index.md)
- [reference/](./reference/index.md)

### Files

- [deserialize.rs_docs.md](./deserialize.rs_docs.md_docs.md)
- [deserialize.rs_kw.md](./deserialize.rs_kw.md_docs.md)
- [error.rs_docs.md](./error.rs_docs.md_docs.md)
- [error.rs_kw.md](./error.rs_kw.md_docs.md)
- [historical.rs_docs.md](./historical.rs_docs.md_docs.md)
- [historical.rs_kw.md](./historical.rs_kw.md_docs.md)
- [lib.rs_docs.md](./lib.rs_docs.md_docs.md)
- [lib.rs_kw.md](./lib.rs_kw.md_docs.md)
- [live.rs_docs.md](./live.rs_docs.md_docs.md)
- [live.rs_kw.md](./live.rs_kw.md_docs.md)
- [reference.rs_docs.md](./reference.rs_docs.md_docs.md)
- [reference.rs_kw.md](./reference.rs_kw.md_docs.md)
