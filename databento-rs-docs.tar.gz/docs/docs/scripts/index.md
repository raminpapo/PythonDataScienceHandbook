# Index: docs/scripts

## Contents


### Files

- [build.sh_docs.md](./build.sh_docs.md_docs.md)
- [build.sh_kw.md](./build.sh_kw.md_docs.md)
- [doc.md](./doc.md_docs.md)
- [format.sh_docs.md](./format.sh_docs.md_docs.md)
- [format.sh_kw.md](./format.sh_kw.md_docs.md)
- [get_version.sh_docs.md](./get_version.sh_docs.md_docs.md)
- [get_version.sh_kw.md](./get_version.sh_kw.md_docs.md)
- [index.md](./index.md_docs.md)
- [lint.sh_docs.md](./lint.sh_docs.md_docs.md)
- [lint.sh_kw.md](./lint.sh_kw.md_docs.md)
- [sub.md](./sub.md_docs.md)
- [test.sh_docs.md](./test.sh_docs.md_docs.md)
- [test.sh_kw.md](./test.sh_kw.md_docs.md)
