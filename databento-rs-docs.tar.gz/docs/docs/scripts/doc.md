# Documentation: docs/scripts

## Folder Overview

**Path**: `docs/scripts`
**Files**: 13
**Subdirectories**: 0

## Purpose

This folder is located at `docs/scripts`.

## Contents Summary


### Files:
- `build.sh_docs.md` (1041 bytes)
- `build.sh_kw.md` (887 bytes)
- `doc.md` (313 bytes)
- `format.sh_docs.md` (858 bytes)
- `format.sh_kw.md` (726 bytes)
- `get_version.sh_docs.md` (977 bytes)
- `get_version.sh_kw.md` (980 bytes)
- `index.md` (218 bytes)
- `lint.sh_docs.md` (1066 bytes)
- `lint.sh_kw.md` (1521 bytes)
- `sub.md` (74 bytes)
- `test.sh_docs.md` (891 bytes)
- `test.sh_kw.md` (591 bytes)
