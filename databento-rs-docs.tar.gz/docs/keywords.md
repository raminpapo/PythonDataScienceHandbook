# Global Keyword Index

Total unique keywords: 4101


## A

### ALL_SYMBOLS

Found in:
- `src/lib.rs`
### API_KEY

Found in:
- `src/historical.rs`
### API_KEY_LENGTH

Found in:
- `src/lib.rs`
### API_VERSION

Found in:
- `src/historical.rs`
### Action

Found in:
- `src/reference/enums.rs`
### AddToForm

Found in:
- `src/historical.rs`
### AddToQuery

Found in:
- `src/historical.rs`
### AdjustmentFactor

Found in:
- `src/reference/adjustment.rs`
### AdjustmentFactorsClient

Found in:
- `src/reference/adjustment.rs`
### AdjustmentStatus

Found in:
- `src/reference/enums.rs`
### ApiError

Found in:
- `src/error.rs`
### ApiErrorResponse

Found in:
- `src/historical/client.rs`
### ApiKey

Found in:
- `src/lib.rs`
### Args

Found in:
- `examples/live_smoke_test.rs`
### AuthRequest

Found in:
- `src/live/protocol.rs`
### AuthResponse

Found in:
- `src/live/protocol.rs`
### aa89xslbv

Found in:
- `src/historical/batch.rs`
### aapl

Found in:
- `examples/reference.rs`
- `src/historical/timeseries.rs`
### abcdefghijklmnopqrstuvwxyz

Found in:
- `src/lib.rs`
### about

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `CODE_OF_CONDUCT.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/metadata.rs`
### above

Found in:
- `LICENSE`
- `repo_book_gen.py`
### abusive

Found in:
- `CODE_OF_CONDUCT.md`
### acc

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
### accept

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### acceptable

Found in:
- `CODE_OF_CONDUCT.md`
### acceptance

Found in:
- `LICENSE`
### accepted

Found in:
- `src/reference/corporate.rs`
### accepting

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### accessed

Found in:
- `src/historical/client.rs`
- `src/reference.rs`
### account

Found in:
- `CODE_OF_CONDUCT.md`
- `src/reference/enums.rs`
### achieve

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### acquired

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### across

Found in:
- `CHANGELOG.md`
### act

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### acting

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### action

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### actions

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `README.md`
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### active

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### activity

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### acts

Found in:
- `LICENSE`
### actual

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `repo_book_gen.py`
### actual_size

Found in:
- `src/historical/batch.rs`
### adapted

Found in:
- `CODE_OF_CONDUCT.md`
### add

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `LICENSE`
- `README.md`
- `repo_book_gen.py`
- `src/live/client.rs`
### add_argument

Found in:
- `repo_book_gen.py`
### add_to_form

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### add_to_query

Found in:
- `src/historical/metadata.rs`
- `src/historical.rs`
### added

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### addendum

Found in:
- `LICENSE`
### adding

Found in:
- `CHANGELOG.md`
### additional

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### additions

Found in:
- `CHANGELOG.md`
- `LICENSE`
### addr

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live.rs`
### address

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `examples/live_smoke_test.rs`
- `src/live.rs`
### addrs

Found in:
- `src/live.rs`
### adds

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
### addtoform

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### addtoquery

Found in:
- `src/historical/metadata.rs`
- `src/historical.rs`
### adex

Found in:
- `src/reference/enums.rs`
### adjustment

Found in:
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### adjustment_factors

Found in:
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference.rs`
### adjustmentfactor

Found in:
- `src/reference/adjustment.rs`
### adjustmentfactorsclient

Found in:
- `src/reference/adjustment.rs`
- `src/reference.rs`
### adjustments

Found in:
- `examples/reference.rs`
### adjustmentstatus

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### adp

Found in:
- `src/reference/enums.rs`
### advanced

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
### advances

Found in:
- `CODE_OF_CONDUCT.md`
### advised

Found in:
- `LICENSE`
### aed

Found in:
- `src/reference/enums.rs`
### affected

Found in:
- `CODE_OF_CONDUCT.md`
### afghanis

Found in:
- `src/reference/enums.rs`
### afghanistan

Found in:
- `src/reference/enums.rs`
### afn

Found in:
- `src/reference/enums.rs`
### africa

Found in:
- `src/reference/enums.rs`
### african

Found in:
- `src/reference/enums.rs`
### after

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### against

Found in:
- `CHANGELOG.md`
- `LICENSE`
### age

Found in:
- `CODE_OF_CONDUCT.md`
### agent

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### agents

Found in:
- `CHANGELOG.md`
### aggression

Found in:
- `CODE_OF_CONDUCT.md`
### agm

Found in:
- `src/reference/enums.rs`
### ago

Found in:
- `CHANGELOG.md`
### agree

Found in:
- `LICENSE`
### agreed

Found in:
- `LICENSE`
### agreement

Found in:
- `LICENSE`
### aid

Found in:
- `CHANGELOG.md`
### ain

Found in:
- `src/reference/security.rs`
### albania

Found in:
- `src/reference/enums.rs`
### albanian

Found in:
- `src/reference/enums.rs`
### algeria

Found in:
- `src/reference/enums.rs`
### algerian

Found in:
- `src/reference/enums.rs`
### algorithm

Found in:
- `src/historical/batch.rs`
### alias

Found in:
- `src/error.rs`
### aligned

Found in:
- `CODE_OF_CONDUCT.md`
### all_symbols

Found in:
- `src/historical/symbology.rs`
- `src/lib.rs`
### alleging

Found in:
- `LICENSE`
### allotment

Found in:
- `src/reference/enums.rs`
### allow

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### allowed

Found in:
- `CODE_OF_CONDUCT.md`
### allowing

Found in:
- `src/reference/corporate.rs`
### almost

Found in:
- `src/historical/timeseries.rs`
### alone

Found in:
- `LICENSE`
### along

Found in:
- `CHANGELOG.md`
- `LICENSE`
### alongside

Found in:
- `LICENSE`
### alpha

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### alphabetically

Found in:
- `repo_book_gen.py`
### already

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### also

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
### always

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
### amd

Found in:
- `src/reference/enums.rs`
### america

Found in:
- `src/reference/enums.rs`
### american

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### amortisation

Found in:
- `src/reference/enums.rs`
### amount

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### amt

Found in:
- `src/reference/enums.rs`
### analysis

Found in:
- `repo_book_gen.py`
### and_then

Found in:
- `src/historical/client.rs`
### andorra

Found in:
- `src/reference/enums.rs`
### ands

Found in:
- `src/reference/corporate.rs`
### ang

Found in:
- `src/reference/enums.rs`
### anga

Found in:
- `src/reference/enums.rs`
### angola

Found in:
- `src/reference/enums.rs`
### anguilla

Found in:
- `src/reference/enums.rs`
### anl

Found in:
- `src/reference/enums.rs`
### ann

Found in:
- `src/reference/enums.rs`
### annotations

Found in:
- `LICENSE`
### announcement

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### annual

Found in:
- `src/reference/enums.rs`
### another

Found in:
- `src/error.rs`
- `src/historical/symbology.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### answers

Found in:
- `CODE_OF_CONDUCT.md`
### anticipated

Found in:
- `src/reference/corporate.rs`
### antigua

Found in:
- `src/reference/enums.rs`
### antilles

Found in:
- `src/reference/enums.rs`
### any

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
### anyhow

Found in:
- `Cargo.toml`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
### anything

Found in:
- `scripts/format.sh`
### aoa

Found in:
- `src/reference/enums.rs`
### apache

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
- `LICENSE`
- `README.md`
### api

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### api________________________

Found in:
- `src/historical.rs`
### api_err

Found in:
- `src/historical/client.rs`
### api_key

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### api_key_env_var

Found in:
- `examples/live_smoke_test.rs`
### api_key_length

Found in:
- `src/lib.rs`
### api_version

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### apierror

Found in:
- `src/error.rs`
- `src/historical/client.rs`
### apierrorresponse

Found in:
- `src/historical/client.rs`
### apikey

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### apis

Found in:
- `CHANGELOG.md`
### apologizing

Found in:
- `CODE_OF_CONDUCT.md`
### apology

Found in:
- `CODE_OF_CONDUCT.md`
### appear

Found in:
- `LICENSE`
### appearance

Found in:
- `CODE_OF_CONDUCT.md`
### appears

Found in:
- `repo_book_gen.py`
### append

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### append_body

Found in:
- `.github/workflows/release.yaml`
### appendix

Found in:
- `LICENSE`
### appends

Found in:
- `CHANGELOG.md`
### applicable

Found in:
- `LICENSE`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### application

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/reference.rs`
### applied

Found in:
- `src/historical/timeseries.rs`
### applies

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### apply

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### appointed

Found in:
- `CODE_OF_CONDUCT.md`
### appropriate

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### appropriateness

Found in:
- `LICENSE`
### arab

Found in:
- `src/reference/enums.rs`
### arabia

Found in:
- `src/reference/enums.rs`
### arabian

Found in:
- `src/reference/enums.rs`
### arc

Found in:
- `src/historical/symbology.rs`
- `src/live.rs`
### arch

Found in:
- `src/lib.rs`
### argentina

Found in:
- `src/reference/enums.rs`
### argentine

Found in:
- `src/reference/enums.rs`
### argparse

Found in:
- `repo_book_gen.py`
### args

Found in:
- `Cargo.toml`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/live/protocol.rs`
### argument

Found in:
- `src/error.rs`
### argumentparser

Found in:
- `repo_book_gen.py`
### arguments

Found in:
- `examples/split_symbols.rs`
### ariary

Found in:
- `src/reference/enums.rs`
### arising

Found in:
- `LICENSE`
### armenia

Found in:
- `src/reference/enums.rs`
### armenian

Found in:
- `src/reference/enums.rs`
### around

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### arr

Found in:
- `src/reference/enums.rs`
### arrangement

Found in:
- `src/reference/enums.rs`
### ars

Found in:
- `src/reference/enums.rs`
### aruba

Found in:
- `src/reference/enums.rs`
### aruban

Found in:
- `src/reference/enums.rs`
### as_bytes

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### as_deref

Found in:
- `src/live/client.rs`
### as_mut

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
### as_ref

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### as_slice

Found in:
- `src/live/client.rs`
### as_str

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### as_u16

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### as_url

Found in:
- `src/historical/client.rs`
- `src/historical.rs`
- `src/reference.rs`
### ascii

Found in:
- `CHANGELOG.md`
- `src/lib.rs`
### asis

Found in:
- `src/historical/timeseries.rs`
### ask

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### asmt

Found in:
- `CHANGELOG.md`
### aspi

Found in:
- `CHANGELOG.md`
### aspn

Found in:
- `CHANGELOG.md`
### asref

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/reference/enums.rs`
### assert

Found in:
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### assert_eq

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### asserted

Found in:
- `LICENSE`
### asset

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/reference/corporate.rs`
### asset_cstr_len

Found in:
- `CHANGELOG.md`
### assets

Found in:
- `src/reference/enums.rs`
### assign

Found in:
- `src/reference/enums.rs`
### assigned

Found in:
- `src/historical/metadata.rs`
### assimilation

Found in:
- `src/reference/enums.rs`
### assm

Found in:
- `src/reference/enums.rs`
### associated

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### assume

Found in:
- `LICENSE`
### assume_utc

Found in:
- `src/deserialize.rs`
- `src/historical.rs`
- `src/reference.rs`
### async

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### async_compression

Found in:
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### async_decode_metadata_with_fsm

Found in:
- `src/live/client.rs`
### async_decode_record_ref_with_fsm

Found in:
- `src/live/client.rs`
### asyncbufreadext

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### asyncdbndecoder

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### asyncdbnencoder

Found in:
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### asyncdbnmetadataencoder

Found in:
- `src/live/client.rs`
### asyncdbnrecorddecoder

Found in:
- `CHANGELOG.md`
### asyncdecoder

Found in:
- `CHANGELOG.md`
### asyncdecoderecord

Found in:
- `CHANGELOG.md`
### asyncdecoderecordref

Found in:
- `CHANGELOG.md`
### asyncdynbufwriter

Found in:
- `CHANGELOG.md`
### asyncdynwriter

Found in:
- `CHANGELOG.md`
### asyncencoderecord

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
### asyncencoderecordref

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### asyncencoderecordtextext

Found in:
- `CHANGELOG.md`
### asynchronous

Found in:
- `README.md`
### asyncjsonencoder

Found in:
- `CHANGELOG.md`
### asyncreadext

Found in:
- `src/historical/timeseries.rs`
### asyncrecorddecoder

Found in:
- `CHANGELOG.md`
### asyncseek

Found in:
- `CHANGELOG.md`
### asyncskipbytes

Found in:
- `CHANGELOG.md`
### asyncwriteext

Found in:
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### ats

Found in:
- `src/reference/enums.rs`
### attached

Found in:
- `LICENSE`
### attacks

Found in:
- `CODE_OF_CONDUCT.md`
### attempts

Found in:
- `src/live/client.rs`
- `src/live.rs`
### attention

Found in:
- `CODE_OF_CONDUCT.md`
### attribute

Found in:
- `CHANGELOG.md`
### attribution

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### auction

Found in:
- `src/reference/enums.rs`
### auction_time

Found in:
- `CHANGELOG.md`
### aud

Found in:
- `src/reference/enums.rs`
### australia

Found in:
- `src/reference/enums.rs`
### australian

Found in:
- `src/reference/enums.rs`
### austria

Found in:
- `src/reference/enums.rs`
### austrian

Found in:
- `src/reference/enums.rs`
### auth

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### auth_end

Found in:
- `src/live/client.rs`
### auth_keys

Found in:
- `src/live/protocol.rs`
### auth_line

Found in:
- `src/live/client.rs`
### auth_req

Found in:
- `src/live/protocol.rs`
### auth_resp

Found in:
- `src/live/protocol.rs`
### auth_start

Found in:
- `src/live/client.rs`
### authenticate

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### authenticates

Found in:
- `src/live/client.rs`
### authentication

Found in:
- `Cargo.toml`
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### author

Found in:
- `CONTRIBUTING.md`
### authority

Found in:
- `.github/pull_request_template.md`
### authorized

Found in:
- `LICENSE`
### authors

Found in:
- `Cargo.toml`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### authorship

Found in:
- `LICENSE`
### authrequest

Found in:
- `src/live/protocol.rs`
### authresponse

Found in:
- `src/live/protocol.rs`
### availability

Found in:
- `src/historical/metadata.rs`
### available

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### avoiding

Found in:
- `CODE_OF_CONDUCT.md`
### await

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### awg

Found in:
- `src/reference/enums.rs`
### azerbaijan

Found in:
- `src/reference/enums.rs`
### azerbaijani

Found in:
- `src/reference/enums.rs`
### azn

Found in:
- `src/reference/enums.rs`

## B

### BODY

Found in:
- `src/historical/client.rs`
### BUCKET_ID_LENGTH

Found in:
- `src/lib.rs`
### BatchClient

Found in:
- `src/historical/batch.rs`
### BatchFileDesc

Found in:
- `src/historical/batch.rs`
### BatchJob

Found in:
- `src/historical/batch.rs`
### BusinessErrorDetails

Found in:
- `src/historical/client.rs`
### bad

Found in:
- `src/error.rs`
- `src/historical/client.rs`
### bad_arg

Found in:
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### bad_gateway

Found in:
- `src/historical/client.rs`
### badargument

Found in:
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### badge

Found in:
- `README.md`
### bahamas

Found in:
- `src/reference/enums.rs`
### bahrain

Found in:
- `src/reference/enums.rs`
### bahraini

Found in:
- `src/reference/enums.rs`
### baht

Found in:
- `src/reference/enums.rs`
### bail

Found in:
- `examples/split_symbols.rs`
### balboa

Found in:
- `src/reference/enums.rs`
### bam

Found in:
- `src/reference/enums.rs`
### ban

Found in:
- `CODE_OF_CONDUCT.md`
### bangladesh

Found in:
- `src/reference/enums.rs`
### bankruptcy

Found in:
- `src/reference/enums.rs`
### barbados

Found in:
- `src/reference/enums.rs`
### barbuda

Found in:
- `src/reference/enums.rs`
### bars

Found in:
- `CHANGELOG.md`
### base

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/reference.rs`
### base_url

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference.rs`
### based

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/reference/enums.rs`
### bash

Found in:
- `.github/workflows/build.yaml`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### basic_auth

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### basics

Found in:
- `src/live.rs`
### basis

Found in:
- `LICENSE`
- `src/reference/enums.rs`
### basket

Found in:
- `src/reference/enums.rs`
### batch

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### batchclient

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### batchdownload

Found in:
- `src/historical/batch.rs`
### batched

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### batchfiledesc

Found in:
- `src/historical/batch.rs`
### batchjob

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### bats

Found in:
- `src/reference/adjustment.rs`
### bbcc

Found in:
- `src/reference/enums.rs`
### bbd

Found in:
- `src/reference/enums.rs`
### bbec

Found in:
- `src/reference/enums.rs`
### bbed

Found in:
- `src/reference/enums.rs`
### bbg000brm1n5

Found in:
- `src/reference/security.rs`
### bbg000brm1y3

Found in:
- `src/reference/security.rs`
### bbg00b9rg1j6

Found in:
- `src/reference/corporate.rs`
### bbg00b9rg1w1

Found in:
- `src/reference/corporate.rs`
### bbg_comp_id

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### bbg_comp_ticker

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### bbo

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### bbomsg

Found in:
- `CHANGELOG.md`
### bbotrades

Found in:
- `CHANGELOG.md`
### bbrd

Found in:
- `src/reference/enums.rs`
### bceao

Found in:
- `src/reference/enums.rs`
### bdt

Found in:
- `src/reference/enums.rs`
### beac

Found in:
- `src/reference/enums.rs`
### because

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
### become

Found in:
- `src/reference/corporate.rs`
### becomes

Found in:
- `src/reference/corporate.rs`
### been

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### bef

Found in:
- `src/reference/enums.rs`
### before

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference.rs`
### began

Found in:
- `src/historical/batch.rs`
### begin

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
### begins

Found in:
- `src/reference/corporate.rs`
### begun

Found in:
- `src/historical/batch.rs`
### behalf

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### behavior

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### being

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
### belarus

Found in:
- `src/reference/enums.rs`
### belarusian

Found in:
- `src/reference/enums.rs`
### belarussian

Found in:
- `src/reference/enums.rs`
### belgian

Found in:
- `src/reference/enums.rs`
### belgium

Found in:
- `src/reference/enums.rs`
### belize

Found in:
- `src/reference/enums.rs`
### below

Found in:
- `LICENSE`
### beneficial

Found in:
- `LICENSE`
### benefit

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### benin

Found in:
- `src/reference/enums.rs`
### bermuda

Found in:
- `src/reference/enums.rs`
### best

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### better

Found in:
- `CHANGELOG.md`
### between

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
### bgn

Found in:
- `src/reference/enums.rs`
### bhd

Found in:
- `src/reference/enums.rs`
### bhm

Found in:
- `src/reference/enums.rs`
### bhutan

Found in:
- `src/reference/enums.rs`
### bhutanese

Found in:
- `src/reference/enums.rs`
### bids

Found in:
- `src/reference/corporate.rs`
### bif

Found in:
- `src/reference/enums.rs`
### bifurcated

Found in:
- `src/reference/enums.rs`
### bill_id

Found in:
- `CHANGELOG.md`
### billable

Found in:
- `src/historical/metadata.rs`
### billed_size

Found in:
- `src/historical/batch.rs`
### billing

Found in:
- `src/historical/batch.rs`
### bills

Found in:
- `src/reference/corporate.rs`
### bim

Found in:
- `src/reference/enums.rs`
### bimonthly

Found in:
- `src/reference/enums.rs`
### bin

Found in:
- `README.md`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### binary

Found in:
- `README.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### binary_files

Found in:
- `repo_book_gen.py`
### bind

Found in:
- `LICENSE`
- `src/live/client.rs`
### binding

Found in:
- `src/reference/corporate.rs`
### bindings

Found in:
- `Cargo.toml`
### birr

Found in:
- `src/reference/enums.rs`
### bissau

Found in:
- `src/reference/enums.rs`
### bit

Found in:
- `CHANGELOG.md`
### bits

Found in:
- `CHANGELOG.md`
### bkrp

Found in:
- `src/reference/enums.rs`
### blank_issues_enabled

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### block

Found in:
- `repo_book_gen.py`
### bloomberg

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### blue

Found in:
- `README.md`
### bmd

Found in:
- `src/reference/enums.rs`
### bnd

Found in:
- `src/reference/enums.rs`
### bo1

Found in:
- `src/historical.rs`
### bob

Found in:
- `src/reference/enums.rs`
### body

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/client.rs`
### body_contains

Found in:
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### body_path

Found in:
- `.github/workflows/release.yaml`
### body_string_contains

Found in:
- `src/lib.rs`
### bodycontainsmatcher

Found in:
- `src/lib.rs`
### bolivar

Found in:
- `src/reference/enums.rs`
### bolivares

Found in:
- `src/reference/enums.rs`
### bolivia

Found in:
- `src/reference/enums.rs`
### boliviano

Found in:
- `src/reference/enums.rs`
### bon

Found in:
- `src/reference/enums.rs`
### bond

Found in:
- `src/reference/enums.rs`
### bonus

Found in:
- `src/reference/enums.rs`
### book

Found in:
- `repo_book_gen.py`
### book_path

Found in:
- `repo_book_gen.py`
### bool

Found in:
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### bootstrap

Found in:
- `repo_book_gen.py`
### borqs

Found in:
- `src/reference/corporate.rs`
### borrowedformatitem

Found in:
- `src/deserialize.rs`
- `src/historical.rs`
### bosnia

Found in:
- `src/reference/enums.rs`
### boston

Found in:
- `src/historical.rs`
### both

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/batch.rs`
- `src/live.rs`
### botswana

Found in:
- `src/reference/enums.rs`
### bouvet

Found in:
- `src/reference/enums.rs`
### bov

Found in:
- `src/reference/enums.rs`
### box

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/reference.rs`
- `src/live/client.rs`
### branch

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### branches

Found in:
- `.github/workflows/release.yaml`
### brazil

Found in:
- `src/reference/enums.rs`
### brazilian

Found in:
- `src/reference/enums.rs`
### break

Found in:
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/live/client.rs`
### breaking

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
### british

Found in:
- `src/reference/enums.rs`
### brl

Found in:
- `src/reference/enums.rs`
### brn

Found in:
- `src/historical/timeseries.rs`
### broken_intra_doc_links

Found in:
- `src/lib.rs`
### brqs

Found in:
- `src/reference/corporate.rs`
### brunei

Found in:
- `src/reference/enums.rs`
### bsd

Found in:
- `src/reference/enums.rs`
### bsw

Found in:
- `src/reference/enums.rs`
### btn

Found in:
- `src/reference/enums.rs`
### btreemap

Found in:
- `CHANGELOG.md`
### bucket

Found in:
- `src/live/client.rs`
### bucket_id

Found in:
- `src/lib.rs`
- `src/live/protocol.rs`
### bucket_id_length

Found in:
- `src/lib.rs`
### buf_size

Found in:
- `src/live/client.rs`
- `src/live.rs`
### buffer

Found in:
- `CHANGELOG.md`
- `src/live.rs`
### buffer_size

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live.rs`
### bufread

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### bufreader

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### bufwriter

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### bug

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
### bugs

Found in:
- `src/live/client.rs`
### build

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
### builder

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
### builders

Found in:
- `CHANGELOG.md`
### builds

Found in:
- `.github/pull_request_template.md`
### built

Found in:
- `README.md`
### bulgaria

Found in:
- `src/reference/enums.rs`
### bulgarian

Found in:
- `src/reference/enums.rs`
### burkina

Found in:
- `src/reference/enums.rs`
### burundi

Found in:
- `src/reference/enums.rs`
### business

Found in:
- `src/historical/client.rs`
- `src/reference/corporate.rs`
### businesserrordetails

Found in:
- `src/historical/client.rs`
### buyback

Found in:
- `src/reference/enums.rs`
### bwp

Found in:
- `src/reference/enums.rs`
### byn

Found in:
- `src/reference/enums.rs`
### byr

Found in:
- `src/reference/enums.rs`
### byte

Found in:
- `src/live/protocol.rs`
### bytes

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### bytes_stream

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### bytes_written

Found in:
- `repo_book_gen.py`
### bzd

Found in:
- `src/reference/enums.rs`

## C

### CHUNK_SIZE

Found in:
- `src/lib.rs`
### CME

Found in:
- `README.md`
### Challenge

Found in:
- `src/live/protocol.rs`
### Client

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/reference.rs`
### ClientBuilder

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### CorporateAction

Found in:
- `src/reference/corporate.rs`
### CorporateActionsClient

Found in:
- `src/reference/corporate.rs`
### Country

Found in:
- `src/reference/enums.rs`
### Currency

Found in:
- `src/reference/enums.rs`
### c_char

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### ca8667961053

Found in:
- `src/reference/security.rs`
### cache

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### cad

Found in:
- `src/reference/enums.rs`
### caicos

Found in:
- `src/reference/enums.rs`
### calculate

Found in:
- `src/reference/corporate.rs`
### calculation

Found in:
- `src/reference/adjustment.rs`
### calculations

Found in:
- `src/reference/corporate.rs`
### caledonia

Found in:
- `src/reference/enums.rs`
### calendar

Found in:
- `src/reference/corporate.rs`
### call

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### called

Found in:
- `src/live/client.rs`
### calling

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### cambodia

Found in:
- `src/reference/enums.rs`
### cambodian

Found in:
- `src/reference/enums.rs`
### camelcase

Found in:
- `repo_book_gen.py`
### cameroon

Found in:
- `src/reference/enums.rs`
### canada

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### canadian

Found in:
- `src/reference/enums.rs`
### cancel

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### cancellation

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### cancelled

Found in:
- `src/reference/enums.rs`
### cannot

Found in:
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### capdist

Found in:
- `src/reference/enums.rs`
### cape

Found in:
- `src/reference/enums.rs`
### capital

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### caprd

Found in:
- `src/reference/enums.rs`
### cargo

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
- `Cargo.toml`
- `README.md`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### cargo_manifest_dir

Found in:
- `src/lib.rs`
### cargo_pkg_version

Found in:
- `src/lib.rs`
### cargo_registry_token

Found in:
- `.github/workflows/release.yaml`
### caribbean

Found in:
- `src/reference/enums.rs`
### carry

Found in:
- `LICENSE`
### case

Found in:
- `repo_book_gen.py`
- `src/historical/timeseries.rs`
- `src/reference/corporate.rs`
### cases

Found in:
- `src/live/client.rs`
### cash

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### cashandstock

Found in:
- `src/reference/enums.rs`
### categories

Found in:
- `Cargo.toml`
### category_slugs

Found in:
- `Cargo.toml`
### catse

Found in:
- `src/reference/security.rs`
### cause

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### cayman

Found in:
- `src/reference/enums.rs`
### cbbo

Found in:
- `CHANGELOG.md`
### cbbo1s

Found in:
- `CHANGELOG.md`
### cbbomsg

Found in:
- `CHANGELOG.md`
### cda

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### cdf

Found in:
- `src/reference/enums.rs`
### cdi

Found in:
- `src/reference/enums.rs`
### ceases

Found in:
- `src/reference/corporate.rs`
### cedi

Found in:
- `src/reference/enums.rs`
### cells

Found in:
- `repo_book_gen.py`
### center

Found in:
- `src/historical/batch.rs`
### central

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### cents

Found in:
- `src/reference/enums.rs`
### certificate

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### cfa

Found in:
- `src/reference/enums.rs`
### cfg

Found in:
- `Cargo.toml`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
### cfg_attr

Found in:
- `src/lib.rs`
### cfi

Found in:
- `src/reference/security.rs`
### cfp

Found in:
- `src/reference/enums.rs`
### cgm

Found in:
- `src/reference/enums.rs`
### chad

Found in:
- `src/reference/enums.rs`
### challenge

Found in:
- `src/live/protocol.rs`
### challenge_key

Found in:
- `src/live/protocol.rs`
### change

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### changed

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### changelog

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
### changes

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `src/reference/corporate.rs`
### changing

Found in:
- `CHANGELOG.md`
### channel

Found in:
- `CHANGELOG.md`
### channel_id

Found in:
- `CHANGELOG.md`
### channels

Found in:
- `CODE_OF_CONDUCT.md`
### chapter

Found in:
- `repo_book_gen.py`
### char

Found in:
- `src/reference/enums.rs`
### character

Found in:
- `LICENSE`
- `src/live/client.rs`
### characteristics

Found in:
- `CODE_OF_CONDUCT.md`
### characters

Found in:
- `src/lib.rs`
- `src/live/client.rs`
### charge

Found in:
- `LICENSE`
### chars

Found in:
- `src/live/client.rs`
### check

Found in:
- `repo_book_gen.py`
- `scripts/format.sh`
### check_http_error

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### check_http_error_non_json

Found in:
- `src/historical/client.rs`
### check_if_exists

Found in:
- `src/historical/batch.rs`
### check_warnings

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### checklist

Found in:
- `.github/pull_request_template.md`
### checkout

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### checksum

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### checksums

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
### chess

Found in:
- `src/reference/enums.rs`
### chf

Found in:
- `src/reference/enums.rs`
### chile

Found in:
- `src/reference/enums.rs`
### chilean

Found in:
- `src/reference/enums.rs`
### china

Found in:
- `src/reference/enums.rs`
### chinese

Found in:
- `src/reference/enums.rs`
### choice

Found in:
- `src/reference/adjustment.rs`
### choose

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
### christmas

Found in:
- `src/reference/enums.rs`
### chunk

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/lib.rs`
### chunk_size

Found in:
- `src/lib.rs`
- `src/live/client.rs`
### chunking

Found in:
- `CHANGELOG.md`
### chunks

Found in:
- `examples/split_symbols.rs`
- `src/lib.rs`
### cic

Found in:
- `src/reference/security.rs`
### cik

Found in:
- `src/reference/security.rs`
### city

Found in:
- `src/reference/enums.rs`
### claim

Found in:
- `LICENSE`
### claims

Found in:
- `LICENSE`
### clap

Found in:
- `Cargo.toml`
- `examples/live_smoke_test.rs`
### clarifying

Found in:
- `CODE_OF_CONDUCT.md`
### clarity

Found in:
- `CODE_OF_CONDUCT.md`
### class

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/enums.rs`
### class_count

Found in:
- `repo_book_gen.py`
### classes

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### classification

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### classify

Found in:
- `repo_book_gen.py`
### classify_file

Found in:
- `repo_book_gen.py`
### classifying

Found in:
- `repo_book_gen.py`
### clean

Found in:
- `CHANGELOG.md`
### clear

Found in:
- `src/live/protocol.rs`
### clf

Found in:
- `src/reference/enums.rs`
### cli

Found in:
- `CHANGELOG.md`
### client

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
### client_task

Found in:
- `src/live/client.rs`
### clientbuilder

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### clients

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/error.rs`
### clippy

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `scripts/lint.sh`
- `src/historical/timeseries.rs`
- `src/lib.rs`
### clone

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### close

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
### close_date

Found in:
- `src/reference/corporate.rs`
### closed

Found in:
- `CHANGELOG.md`
- `src/historical.rs`
- `src/live/client.rs`
### closes

Found in:
- `src/live/client.rs`
### closing

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### clp

Found in:
- `src/reference/enums.rs`
### cls

Found in:
- `repo_book_gen.py`
### clsac

Found in:
- `src/reference/enums.rs`
### clz3

Found in:
- `src/lib.rs`
### cmbp1

Found in:
- `CHANGELOG.md`
### cmbp_1

Found in:
- `CHANGELOG.md`
### cme

Found in:
- `README.md`
### cmp

Found in:
- `src/historical/batch.rs`
### cms

Found in:
- `CHANGELOG.md`
### cmssymbol

Found in:
- `CHANGELOG.md`
### cny

Found in:
- `src/reference/enums.rs`
### coast

Found in:
- `src/reference/enums.rs`
### cocos

Found in:
- `src/reference/enums.rs`
### code

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### code_of_conduct

Found in:
- `CODE_OF_CONDUCT.md`
### codebase

Found in:
- `CONTRIBUTING.md`
### codes

Found in:
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### collect

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### collections

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### colombia

Found in:
- `src/reference/enums.rs`
### colombian

Found in:
- `src/reference/enums.rs`
### colon

Found in:
- `src/reference/enums.rs`
### color

Found in:
- `README.md`
### com

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `scripts/lint.sh`
- `src/historical.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### combination

Found in:
- `LICENSE`
### combined

Found in:
- `CHANGELOG.md`
### combining

Found in:
- `repo_book_gen.py`
### command

Found in:
- `.github/workflows/release.yaml`
- `README.md`
### comments

Found in:
- `CODE_OF_CONDUCT.md`
### commercial

Found in:
- `LICENSE`
### commit

Found in:
- `.github/workflows/release.yaml`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### commits

Found in:
- `CODE_OF_CONDUCT.md`
### commodities

Found in:
- `src/reference/enums.rs`
### commodityspot

Found in:
- `CHANGELOG.md`
### common

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
### common_words

Found in:
- `repo_book_gen.py`
### communicate

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### communication

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### community

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `README.md`
### comoro

Found in:
- `src/reference/enums.rs`
### comoros

Found in:
- `src/reference/enums.rs`
### company

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### compat

Found in:
- `CHANGELOG.md`
### compatibility

Found in:
- `CHANGELOG.md`
### compatible

Found in:
- `CHANGELOG.md`
### compiled

Found in:
- `LICENSE`
### compiles

Found in:
- `examples/historical.rs`
- `examples/live.rs`
### complaints

Found in:
- `CODE_OF_CONDUCT.md`
### complementary

Found in:
- `src/reference/security.rs`
### complete

Found in:
- `repo_book_gen.py`
- `src/live/protocol.rs`
### completed

Found in:
- `.github/workflows/release.yaml`
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
### completes

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### complies

Found in:
- `LICENSE`
### component

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### composed

Found in:
- `src/lib.rs`
- `src/live/client.rs`
### composite

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### comprehensive

Found in:
- `repo_book_gen.py`
### comprehensive_book

Found in:
- `repo_book_gen.py`
### compression

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### compute

Found in:
- `repo_book_gen.py`
### compute_repo_fingerprint

Found in:
- `repo_book_gen.py`
### computer

Found in:
- `LICENSE`
### concat

Found in:
- `src/lib.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### concatenation

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### concerns

Found in:
- `repo_book_gen.py`
### conclusion

Found in:
- `.github/workflows/release.yaml`
### concrete

Found in:
- `CHANGELOG.md`
### condition

Found in:
- `src/historical/metadata.rs`
### conditions

Found in:
- `LICENSE`
### conduct

Found in:
- `CODE_OF_CONDUCT.md`
### conducts

Found in:
- `src/live/protocol.rs`
### configurable

Found in:
- `CHANGELOG.md`
### configuration

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
- `src/historical/timeseries.rs`
### configured

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### configuring

Found in:
- `CHANGELOG.md`
### confirm

Found in:
- `.github/pull_request_template.md`
### conflicts

Found in:
- `src/live.rs`
### congo

Found in:
- `src/reference/enums.rs`
### congolese

Found in:
- `src/reference/enums.rs`
### conjunction

Found in:
- `src/historical/timeseries.rs`
### connect

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live.rs`
### connect_with_addr

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### connected

Found in:
- `src/live/client.rs`
### connection

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### consd

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### consequence

Found in:
- `CODE_OF_CONDUCT.md`
### consequences

Found in:
- `CODE_OF_CONDUCT.md`
### consequential

Found in:
- `LICENSE`
### consider

Found in:
- `src/historical/timeseries.rs`
### considered

Found in:
- `CODE_OF_CONDUCT.md`
### consistency

Found in:
- `CHANGELOG.md`
### consistent

Found in:
- `CHANGELOG.md`
- `LICENSE`
### consolidated

Found in:
- `CHANGELOG.md`
### consolidation

Found in:
- `src/reference/enums.rs`
### conspicuously

Found in:
- `LICENSE`
### const

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
### constant

Found in:
- `CHANGELOG.md`
### constants

Found in:
- `CHANGELOG.md`
### constitutes

Found in:
- `LICENSE`
### constructing

Found in:
- `CHANGELOG.md`
### constructive

Found in:
- `CODE_OF_CONDUCT.md`
### construed

Found in:
- `LICENSE`
### consts

Found in:
- `src/lib.rs`
### consumes

Found in:
- `src/live/protocol.rs`
### contact_links

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
### contain

Found in:
- `examples/split_symbols.rs`
### contained

Found in:
- `LICENSE`
### containers

Found in:
- `CHANGELOG.md`
### containing

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/lib.rs`
### contains

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/lib.rs`
- `src/live/client.rs`
### contains_key

Found in:
- `src/reference/corporate.rs`
### content

Found in:
- `LICENSE`
- `repo_book_gen.py`
### contents

Found in:
- `LICENSE`
- `repo_book_gen.py`
### context

Found in:
- `.github/pull_request_template.md`
- `examples/split_symbols.rs`
### contingent

Found in:
- `src/reference/enums.rs`
### continue

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
### continued

Found in:
- `CODE_OF_CONDUCT.md`
### continuous

Found in:
- `src/historical/symbology.rs`
### contract

Found in:
- `LICENSE`
### contribute

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### contributes

Found in:
- `CODE_OF_CONDUCT.md`
### contribution

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### contributions

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### contributor

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### contributors

Found in:
- `CODE_OF_CONDUCT.md`
### contributory

Found in:
- `LICENSE`
### control

Found in:
- `LICENSE`
- `src/live/protocol.rs`
### controlled

Found in:
- `LICENSE`
### controls

Found in:
- `src/live.rs`
### conv

Found in:
- `src/reference/enums.rs`
### convention

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### conventions

Found in:
- `README.md`
### conversion

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### conversions

Found in:
- `CHANGELOG.md`
- `LICENSE`
### convert

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/metadata.rs`
### converted

Found in:
- `CHANGELOG.md`
- `src/reference.rs`
### convertible

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### converting

Found in:
- `CHANGELOG.md`
### converts

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### cook

Found in:
- `src/reference/enums.rs`
### cop

Found in:
- `src/reference/enums.rs`
### copies

Found in:
- `LICENSE`
### copy

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### copyright

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### cordoba

Found in:
- `src/reference/enums.rs`
### core

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
### corporate

Found in:
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### corporate_actions

Found in:
- `examples/reference.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### corporateaction

Found in:
- `src/reference/corporate.rs`
### corporateactionsclient

Found in:
- `src/reference/corporate.rs`
- `src/reference.rs`
### correct

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
### correction

Found in:
- `CODE_OF_CONDUCT.md`
### corrective

Found in:
- `CODE_OF_CONDUCT.md`
### correctly

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
### correctness

Found in:
- `src/historical/metadata.rs`
### correspond

Found in:
- `src/historical/batch.rs`
### corresponding

Found in:
- `.github/pull_request_template.md`
### corrupted

Found in:
- `CHANGELOG.md`
### corrupting

Found in:
- `src/live/client.rs`
### cost

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### cost_usd

Found in:
- `src/historical/batch.rs`
### costa

Found in:
- `src/reference/enums.rs`
### cou

Found in:
- `src/reference/enums.rs`
### could

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### couldn

Found in:
- `examples/split_symbols.rs`
### count

Found in:
- `repo_book_gen.py`
- `src/historical/metadata.rs`
### counterclaim

Found in:
- `LICENSE`
### countries

Found in:
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### country

Found in:
- `examples/reference.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### court

Found in:
- `src/reference/enums.rs`
### covenant

Found in:
- `CODE_OF_CONDUCT.md`
### cpp

Found in:
- `repo_book_gen.py`
### cram

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### crate

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### crates

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `README.md`
### crc

Found in:
- `src/reference/enums.rs`
### create

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### create_dir_all

Found in:
- `src/historical/batch.rs`
### create_new

Found in:
- `examples/split_symbols.rs`
### created

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### creates

Found in:
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### creating

Found in:
- `examples/split_symbols.rs`
### creation

Found in:
- `src/reference/security.rs`
### credit

Found in:
- `CHANGELOG.md`
### croatia

Found in:
- `src/reference/enums.rs`
### croatian

Found in:
- `src/reference/enums.rs`
### cross

Found in:
- `LICENSE`
### csv

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### ctx

Found in:
- `src/reference/enums.rs`
### cuba

Found in:
- `src/reference/enums.rs`
### cuban

Found in:
- `src/reference/enums.rs`
### cup

Found in:
- `src/reference/enums.rs`
### curacao

Found in:
- `src/reference/enums.rs`
### currd

Found in:
- `src/reference/enums.rs`
### currencies

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### currency

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### current

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/batch.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live.rs`
### currently

Found in:
- `src/historical/symbology.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### cursor

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### cusip

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### custom

Found in:
- `CHANGELOG.md`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/enums.rs`
### customary

Found in:
- `LICENSE`
### customization

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
### cut

Found in:
- `scripts/get_version.sh`
- `src/reference/corporate.rs`
### cve

Found in:
- `src/reference/enums.rs`
### cvr

Found in:
- `src/reference/enums.rs`
### cyp

Found in:
- `src/reference/enums.rs`
### cypriot

Found in:
- `src/reference/enums.rs`
### cyprus

Found in:
- `src/reference/enums.rs`
### czech

Found in:
- `src/reference/enums.rs`
### czechoslovakia

Found in:
- `src/reference/enums.rs`
### czk

Found in:
- `src/reference/enums.rs`

## D

### DATASET

Found in:
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### DATE_FORMAT

Found in:
- `src/historical.rs`
### DBN

Found in:
- `CHANGELOG.md`
### DEFAULT_PORT

Found in:
- `src/live/protocol.rs`
### Databento

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### DatasetCondition

Found in:
- `src/historical/metadata.rs`
### DatasetConditionDetail

Found in:
- `src/historical/metadata.rs`
### DatasetRange

Found in:
- `src/historical/metadata.rs`
### DateRange

Found in:
- `src/historical.rs`
### DateTimeLike

Found in:
- `src/reference.rs`
### DateTimeRange

Found in:
- `src/historical.rs`
### Delivery

Found in:
- `src/historical/batch.rs`
### Dict

Found in:
- `repo_book_gen.py`
### DownloadParams

Found in:
- `src/historical/batch.rs`
### daily

Found in:
- `src/reference/enums.rs`
### dalasi

Found in:
- `src/reference/enums.rs`
### damages

Found in:
- `LICENSE`
### dangerous

Found in:
- `repo_book_gen.py`
### danish

Found in:
- `src/reference/enums.rs`
### darkblue

Found in:
- `README.md`
### darussalam

Found in:
- `src/reference/enums.rs`
### data

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
### databento

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
### databento_api_key

Found in:
- `README.md`
- `examples/live_smoke_test.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### dataset

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### dataset_subdomain

Found in:
- `src/live/protocol.rs`
### datasetcondition

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### datasetconditiondetail

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### datasetrange

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### datasets

Found in:
- `CHANGELOG.md`
### date

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/reference.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### date_format

Found in:
- `src/historical/metadata.rs`
- `src/historical.rs`
### date_info

Found in:
- `src/reference/corporate.rs`
### date_range

Found in:
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
### date_range_from_lt_day_duration

Found in:
- `src/historical.rs`
### date_str

Found in:
- `src/historical/metadata.rs`
### date_time_range

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### daterange

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
### dates

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/reference/corporate.rs`
### datetime

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### datetimelike

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### datetimerange

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### days

Found in:
- `src/historical/metadata.rs`
- `src/reference/enums.rs`
### days28

Found in:
- `src/reference/enums.rs`
### days35

Found in:
- `src/reference/enums.rs`
### dbg

Found in:
- `src/live/client.rs`
### dbn

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### dbn_err

Found in:
- `src/error.rs`
### dbn_version

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### dbnfsm

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### dbnmetadata

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### dbnv1

Found in:
- `CHANGELOG.md`
### dbnv2

Found in:
- `CHANGELOG.md`
### dbnv3

Found in:
- `CHANGELOG.md`
### dbnversion

Found in:
- `CHANGELOG.md`
### deadline

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### debug

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### debug_struct

Found in:
- `src/live/client.rs`
### decisions

Found in:
- `CODE_OF_CONDUCT.md`
### declaration

Found in:
- `.github/pull_request_template.md`
### declared

Found in:
- `src/reference/adjustment.rs`
### decode

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### decode_record

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### decode_record_ref

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### decode_records

Found in:
- `CHANGELOG.md`
### decode_ref

Found in:
- `CHANGELOG.md`
### decoded

Found in:
- `src/live.rs`
### decoder

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### decoders

Found in:
- `CHANGELOG.md`
### decodestream

Found in:
- `CHANGELOG.md`
### decoding

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### deducted

Found in:
- `src/reference/adjustment.rs`
### deduplicate

Found in:
- `src/reference/corporate.rs`
### deem

Found in:
- `CODE_OF_CONDUCT.md`
### deemed

Found in:
- `CODE_OF_CONDUCT.md`
### def

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
### default

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `repo_book_gen.py`
- `scripts/build.sh`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### default_buf_size

Found in:
- `src/live/client.rs`
### default_headers

Found in:
- `src/historical/client.rs`
- `src/reference.rs`
### default_option_flag

Found in:
- `src/reference/corporate.rs`
### default_port

Found in:
- `src/live/protocol.rs`
### default_value

Found in:
- `examples/live_smoke_test.rs`
### defaultdict

Found in:
- `repo_book_gen.py`
### defaults

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### defend

Found in:
- `LICENSE`
### deferred

Found in:
- `src/reference/enums.rs`
### defined

Found in:
- `LICENSE`
### definition

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `examples/split_symbols.rs`
### definitions

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `examples/split_symbols.rs`
### degraded

Found in:
- `src/historical/metadata.rs`
### delete

Found in:
- `.github/pull_request_template.md`
### deleted

Found in:
- `src/reference/enums.rs`
### deliberate

Found in:
- `LICENSE`
### delisted

Found in:
- `src/reference/enums.rs`
### delisting

Found in:
- `src/reference/security.rs`
### delisting_date

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### delivered

Found in:
- `src/historical/batch.rs`
### delivers

Found in:
- `CHANGELOG.md`
### delivery

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### delta

Found in:
- `CHANGELOG.md`
### dem

Found in:
- `src/reference/enums.rs`
### demerger

Found in:
- `src/reference/enums.rs`
### democratic

Found in:
- `src/reference/enums.rs`
### demonstrating

Found in:
- `CODE_OF_CONDUCT.md`
### denar

Found in:
- `src/reference/enums.rs`
### denmark

Found in:
- `src/reference/enums.rs`
### denominator

Found in:
- `src/reference/corporate.rs`
### denotes

Found in:
- `src/historical/metadata.rs`
### deny

Found in:
- `scripts/lint.sh`
- `src/lib.rs`
### dep

Found in:
- `Cargo.toml`
### dependencies

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `Cargo.toml`
### depending

Found in:
- `src/live/protocol.rs`
### depository

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### deprecated

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### deprecations

Found in:
- `CHANGELOG.md`
### depth

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
- `src/live/client.rs`
### derivative

Found in:
- `LICENSE`
### derive

Found in:
- `Cargo.toml`
- `examples/live_smoke_test.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### derived

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/client.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### deriving

Found in:
- `CHANGELOG.md`
### derogatory

Found in:
- `CODE_OF_CONDUCT.md`
### desc

Found in:
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### describe

Found in:
- `.github/pull_request_template.md`
### described

Found in:
- `src/historical/metadata.rs`
### describes

Found in:
- `src/reference/corporate.rs`
### describing

Found in:
- `LICENSE`
- `src/historical/metadata.rs`
### description

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### deserialize

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### deserialize_compression

Found in:
- `src/historical/batch.rs`
### deserialize_date

Found in:
- `src/historical/metadata.rs`
### deserialize_date_time

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### deserialize_json

Found in:
- `src/historical/client.rs`
### deserialize_opt_date

Found in:
- `src/historical/metadata.rs`
### deserialize_opt_date_time

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
### deserialize_opt_date_time_hash_map

Found in:
- `src/deserialize.rs`
- `src/reference/corporate.rs`
### deserialize_with

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### deserializeowned

Found in:
- `src/historical/client.rs`
### deserializer

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/reference/enums.rs`
### deserializers

Found in:
- `src/deserialize.rs`
### deserializing

Found in:
- `CHANGELOG.md`
### designated

Found in:
- `LICENSE`
### detail

Found in:
- `src/historical/client.rs`
- `src/reference/adjustment.rs`
### detailed

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `repo_book_gen.py`
### details

Found in:
- `.github/pull_request_template.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### detect

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### detected

Found in:
- `repo_book_gen.py`
### determine

Found in:
- `src/reference/corporate.rs`
### determine_gateway

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### determined

Found in:
- `repo_book_gen.py`
### determines

Found in:
- `CHANGELOG.md`
### determining

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### deutschmark

Found in:
- `src/reference/enums.rs`
### dev

Found in:
- `Cargo.toml`
### diagnostics

Found in:
- `CHANGELOG.md`
### dict

Found in:
- `repo_book_gen.py`
### didn

Found in:
- `CHANGELOG.md`
### different

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### differing

Found in:
- `CODE_OF_CONDUCT.md`
### digest

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### digits

Found in:
- `src/deserialize.rs`
### dinar

Found in:
- `src/reference/enums.rs`
### dinars

Found in:
- `src/reference/enums.rs`
### direct

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
### direction

Found in:
- `LICENSE`
### directly

Found in:
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### directories

Found in:
- `repo_book_gen.py`
### directory

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### dirham

Found in:
- `src/reference/enums.rs`
### dirname

Found in:
- `scripts/get_version.sh`
### dirs

Found in:
- `repo_book_gen.py`
### disability

Found in:
- `CODE_OF_CONDUCT.md`
### disable

Found in:
- `README.md`
### disclaimer

Found in:
- `LICENSE`
### disconnect

Found in:
- `src/live/client.rs`
### discounts

Found in:
- `src/historical/metadata.rs`
### discover

Found in:
- `src/historical/metadata.rs`
### discussing

Found in:
- `LICENSE`
### discussions

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CONTRIBUTING.md`
### disk

Found in:
- `CHANGELOG.md`
### disparagement

Found in:
- `CODE_OF_CONDUCT.md`
### dispatch

Found in:
- `CHANGELOG.md`
### display

Found in:
- `LICENSE`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### dissenters

Found in:
- `src/reference/enums.rs`
### dissentersrights

Found in:
- `src/reference/enums.rs`
### dist

Found in:
- `src/reference/enums.rs`
### distinct

Found in:
- `src/reference/corporate.rs`
### distinguish

Found in:
- `src/reference/adjustment.rs`
### distribute

Found in:
- `LICENSE`
### distributed

Found in:
- `LICENSE`
- `README.md`
- `src/reference/enums.rs`
### distribution

Found in:
- `LICENSE`
- `src/reference/enums.rs`
### div

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### diveb

Found in:
- `src/reference/enums.rs`
### diverse

Found in:
- `CODE_OF_CONDUCT.md`
### diversity

Found in:
- `CODE_OF_CONDUCT.md`
### divestment

Found in:
- `src/reference/enums.rs`
### divided

Found in:
- `src/reference/adjustment.rs`
### dividend

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### dividend_currency

Found in:
- `src/reference/adjustment.rs`
### dividends

Found in:
- `src/reference/corporate.rs`
### division

Found in:
- `src/reference/enums.rs`
### divrc

Found in:
- `src/reference/enums.rs`
### djf

Found in:
- `src/reference/enums.rs`
### djibouti

Found in:
- `src/reference/enums.rs`
### dkk

Found in:
- `src/reference/enums.rs`
### dly

Found in:
- `src/reference/enums.rs`
### dmrgr

Found in:
- `src/reference/enums.rs`
### dns

Found in:
- `CHANGELOG.md`
### dobra

Found in:
- `src/reference/enums.rs`
### doc

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
- `scripts/lint.sh`
- `src/error.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### doc_auto_cfg

Found in:
- `src/lib.rs`
### doc_content

Found in:
- `repo_book_gen.py`
### doc_name

Found in:
- `repo_book_gen.py`
### doc_path

Found in:
- `repo_book_gen.py`
### docs

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### docs_count

Found in:
- `repo_book_gen.py`
### docs_created

Found in:
- `repo_book_gen.py`
### docs_url

Found in:
- `src/error.rs`
- `src/historical/client.rs`
### docsrs

Found in:
- `Cargo.toml`
- `README.md`
- `src/lib.rs`
### docstring

Found in:
- `repo_book_gen.py`
### docstring_lines

Found in:
- `repo_book_gen.py`
### docstrings

Found in:
- `CHANGELOG.md`
### document

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `LICENSE`
### documentation

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
- `README.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
### documented

Found in:
- `repo_book_gen.py`
- `src/live/protocol.rs`
### does

Found in:
- `LICENSE`
- `scripts/lint.sh`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### doesn

Found in:
- `.github/workflows/release.yaml`
### dollar

Found in:
- `src/reference/enums.rs`
### dollars

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### domestic

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### dominica

Found in:
- `src/reference/enums.rs`
### dominican

Found in:
- `src/reference/enums.rs`
### don

Found in:
- `CONTRIBUTING.md`
- `src/historical/symbology.rs`
- `src/live/client.rs`
### done

Found in:
- `src/historical/batch.rs`
### dong

Found in:
- `src/reference/enums.rs`
### dop

Found in:
- `src/reference/enums.rs`
### down

Found in:
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### downgraded

Found in:
- `CHANGELOG.md`
### download

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### download_file

Found in:
- `src/historical/batch.rs`
### downloaded

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### downloading

Found in:
- `src/historical/batch.rs`
### downloadparams

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### downloads

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
### downstream

Found in:
- `CONTRIBUTING.md`
### dprcpdiv

Found in:
- `src/reference/enums.rs`
### drachma

Found in:
- `src/reference/enums.rs`
### dram

Found in:
- `src/reference/enums.rs`
### drawings

Found in:
- `src/reference/enums.rs`
### drchg

Found in:
- `src/reference/enums.rs`
### drip

Found in:
- `src/reference/enums.rs`
### drl

Found in:
- `src/reference/enums.rs`
### drt

Found in:
- `src/reference/enums.rs`
### dst

Found in:
- `src/reference/enums.rs`
### dt_offset_to_date_range

Found in:
- `src/historical.rs`
### dt_range

Found in:
- `src/historical/symbology.rs`
- `src/historical.rs`
### dt_str

Found in:
- `src/deserialize.rs`
### due

Found in:
- `CONTRIBUTING.md`
- `src/reference/corporate.rs`
### duebills_redemption_date

Found in:
- `src/reference/corporate.rs`
### dump

Found in:
- `repo_book_gen.py`
### dumps

Found in:
- `repo_book_gen.py`
### duration

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live.rs`
### during

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/timeseries.rs`
### dutch

Found in:
- `src/reference/enums.rs`
### dutchauct

Found in:
- `src/reference/enums.rs`
### dvst

Found in:
- `src/reference/enums.rs`
### dyn

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/reference.rs`
- `src/live/client.rs`
### dynwriter

Found in:
- `CHANGELOG.md`
### dzd

Found in:
- `src/reference/enums.rs`

## E

### ENC

Found in:
- `src/historical/metadata.rs`
### END

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### End

Found in:
- `src/reference.rs`
### Err

Found in:
- `examples/split_symbols.rs`
- `src/live/client.rs`
### Error

Found in:
- `src/error.rs`
### Event

Found in:
- `src/live/client.rs`
- `src/reference/enums.rs`
### EventSubType

Found in:
- `src/reference/enums.rs`
### Exchanges

Found in:
- `src/reference/corporate.rs`
### each

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
### earliest

Found in:
- `src/reference/corporate.rs`
### early

Found in:
- `src/reference/enums.rs`
### easier

Found in:
- `CHANGELOG.md`
### east

Found in:
- `src/reference/enums.rs`
### echo

Found in:
- `.github/workflows/release.yaml`
- `scripts/build.sh`
### econdary

Found in:
- `src/reference/security.rs`
### economic

Found in:
- `CODE_OF_CONDUCT.md`
### econv

Found in:
- `src/reference/enums.rs`
### ecs

Found in:
- `src/reference/enums.rs`
### ecuador

Found in:
- `src/reference/enums.rs`
### edit

Found in:
- `CODE_OF_CONDUCT.md`
### edition

Found in:
- `Cargo.toml`
### editorial

Found in:
- `LICENSE`
### edits

Found in:
- `CODE_OF_CONDUCT.md`
### education

Found in:
- `CODE_OF_CONDUCT.md`
### eek

Found in:
- `src/reference/enums.rs`
### eex

Found in:
- `CHANGELOG.md`
### effect

Found in:
- `src/reference/corporate.rs`
### effective

Found in:
- `.github/pull_request_template.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### effective_date

Found in:
- `src/reference/corporate.rs`
### efficient

Found in:
- `README.md`
### egm

Found in:
- `src/reference/enums.rs`
### egp

Found in:
- `src/reference/enums.rs`
### egypt

Found in:
- `src/reference/enums.rs`
### egyptian

Found in:
- `src/reference/enums.rs`
### either

Found in:
- `LICENSE`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### elaborations

Found in:
- `LICENSE`
### elect

Found in:
- `src/reference/corporate.rs`
### election

Found in:
- `src/reference/corporate.rs`
### electronic

Found in:
- `LICENSE`
### elif

Found in:
- `repo_book_gen.py`
### eligible

Found in:
- `src/reference/corporate.rs`
### eliminated

Found in:
- `CHANGELOG.md`
### else

Found in:
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/lib.rs`
### elsewhere

Found in:
- `CHANGELOG.md`
### email

Found in:
- `CODE_OF_CONDUCT.md`
### emirates

Found in:
- `src/reference/enums.rs`
### emitting

Found in:
- `CHANGELOG.md`
### empathy

Found in:
- `CODE_OF_CONDUCT.md`
### empty

Found in:
- `src/live/protocol.rs`
### enable

Found in:
- `src/historical/timeseries.rs`
### enabled

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/live.rs`
### enables

Found in:
- `README.md`
### enc

Found in:
- `src/historical/metadata.rs`
### encode

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### encode_all

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### encode_hex

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### encode_record_ref

Found in:
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### encode_record_with_sym

Found in:
- `CHANGELOG.md`
### encoded

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### encoded_response

Found in:
- `src/live/protocol.rs`
### encoder

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### encoders

Found in:
- `examples/split_symbols.rs`
### encodes

Found in:
- `CHANGELOG.md`
### encoding

Found in:
- `CHANGELOG.md`
- `README.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### encodings

Found in:
- `CHANGELOG.md`
### encountered

Found in:
- `repo_book_gen.py`
### encounters

Found in:
- `src/historical/batch.rs`
### end

Found in:
- `CHANGELOG.md`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### end_date

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/reference/corporate.rs`
### end_subscription_date

Found in:
- `src/reference/corporate.rs`
### ending

Found in:
- `src/live/client.rs`
### endofinterval

Found in:
- `CHANGELOG.md`
### endpoint

Found in:
- `src/reference/security.rs`
### endpoints

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### ends

Found in:
- `src/reference/corporate.rs`
### energy

Found in:
- `CHANGELOG.md`
### enforcement

Found in:
- `CODE_OF_CONDUCT.md`
### enforcing

Found in:
- `CODE_OF_CONDUCT.md`
### enhancement

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
### enhancements

Found in:
- `CHANGELOG.md`
### enhancemets

Found in:
- `CHANGELOG.md`
### ensures

Found in:
- `examples/historical.rs`
- `examples/live.rs`
### ent

Found in:
- `src/reference/enums.rs`
### entire

Found in:
- `CHANGELOG.md`
- `src/lib.rs`
### entities

Found in:
- `LICENSE`
### entitled

Found in:
- `src/reference/corporate.rs`
### entitlement

Found in:
- `src/reference/enums.rs`
### entitlements

Found in:
- `src/historical/metadata.rs`
### entity

Found in:
- `LICENSE`
- `src/reference/security.rs`
### entry

Found in:
- `repo_book_gen.py`
### enum

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
### enumerate

Found in:
- `repo_book_gen.py`
- `src/lib.rs`
- `src/live/protocol.rs`
### enumerations

Found in:
- `CHANGELOG.md`
### enums

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference.rs`
### env

Found in:
- `.github/workflows/release.yaml`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
- `src/lib.rs`
### environment

Found in:
- `CODE_OF_CONDUCT.md`
- `README.md`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### eobi

Found in:
- `CHANGELOG.md`
### epoch

Found in:
- `examples/live_smoke_test.rs`
### eprintln

Found in:
- `examples/split_symbols.rs`
### eqs

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### equal

Found in:
- `src/historical/batch.rs`
### equatorial

Found in:
- `src/reference/enums.rs`
### equities

Found in:
- `CHANGELOG.md`
### equity

Found in:
- `src/reference/enums.rs`
### equivalent

Found in:
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
### equs

Found in:
- `CHANGELOG.md`
### equsmini

Found in:
- `src/live/client.rs`
### eritrean

Found in:
- `src/reference/enums.rs`
### ern

Found in:
- `src/reference/enums.rs`
### err

Found in:
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### error

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `repo_book_gen.py`
- `src/deserialize.rs`
- `src/error.rs`
### error_for_status

Found in:
- `src/historical/timeseries.rs`
### errorcode

Found in:
- `CHANGELOG.md`
### errormsg

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
### errormsgv1

Found in:
- `CHANGELOG.md`
### errors

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
### escaping

Found in:
- `CHANGELOG.md`
### escudo

Found in:
- `src/reference/enums.rs`
### esm2

Found in:
- `src/historical/symbology.rs`
### esp

Found in:
- `src/reference/enums.rs`
### estimate

Found in:
- `repo_book_gen.py`
### estonia

Found in:
- `src/reference/enums.rs`
### estonian

Found in:
- `src/reference/enums.rs`
### eswatini

Found in:
- `src/reference/enums.rs`
### esz3

Found in:
- `src/lib.rs`
### etb

Found in:
- `src/reference/enums.rs`
### etc

Found in:
- `repo_book_gen.py`
- `src/reference/enums.rs`
### etf

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### ethiopia

Found in:
- `src/reference/enums.rs`
### ethiopian

Found in:
- `src/reference/enums.rs`
### ethnicity

Found in:
- `CODE_OF_CONDUCT.md`
### eur

Found in:
- `src/reference/enums.rs`
### eurex

Found in:
- `CHANGELOG.md`
### europe

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### european

Found in:
- `CHANGELOG.md`
### euros

Found in:
- `src/reference/enums.rs`
### eval

Found in:
- `repo_book_gen.py`
### even

Found in:
- `LICENSE`
### event

Found in:
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `examples/reference.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference.rs`
### event_action

Found in:
- `src/reference/corporate.rs`
### event_created_date

Found in:
- `src/reference/corporate.rs`
### event_date

Found in:
- `src/reference/corporate.rs`
### event_date_label

Found in:
- `src/reference/corporate.rs`
### event_id

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### event_info

Found in:
- `src/reference/corporate.rs`
### event_subtype

Found in:
- `src/reference/corporate.rs`
### event_unique_id

Found in:
- `src/reference/corporate.rs`
### eventdate

Found in:
- `src/reference/corporate.rs`
### events

Found in:
- `examples/reference.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### eventsubtype

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### every

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/enums.rs`
### everyone

Found in:
- `CODE_OF_CONDUCT.md`
### ex_date

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### example

Found in:
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/split_symbols.rs`
- `src/historical/symbology.rs`
### examples

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `CODE_OF_CONDUCT.md`
- `README.md`
- `repo_book_gen.py`
- `scripts/build.sh`
### except

Found in:
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/client.rs`
### exception

Found in:
- `repo_book_gen.py`
### exceptions

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### exchange

Found in:
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### exchanges

Found in:
- `src/reference/corporate.rs`
### exclude

Found in:
- `CHANGELOG.md`
### excluding

Found in:
- `LICENSE`
### exclusive

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### exdate

Found in:
- `src/reference/corporate.rs`
### exec

Found in:
- `repo_book_gen.py`
### executed

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
### execution

Found in:
- `repo_book_gen.py`
### exercise

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### exercised

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### exercising

Found in:
- `LICENSE`
### exhausted

Found in:
- `src/live/client.rs`
### exhaustive

Found in:
- `CHANGELOG.md`
### exhaustively

Found in:
- `CHANGELOG.md`
### exist

Found in:
- `.github/workflows/release.yaml`
### exist_ok

Found in:
- `repo_book_gen.py`
### existing

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `README.md`
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### exists

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### exit

Found in:
- `scripts/get_version.sh`
- `src/live/client.rs`
### exp

Found in:
- `src/historical/metadata.rs`
### exp_completion_date

Found in:
- `src/reference/corporate.rs`
### exp_hash_hex

Found in:
- `src/historical/batch.rs`
### exp_size

Found in:
- `src/historical/batch.rs`
### exp_version

Found in:
- `src/historical/timeseries.rs`
### expanded

Found in:
- `CHANGELOG.md`
### expect

Found in:
- `src/historical/timeseries.rs`
### expect_subscribe

Found in:
- `src/live/client.rs`
### expected

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### expected_rtype

Found in:
- `examples/live_smoke_test.rs`
### experience

Found in:
- `CODE_OF_CONDUCT.md`
### experiences

Found in:
- `CODE_OF_CONDUCT.md`
### experimental

Found in:
- `src/lib.rs`
### expire

Found in:
- `src/historical/batch.rs`
### expired

Found in:
- `src/historical/batch.rs`
### expiry

Found in:
- `src/reference/corporate.rs`
### expiry_time

Found in:
- `src/reference/corporate.rs`
### expiry_tz

Found in:
- `src/reference/corporate.rs`
### explanation

Found in:
- `CODE_OF_CONDUCT.md`
### explicit

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### explicitly

Found in:
- `LICENSE`
- `src/historical/timeseries.rs`
### export

Found in:
- `src/historical/timeseries.rs`
- `src/lib.rs`
### exposed

Found in:
- `src/live/protocol.rs`
### express

Found in:
- `LICENSE`
### expression

Found in:
- `CODE_OF_CONDUCT.md`
### ext

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### extend

Found in:
- `CHANGELOG.md`
### extends

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### extension

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### extensions

Found in:
- `src/reference/enums.rs`
### external

Found in:
- `CODE_OF_CONDUCT.md`
### extract

Found in:
- `repo_book_gen.py`
### extract_keywords

Found in:
- `repo_book_gen.py`
### extracted

Found in:
- `repo_book_gen.py`
### extraordinary

Found in:
- `src/reference/enums.rs`

## F

### FeedMode

Found in:
- `src/historical/metadata.rs`
### FieldDetail

Found in:
- `src/historical/metadata.rs`
### Fixture

Found in:
- `src/live/client.rs`
### Fraction

Found in:
- `src/reference/enums.rs`
### Frequency

Found in:
- `src/reference/enums.rs`
### f64

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### factor

Found in:
- `src/reference/adjustment.rs`
### factors

Found in:
- `src/reference/adjustment.rs`
- `src/reference.rs`
### fail

Found in:
- `.github/workflows/build.yaml`
### failed

Found in:
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/live/client.rs`
### fails

Found in:
- `scripts/format.sh`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
### failure

Found in:
- `LICENSE`
- `src/live/client.rs`
### fair

Found in:
- `CODE_OF_CONDUCT.md`
### fairly

Found in:
- `CODE_OF_CONDUCT.md`
### falkland

Found in:
- `src/reference/enums.rs`
### falklands

Found in:
- `src/reference/enums.rs`
### fallback

Found in:
- `repo_book_gen.py`
### fallible_streaming_iterator

Found in:
- `CHANGELOG.md`
### fallibly

Found in:
- `src/reference.rs`
### falls

Found in:
- `src/reference/corporate.rs`
### false

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/client.rs`
### faq

Found in:
- `CODE_OF_CONDUCT.md`
### faroe

Found in:
- `src/reference/enums.rs`
### fashion

Found in:
- `src/reference/adjustment.rs`
### faso

Found in:
- `src/reference/enums.rs`
### fast

Found in:
- `.github/workflows/build.yaml`
- `README.md`
### favor

Found in:
- `CHANGELOG.md`
### feature

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `README.md`
- `src/error.rs`
- `src/lib.rs`
### features

Found in:
- `Cargo.toml`
- `README.md`
- `scripts/build.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
- `src/lib.rs`
### fee

Found in:
- `LICENSE`
### feed

Found in:
- `src/historical/metadata.rs`
### feedback

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### feedmode

Found in:
- `src/historical/metadata.rs`
### fees

Found in:
- `src/reference/adjustment.rs`
### fetch

Found in:
- `.github/workflows/release.yaml`
### fetch_symbols_to_parent

Found in:
- `examples/split_symbols.rs`
### fetches

Found in:
- `README.md`
- `src/live/client.rs`
### few

Found in:
- `repo_book_gen.py`
### ffi

Found in:
- `src/live/client.rs`
### field

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### fielddetail

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### fields

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/live.rs`
### fifty

Found in:
- `LICENSE`
### figi

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### figi_ticker

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### fiji

Found in:
- `src/reference/enums.rs`
### file

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### file_class

Found in:
- `repo_book_gen.py`
### file_count

Found in:
- `repo_book_gen.py`
### file_desc

Found in:
- `src/historical/batch.rs`
### file_list

Found in:
- `repo_book_gen.py`
### file_name

Found in:
- `src/historical/batch.rs`
### file_path

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
### file_str

Found in:
- `repo_book_gen.py`
### filed

Found in:
- `LICENSE`
### filename

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### filename_to_download

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### filenames

Found in:
- `repo_book_gen.py`
### files

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### files_scanned

Found in:
- `repo_book_gen.py`
### fill

Found in:
- `CHANGELOG.md`
### filler

Found in:
- `src/live/client.rs`
### filter

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### filter_map

Found in:
- `src/live/protocol.rs`
### filtering

Found in:
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### filters

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### fim

Found in:
- `src/reference/enums.rs`
### final

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### finalize

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### finance

Found in:
- `Cargo.toml`
### financial

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### financial_year_end_date

Found in:
- `src/reference/corporate.rs`
### financials

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### find

Found in:
- `README.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/live/client.rs`
### findall

Found in:
- `repo_book_gen.py`
### fingerprint

Found in:
- `repo_book_gen.py`
### finish_non_exhaustive

Found in:
- `src/live/client.rs`
### finished

Found in:
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
### finland

Found in:
- `src/reference/enums.rs`
### finnish

Found in:
- `src/reference/enums.rs`
### first

Found in:
- `repo_book_gen.py`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### first_letter

Found in:
- `repo_book_gen.py`
### fisn

Found in:
- `src/reference/security.rs`
### fitness

Found in:
- `LICENSE`
### five

Found in:
- `src/lib.rs`
### fix

Found in:
- `.github/pull_request_template.md`
### fixed

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### fixes

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
### fixture

Found in:
- `src/live/client.rs`
### fixture_task

Found in:
- `src/live/client.rs`
### fjd

Found in:
- `src/reference/enums.rs`
### fkp

Found in:
- `src/reference/enums.rs`
### flag

Found in:
- `CHANGELOG.md`
- `scripts/lint.sh`
- `src/reference/corporate.rs`
### flags

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
### flagset

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### flat

Found in:
- `src/historical/metadata.rs`
### floating

Found in:
- `CHANGELOG.md`
### flush

Found in:
- `src/live/client.rs`
### fmt

Found in:
- `scripts/format.sh`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### fmtsubscriber

Found in:
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### fnl

Found in:
- `src/reference/enums.rs`
### focusing

Found in:
- `CODE_OF_CONDUCT.md`
### fold

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
### folder

Found in:
- `repo_book_gen.py`
### folder_path

Found in:
- `repo_book_gen.py`
### folders

Found in:
- `repo_book_gen.py`
### follow

Found in:
- `CODE_OF_CONDUCT.md`
### following

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `README.md`
### follows

Found in:
- `.github/pull_request_template.md`
### fomento

Found in:
- `src/reference/enums.rs`
### force

Found in:
- `.github/workflows/release.yaml`
### forint

Found in:
- `src/reference/enums.rs`
### form

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### format

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### format_args

Found in:
- `src/historical/metadata.rs`
### format_description

Found in:
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/historical.rs`
### format_err

Found in:
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
### formats

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### formatted

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### formatter

Found in:
- `src/error.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### formatting

Found in:
- `CHANGELOG.md`
### forward

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### found

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### four

Found in:
- `src/historical/client.rs`
### fraction

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### fractions

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### frames

Found in:
- `src/historical/timeseries.rs`
### framework

Found in:
- `repo_book_gen.py`
### franc

Found in:
- `src/reference/enums.rs`
### france

Found in:
- `src/reference/enums.rs`
### francs

Found in:
- `src/reference/enums.rs`
### frank

Found in:
- `src/reference/enums.rs`
### franked

Found in:
- `src/reference/enums.rs`
### franking

Found in:
- `src/reference/enums.rs`
### free

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### french

Found in:
- `src/reference/enums.rs`
### frequency

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### frf

Found in:
- `src/reference/enums.rs`
### from

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `scripts/lint.sh`
### from_date

Found in:
- `src/reference/corporate.rs`
### from_millis

Found in:
- `src/live/client.rs`
### from_slice

Found in:
- `src/historical/client.rs`
### from_str

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/reference/enums.rs`
### from_unix_timestamp_nanos

Found in:
- `examples/live_smoke_test.rs`
- `src/historical.rs`
### from_utf8

Found in:
- `src/historical/client.rs`
### from_zstd_file

Found in:
- `examples/split_symbols.rs`
### fromstr

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### fsm

Found in:
- `src/live/client.rs`
### fsplt

Found in:
- `src/reference/enums.rs`
### ftt

Found in:
- `src/reference/enums.rs`
### fuertes

Found in:
- `src/reference/enums.rs`
### full

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
### fully

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### func

Found in:
- `repo_book_gen.py`
### func_count

Found in:
- `repo_book_gen.py`
### function

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
### functionality

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
### functions

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### fund

Found in:
- `src/reference/enums.rs`
### fut

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `src/historical/timeseries.rs`
### futuna

Found in:
- `src/reference/enums.rs`
### future

Found in:
- `CHANGELOG.md`
### futures

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### fwdfill

Found in:
- `CHANGELOG.md`
### fychg

Found in:
- `src/reference/enums.rs`

## G

### GetDatasetConditionParams

Found in:
- `src/historical/metadata.rs`
### GetLastParams

Found in:
- `src/reference/security.rs`
### GetQueryParams

Found in:
- `src/historical/metadata.rs`
### GetRangeParams

Found in:
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### GetRangeToFileParams

Found in:
- `src/historical/timeseries.rs`
### GlobalStatus

Found in:
- `src/reference/enums.rs`
### g1466b145

Found in:
- `src/reference/corporate.rs`
### gabon

Found in:
- `src/reference/enums.rs`
### gambia

Found in:
- `src/reference/enums.rs`
### gambian

Found in:
- `src/reference/enums.rs`
### gateway

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/client.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### gbp

Found in:
- `src/reference/enums.rs`
### gbx

Found in:
- `src/reference/enums.rs`
### gel

Found in:
- `src/reference/enums.rs`
### gender

Found in:
- `CODE_OF_CONDUCT.md`
### general

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `repo_book_gen.py`
- `src/reference/enums.rs`
### generalizing

Found in:
- `CHANGELOG.md`
### generally

Found in:
- `src/live/client.rs`
### generate

Found in:
- `repo_book_gen.py`
### generate_comprehensive_book

Found in:
- `repo_book_gen.py`
### generate_file_docs

Found in:
- `repo_book_gen.py`
### generate_file_keywords

Found in:
- `repo_book_gen.py`
### generate_folder_doc

Found in:
- `repo_book_gen.py`
### generate_folder_index

Found in:
- `repo_book_gen.py`
### generate_folder_sub

Found in:
- `repo_book_gen.py`
### generate_global_index

Found in:
- `repo_book_gen.py`
### generate_global_keyword_index

Found in:
- `repo_book_gen.py`
### generate_overview

Found in:
- `repo_book_gen.py`
### generate_performance_security_notes

Found in:
- `repo_book_gen.py`
### generate_readme

Found in:
- `repo_book_gen.py`
### generate_related_files

Found in:
- `repo_book_gen.py`
### generate_test_info

Found in:
- `repo_book_gen.py`
### generate_usage_examples

Found in:
- `repo_book_gen.py`
### generate_verification_report

Found in:
- `repo_book_gen.py`
### generate_walkthrough

Found in:
- `repo_book_gen.py`
### generated

Found in:
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/metadata.rs`
### generating

Found in:
- `repo_book_gen.py`
### generation

Found in:
- `repo_book_gen.py`
### generator

Found in:
- `repo_book_gen.py`
### generator_version

Found in:
- `repo_book_gen.py`
### georgia

Found in:
- `src/reference/enums.rs`
### georgian

Found in:
- `src/reference/enums.rs`
### germany

Found in:
- `src/reference/enums.rs`
### get_billable_size

Found in:
- `src/historical/metadata.rs`
### get_cost

Found in:
- `src/historical/metadata.rs`
### get_dataset_condition

Found in:
- `src/historical/metadata.rs`
### get_dataset_range

Found in:
- `src/historical/metadata.rs`
### get_for_rec

Found in:
- `examples/split_symbols.rs`
### get_for_rec_ref

Found in:
- `CHANGELOG.md`
### get_last

Found in:
- `examples/reference.rs`
- `src/reference/security.rs`
### get_mut

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### get_range

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### get_range_impl

Found in:
- `src/historical/timeseries.rs`
### get_range_params

Found in:
- `src/historical/symbology.rs`
### get_range_to_file

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
### get_range_to_file_params

Found in:
- `src/historical/symbology.rs`
### get_record_count

Found in:
- `src/historical/metadata.rs`
### get_ref

Found in:
- `src/live/protocol.rs`
### get_version

Found in:
- `.github/workflows/release.yaml`
### get_with_path

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
### getbillablesizeparams

Found in:
- `src/historical/metadata.rs`
### getcostparams

Found in:
- `src/historical/metadata.rs`
### getdatasetconditionparams

Found in:
- `src/historical/metadata.rs`
### getlastparams

Found in:
- `examples/reference.rs`
- `src/reference/security.rs`
### getqueryparams

Found in:
- `src/historical/metadata.rs`
### getrangeparams

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### getrangetofileparams

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### getrecordcountparams

Found in:
- `src/historical/metadata.rs`
### gets

Found in:
- `src/historical/metadata.rs`
### getter

Found in:
- `CHANGELOG.md`
### getters

Found in:
- `CHANGELOG.md`
### getting

Found in:
- `CHANGELOG.md`
- `README.md`
- `repo_book_gen.py`
### ghana

Found in:
- `src/reference/enums.rs`
### ghanaian

Found in:
- `src/reference/enums.rs`
### ghc

Found in:
- `src/reference/enums.rs`
### ghs

Found in:
- `src/reference/enums.rs`
### gibraltar

Found in:
- `src/reference/enums.rs`
### gics

Found in:
- `src/reference/security.rs`
### gigabyte

Found in:
- `src/historical/metadata.rs`
### gip

Found in:
- `src/reference/enums.rs`
### git

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### git_dir

Found in:
- `repo_book_gen.py`
### github

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `repo_book_gen.py`
- `scripts/lint.sh`
### github_env

Found in:
- `.github/workflows/release.yaml`
### give

Found in:
- `LICENSE`
### given

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### giving

Found in:
- `CODE_OF_CONDUCT.md`
### glbx

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### glbxmdp3

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `src/historical/symbology.rs`
- `src/live/client.rs`
### global

Found in:
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### global_status

Found in:
- `src/reference/corporate.rs`
### globalstatus

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### globex

Found in:
- `README.md`
### gmd

Found in:
- `src/reference/enums.rs`
### gnf

Found in:
- `src/reference/enums.rs`
### gold

Found in:
- `src/reference/enums.rs`
### goodwill

Found in:
- `LICENSE`
### got

Found in:
- `src/lib.rs`
### gourde

Found in:
- `src/reference/enums.rs`
### gracefully

Found in:
- `CODE_OF_CONDUCT.md`
### gradually

Found in:
- `CHANGELOG.md`
### grant

Found in:
- `LICENSE`
### granted

Found in:
- `LICENSE`
### granting

Found in:
- `LICENSE`
### grants

Found in:
- `LICENSE`
### granularity

Found in:
- `src/live.rs`
### grd

Found in:
- `src/reference/enums.rs`
### greater

Found in:
- `src/historical/batch.rs`
### greece

Found in:
- `src/reference/enums.rs`
### greek

Found in:
- `src/reference/enums.rs`
### greenland

Found in:
- `src/reference/enums.rs`
### greeting

Found in:
- `src/live/protocol.rs`
### grenada

Found in:
- `src/reference/enums.rs`
### grenadines

Found in:
- `src/reference/enums.rs`
### grep

Found in:
- `scripts/get_version.sh`
### gross_dividend

Found in:
- `src/reference/adjustment.rs`
### grossly

Found in:
- `LICENSE`
### group

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### grouped

Found in:
- `repo_book_gen.py`
### groupings

Found in:
- `src/reference/corporate.rs`
### groups

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### gtq

Found in:
- `src/reference/enums.rs`
### guadeloupe

Found in:
- `src/reference/enums.rs`
### guam

Found in:
- `src/reference/enums.rs`
### guarani

Found in:
- `src/reference/enums.rs`
### guatemala

Found in:
- `src/reference/enums.rs`
### guatemalan

Found in:
- `src/reference/enums.rs`
### guernsey

Found in:
- `src/reference/enums.rs`
### guess_type

Found in:
- `repo_book_gen.py`
### guidelines

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
### guilder

Found in:
- `src/reference/enums.rs`
### guilders

Found in:
- `src/reference/enums.rs`
### guinea

Found in:
- `src/reference/enums.rs`
### guinean

Found in:
- `src/reference/enums.rs`
### guyana

Found in:
- `src/reference/enums.rs`
### gyd

Found in:
- `src/reference/enums.rs`

## H

### HTTP

Found in:
- `src/historical/client.rs`
### Header

Found in:
- `src/historical/batch.rs`
### Helper

Found in:
- `src/lib.rs`
### HistoricalGateway

Found in:
- `src/historical.rs`
### haiti

Found in:
- `src/reference/enums.rs`
### half

Found in:
- `src/historical.rs`
- `src/live/client.rs`
### handle

Found in:
- `CHANGELOG.md`
### handle_response

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### handle_zstd_jsonl_response

Found in:
- `src/historical/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### handled

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### handles

Found in:
- `src/historical/batch.rs`
### handling

Found in:
- `CHANGELOG.md`
### harassing

Found in:
- `CODE_OF_CONDUCT.md`
### harassment

Found in:
- `CODE_OF_CONDUCT.md`
### hardcoded

Found in:
- `repo_book_gen.py`
### harmful

Found in:
- `CODE_OF_CONDUCT.md`
### harmless

Found in:
- `LICENSE`
### has_decoded_metadata

Found in:
- `src/live/client.rs`
### hash

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### hash_algo

Found in:
- `src/historical/batch.rs`
### hash_hex

Found in:
- `src/historical/batch.rs`
### hashed

Found in:
- `src/live/protocol.rs`
### hasher

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### hashfiles

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### hashlib

Found in:
- `repo_book_gen.py`
### hashmap

Found in:
- `examples/split_symbols.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### hasn

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### hasrtype

Found in:
- `src/live/client.rs`
### have

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `scripts/lint.sh`
- `src/live/client.rs`
- `src/live/protocol.rs`
### having

Found in:
- `examples/historical.rs`
- `examples/live.rs`
### hb_int

Found in:
- `src/live/client.rs`
### head

Found in:
- `repo_book_gen.py`
### head_file

Found in:
- `repo_book_gen.py`
### header

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference.rs`
### headermap

Found in:
- `src/historical/client.rs`
- `src/reference.rs`
### headers

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/reference.rs`
### healthy

Found in:
- `CODE_OF_CONDUCT.md`
### heard

Found in:
- `src/reference/enums.rs`
### heartbeat

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live.rs`
### heartbeat_interval

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live.rs`
### heartbeat_interval_s

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### held

Found in:
- `src/reference/corporate.rs`
### helena

Found in:
- `src/reference/enums.rs`
### help

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
### helper

Found in:
- `src/lib.rs`
### helpers

Found in:
- `CHANGELOG.md`
### here

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
### hereby

Found in:
- `LICENSE`
### herein

Found in:
- `LICENSE`
### herzegovina

Found in:
- `src/reference/enums.rs`
### hex

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### hexdigest

Found in:
- `repo_book_gen.py`
### hidden

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### high

Found in:
- `repo_book_gen.py`
- `src/historical/metadata.rs`
- `src/live/client.rs`
### hist

Found in:
- `src/historical.rs`
### historical

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `scripts/build.sh`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
### historicalclient

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### historicalgateway

Found in:
- `src/historical/client.rs`
- `src/historical.rs`
- `src/reference.rs`
### historicalstreaming

Found in:
- `src/historical/metadata.rs`
### hkd

Found in:
- `src/reference/enums.rs`
### hnl

Found in:
- `src/reference/enums.rs`
### hold

Found in:
- `LICENSE`
### holder

Found in:
- `src/reference/enums.rs`
### holding

Found in:
- `src/lib.rs`
- `src/reference/corporate.rs`
### homepage

Found in:
- `CODE_OF_CONDUCT.md`
### honduras

Found in:
- `src/reference/enums.rs`
### hong

Found in:
- `src/reference/enums.rs`
### host

Found in:
- `src/live/protocol.rs`
### hour

Found in:
- `src/deserialize.rs`
### hours

Found in:
- `README.md`
- `examples/live_smoke_test.rs`
- `src/historical/client.rs`
### however

Found in:
- `LICENSE`
### hrk

Found in:
- `src/reference/enums.rs`
### hryvnia

Found in:
- `src/reference/enums.rs`
### htg

Found in:
- `src/reference/enums.rs`
### html

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `README.md`
- `src/historical/client.rs`
### http

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/error.rs`
- `src/historical/client.rs`
- `src/reference.rs`
### http_decoder

Found in:
- `src/historical/timeseries.rs`
### https

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `scripts/lint.sh`
- `src/historical/batch.rs`
- `src/historical.rs`
- `src/live/protocol.rs`
### https_url

Found in:
- `src/historical/batch.rs`
### huf

Found in:
- `src/reference/enums.rs`
### human

Found in:
- `Cargo.toml`
- `src/reference/adjustment.rs`
### hungarian

Found in:
- `src/reference/enums.rs`
### hungary

Found in:
- `src/reference/enums.rs`
### hyd

Found in:
- `src/reference/adjustment.rs`

## I

### Index

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### Interest

Found in:
- `src/reference/enums.rs`
### i128

Found in:
- `examples/live_smoke_test.rs`
- `src/historical.rs`
- `src/live/protocol.rs`
### i64

Found in:
- `src/live/protocol.rs`
### icc

Found in:
- `src/reference/enums.rs`
### ice

Found in:
- `CHANGELOG.md`
### iceland

Found in:
- `src/reference/enums.rs`
### icelandic

Found in:
- `src/reference/enums.rs`
### idea

Found in:
- `.gitignore`
### identification

Found in:
- `src/reference/security.rs`
### identified

Found in:
- `src/lib.rs`
### identifier

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### identifiers

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### identity

Found in:
- `CODE_OF_CONDUCT.md`
### idr

Found in:
- `src/reference/enums.rs`
### ids

Found in:
- `src/lib.rs`
- `src/live/client.rs`
### iep

Found in:
- `src/reference/enums.rs`
### ifeuimpact

Found in:
- `src/historical/timeseries.rs`
### ignore_patterns

Found in:
- `repo_book_gen.py`
### ignorecase

Found in:
- `repo_book_gen.py`
### ignored

Found in:
- `repo_book_gen.py`
- `src/live/client.rs`
- `src/live.rs`
### iid

Found in:
- `src/historical/symbology.rs`
### iii

Found in:
- `LICENSE`
### iller

Found in:
- `src/live/client.rs`
### ils

Found in:
- `src/reference/enums.rs`
### imagery

Found in:
- `CODE_OF_CONDUCT.md`
### imbalancemsg

Found in:
- `CHANGELOG.md`
### img

Found in:
- `README.md`
### immutable

Found in:
- `src/live/client.rs`
### impact

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### impl

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
### implementation

Found in:
- `CHANGELOG.md`
### implementations

Found in:
- `CHANGELOG.md`
### implemented

Found in:
- `CHANGELOG.md`
### implements

Found in:
- `src/lib.rs`
### implied

Found in:
- `LICENSE`
### import

Found in:
- `LICENSE`
- `repo_book_gen.py`
### import_count

Found in:
- `repo_book_gen.py`
### improve

Found in:
- `CHANGELOG.md`
### improved

Found in:
- `CHANGELOG.md`
### improvements

Found in:
- `CHANGELOG.md`
### improving

Found in:
- `LICENSE`
### in_docstring

Found in:
- `repo_book_gen.py`
### inability

Found in:
- `LICENSE`
### inactive

Found in:
- `src/reference/enums.rs`
### inappropriate

Found in:
- `CODE_OF_CONDUCT.md`
### inc

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### inchg

Found in:
- `src/reference/enums.rs`
### incident

Found in:
- `CODE_OF_CONDUCT.md`
### incidental

Found in:
- `LICENSE`
### include

Found in:
- `.github/pull_request_template.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
### include_str

Found in:
- `src/lib.rs`
### included

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### includes

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### including

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
### inclusion

Found in:
- `LICENSE`
### inclusive

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### income

Found in:
- `src/reference/enums.rs`
### incomplete

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
### incorporated

Found in:
- `LICENSE`
### incorporation

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### incorporation_country

Found in:
- `src/reference/security.rs`
### incorrect

Found in:
- `CHANGELOG.md`
### increased

Found in:
- `CHANGELOG.md`
### incur

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### incurred

Found in:
- `LICENSE`
### indefault

Found in:
- `src/reference/enums.rs`
### indemnify

Found in:
- `LICENSE`
### indemnity

Found in:
- `LICENSE`
### indent

Found in:
- `repo_book_gen.py`
### index

Found in:
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### index_content

Found in:
- `repo_book_gen.py`
### index_path

Found in:
- `repo_book_gen.py`
### indexes

Found in:
- `repo_book_gen.py`
### india

Found in:
- `src/reference/enums.rs`
### indian

Found in:
- `src/reference/enums.rs`
### indicate

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### indicated

Found in:
- `LICENSE`
### indicates

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### indicating

Found in:
- `src/reference/corporate.rs`
### indirect

Found in:
- `LICENSE`
### individual

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/reference.rs`
### individuals

Found in:
- `CODE_OF_CONDUCT.md`
### indonesia

Found in:
- `src/reference/enums.rs`
### indonesian

Found in:
- `src/reference/enums.rs`
### industrial

Found in:
- `src/reference/security.rs`
### industry

Found in:
- `src/reference/security.rs`
### infallible

Found in:
- `src/live/client.rs`
### info

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
### info_span

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
### information

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### informational

Found in:
- `LICENSE`
### infringed

Found in:
- `LICENSE`
### infringement

Found in:
- `LICENSE`
### init

Found in:
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
### initial

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
- `src/live.rs`
### initializes

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### initializing

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/reference.rs`
### initiate

Found in:
- `CHANGELOG.md`
### inline

Found in:
- `src/lib.rs`
- `src/reference.rs`
### inner

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### input

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### inr

Found in:
- `src/reference/enums.rs`
### insert

Found in:
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/reference.rs`
### inserted

Found in:
- `src/reference/enums.rs`
### inspect_err

Found in:
- `src/live/protocol.rs`
### inspired

Found in:
- `CODE_OF_CONDUCT.md`
### installation

Found in:
- `README.md`
### instance

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### instances

Found in:
- `CODE_OF_CONDUCT.md`
### instead

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
### institute

Found in:
- `LICENSE`
### instructions

Found in:
- `.github/pull_request_template.md`
### instructs

Found in:
- `src/live/client.rs`
- `src/live.rs`
### instrument

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/security.rs`
### instrument_id

Found in:
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### instrumentclass

Found in:
- `CHANGELOG.md`
### instrumentdefmsg

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
### instrumentdefmsgv1

Found in:
- `CHANGELOG.md`
### instrumentdefmsgv3

Found in:
- `CHANGELOG.md`
### instrumentdefrec

Found in:
- `CHANGELOG.md`
### instrumentid

Found in:
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### instruments

Found in:
- `src/live.rs`
- `src/reference/security.rs`
### insufficient

Found in:
- `src/reference/enums.rs`
### insulting

Found in:
- `CODE_OF_CONDUCT.md`
### int

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### int64_t

Found in:
- `src/historical/metadata.rs`
### int_1

Found in:
- `src/live/client.rs`
### int_2

Found in:
- `src/live/client.rs`
### int_3

Found in:
- `src/live/client.rs`
### int_4

Found in:
- `src/live/client.rs`
### int_5

Found in:
- `src/live/client.rs`
### int_6

Found in:
- `src/live/client.rs`
### intdiv

Found in:
- `src/reference/enums.rs`
### integer

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### integrated

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### intelligentcross

Found in:
- `CHANGELOG.md`
### intended

Found in:
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/live.rs`
- `src/reference.rs`
### intentionally

Found in:
- `LICENSE`
### interact

Found in:
- `CODE_OF_CONDUCT.md`
### interaction

Found in:
- `CODE_OF_CONDUCT.md`
### interactions

Found in:
- `CODE_OF_CONDUCT.md`
### interactive

Found in:
- `repo_book_gen.py`
### interest

Found in:
- `src/reference/enums.rs`
### interface

Found in:
- `CHANGELOG.md`
### interfaces

Found in:
- `LICENSE`
- `README.md`
- `src/live/protocol.rs`
### interim

Found in:
- `src/reference/enums.rs`
### intermediate

Found in:
- `src/live/client.rs`
### internal

Found in:
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### internally

Found in:
- `CHANGELOG.md`
### international

Found in:
- `src/reference/enums.rs`
### interval

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live.rs`
### intervals

Found in:
- `src/historical/symbology.rs`
### into

Found in:
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### into_inner

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### into_iter

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
### into_url

Found in:
- `src/historical/client.rs`
### intonmat

Found in:
- `src/reference/enums.rs`
### intontrig

Found in:
- `src/reference/enums.rs`
### intourl

Found in:
- `src/historical/client.rs`
### intraday

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live.rs`
### introduced

Found in:
- `CHANGELOG.md`
### invalid

Found in:
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### inversion

Found in:
- `src/reference/enums.rs`
### investigated

Found in:
- `CODE_OF_CONDUCT.md`
### invisible

Found in:
- `CODE_OF_CONDUCT.md`
### invocation

Found in:
- `CHANGELOG.md`
### invocations

Found in:
- `CHANGELOG.md`
### involved

Found in:
- `CODE_OF_CONDUCT.md`
- `src/reference/enums.rs`
### ioslice

Found in:
- `CHANGELOG.md`
### ipynb

Found in:
- `repo_book_gen.py`
### iqd

Found in:
- `src/reference/enums.rs`
### iran

Found in:
- `src/reference/enums.rs`
### iranian

Found in:
- `src/reference/enums.rs`
### iraq

Found in:
- `src/reference/enums.rs`
### iraqi

Found in:
- `src/reference/enums.rs`
### ireland

Found in:
- `src/reference/enums.rs`
### irg

Found in:
- `src/reference/enums.rs`
### irish

Found in:
- `src/reference/enums.rs`
### irr

Found in:
- `src/reference/enums.rs`
### irregular

Found in:
- `src/reference/enums.rs`
### irrevocable

Found in:
- `LICENSE`
### is_ascii

Found in:
- `src/lib.rs`
### is_ascii_hexdigit

Found in:
- `src/live/client.rs`
### is_binary

Found in:
- `repo_book_gen.py`
### is_dir

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### is_empty

Found in:
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### is_file

Found in:
- `repo_book_gen.py`
### is_last

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### is_none

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/security.rs`
### is_snapshot

Found in:
- `examples/live_smoke_test.rs`
### is_some

Found in:
- `src/live/protocol.rs`
### is_some_and

Found in:
- `examples/live_smoke_test.rs`
### is_success

Found in:
- `src/historical/client.rs`
### ischg

Found in:
- `src/reference/enums.rs`
### isin

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### isin_resulting

Found in:
- `src/reference/adjustment.rs`
### isk

Found in:
- `src/reference/enums.rs`
### island

Found in:
- `src/reference/enums.rs`
### islands

Found in:
- `src/reference/enums.rs`
### isle

Found in:
- `src/reference/enums.rs`
### iso

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### iso8601

Found in:
- `src/deserialize.rs`
### isoformat

Found in:
- `repo_book_gen.py`
### israel

Found in:
- `src/reference/enums.rs`
### israeli

Found in:
- `src/reference/enums.rs`
### issue

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### issuecomment

Found in:
- `scripts/lint.sh`
### issued

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### issuer

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### issuer_id

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### issuer_name

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### issues

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `repo_book_gen.py`
- `scripts/lint.sh`
- `src/historical/metadata.rs`
### italian

Found in:
- `src/reference/enums.rs`
### italy

Found in:
- `src/reference/enums.rs`
### itch

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### item

Found in:
- `src/historical/timeseries.rs`
### iter

Found in:
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/reference.rs`
### iter_mut

Found in:
- `src/live/client.rs`
### iterdir

Found in:
- `repo_book_gen.py`
### itl

Found in:
- `src/reference/enums.rs`
### itm

Found in:
- `src/reference/enums.rs`
### ivory

Found in:
- `src/reference/enums.rs`

## J

### JSON

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
### JobState

Found in:
- `src/historical/batch.rs`
### jamaica

Found in:
- `src/reference/enums.rs`
### jamaican

Found in:
- `src/reference/enums.rs`
### jan

Found in:
- `src/reference/enums.rs`
### january

Found in:
- `LICENSE`
### japan

Found in:
- `src/reference/enums.rs`
### japanese

Found in:
- `src/reference/enums.rs`
### java

Found in:
- `repo_book_gen.py`
### javascript

Found in:
- `repo_book_gen.py`
### jep

Found in:
- `src/reference/enums.rs`
### jersey

Found in:
- `src/reference/enums.rs`
### jmd

Found in:
- `src/reference/enums.rs`
### job

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### job_desc

Found in:
- `src/historical/batch.rs`
### job_descs

Found in:
- `src/historical/batch.rs`
### job_dir

Found in:
- `src/historical/batch.rs`
### job_files

Found in:
- `src/historical/batch.rs`
### job_id

Found in:
- `src/historical/batch.rs`
### jobs

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `src/historical/batch.rs`
### jobstate

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### jod

Found in:
- `src/reference/enums.rs`
### join

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### join_slack

Found in:
- `README.md`
### joinhandle

Found in:
- `src/live/client.rs`
### jordan

Found in:
- `src/reference/enums.rs`
### jordanian

Found in:
- `src/reference/enums.rs`
### jpy

Found in:
- `src/reference/enums.rs`
### json

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
### jupyter

Found in:
- `repo_book_gen.py`
### just

Found in:
- `CODE_OF_CONDUCT.md`

## K

### kazakhstan

Found in:
- `src/reference/enums.rs`
### keep

Found in:
- `src/lib.rs`
### kenya

Found in:
- `src/reference/enums.rs`
### kenyan

Found in:
- `src/reference/enums.rs`
### kes

Found in:
- `src/reference/enums.rs`
### key

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `README.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### key_from_env

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### keys

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### keyword

Found in:
- `repo_book_gen.py`
### keywords

Found in:
- `Cargo.toml`
- `repo_book_gen.py`
### keywords_global

Found in:
- `repo_book_gen.py`
### kgs

Found in:
- `src/reference/enums.rs`
### khr

Found in:
- `src/reference/enums.rs`
### kina

Found in:
- `src/reference/enums.rs`
### kind

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### kindness

Found in:
- `CODE_OF_CONDUCT.md`
### kingdom

Found in:
- `src/reference/enums.rs`
### kip

Found in:
- `src/reference/enums.rs`
### kiribati

Found in:
- `src/reference/enums.rs`
### kitts

Found in:
- `src/reference/enums.rs`
### kmf

Found in:
- `src/reference/enums.rs`
### known

Found in:
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
### kong

Found in:
- `src/reference/enums.rs`
### korea

Found in:
- `src/reference/enums.rs`
### korean

Found in:
- `src/reference/enums.rs`
### koruna

Found in:
- `src/reference/enums.rs`
### kpw

Found in:
- `src/reference/enums.rs`
### krona

Found in:
- `src/reference/enums.rs`
### krone

Found in:
- `src/reference/enums.rs`
### kroner

Found in:
- `src/reference/enums.rs`
### kroon

Found in:
- `src/reference/enums.rs`
### krw

Found in:
- `src/reference/enums.rs`
### kuna

Found in:
- `src/reference/enums.rs`
### kuwait

Found in:
- `src/reference/enums.rs`
### kuwaiti

Found in:
- `src/reference/enums.rs`
### kvp

Found in:
- `src/live/protocol.rs`
### kw_content

Found in:
- `repo_book_gen.py`
### kw_doc

Found in:
- `repo_book_gen.py`
### kw_path

Found in:
- `repo_book_gen.py`
### kwacha

Found in:
- `src/reference/enums.rs`
### kwanza

Found in:
- `src/reference/enums.rs`
### kwd

Found in:
- `src/reference/enums.rs`
### kyat

Found in:
- `src/reference/enums.rs`
### kyd

Found in:
- `src/reference/enums.rs`
### kyrgyz

Found in:
- `src/reference/enums.rs`
### kyrgyzstan

Found in:
- `src/reference/enums.rs`
### kzt

Found in:
- `src/reference/enums.rs`

## L

### LEGACY_DATE_TIME_FORMAT

Found in:
- `src/deserialize.rs`
### Limit

Found in:
- `src/historical.rs`
### ListFieldsParams

Found in:
- `src/historical/metadata.rs`
### ListJobsParams

Found in:
- `src/historical/batch.rs`
### ListingSource

Found in:
- `src/reference/enums.rs`
### ListingStatus

Found in:
- `src/reference/enums.rs`
### labels

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/feature_request.md`
### lack

Found in:
- `src/live/protocol.rs`
### ladder

Found in:
- `CODE_OF_CONDUCT.md`
### lak

Found in:
- `src/reference/enums.rs`
### lang

Found in:
- `repo_book_gen.py`
- `scripts/lint.sh`
### lang_map

Found in:
- `repo_book_gen.py`
### language

Found in:
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### lanka

Found in:
- `src/reference/enums.rs`
### lankan

Found in:
- `src/reference/enums.rs`
### lao

Found in:
- `src/reference/enums.rs`
### laos

Found in:
- `src/reference/enums.rs`
### large

Found in:
- `repo_book_gen.py`
### large_blob

Found in:
- `repo_book_gen.py`
### larger

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### lari

Found in:
- `src/reference/enums.rs`
### last

Found in:
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### last_chunk_idx

Found in:
- `src/live/protocol.rs`
### last_modified_date

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### last_sec_master

Found in:
- `examples/reference.rs`
### later

Found in:
- `src/live/client.rs`
### latest

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `README.md`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/security.rs`
### latin

Found in:
- `repo_book_gen.py`
### lats

Found in:
- `src/reference/enums.rs`
### latvia

Found in:
- `src/reference/enums.rs`
### latvian

Found in:
- `src/reference/enums.rs`
### law

Found in:
- `LICENSE`
### lawsuit

Found in:
- `LICENSE`
### layout

Found in:
- `CHANGELOG.md`
### lazylock

Found in:
- `src/lib.rs`
### lbp

Found in:
- `src/reference/enums.rs`
### lcc

Found in:
- `src/reference/enums.rs`
### lead

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### leaders

Found in:
- `CODE_OF_CONDUCT.md`
### learning

Found in:
- `CODE_OF_CONDUCT.md`
### least

Found in:
- `LICENSE`
### lebanese

Found in:
- `src/reference/enums.rs`
### lebanon

Found in:
- `src/reference/enums.rs`
### leg

Found in:
- `CHANGELOG.md`
### leg_

Found in:
- `CHANGELOG.md`
### legacy_date_time_format

Found in:
- `src/deserialize.rs`
### legal

Found in:
- `LICENSE`
- `src/reference/security.rs`
### lei

Found in:
- `src/reference/security.rs`
### lek

Found in:
- `src/reference/enums.rs`
### lempira

Found in:
- `src/reference/enums.rs`
### len

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### length

Found in:
- `CHANGELOG.md`
- `src/lib.rs`
- `src/live/protocol.rs`
### leone

Found in:
- `src/reference/enums.rs`
### lesotho

Found in:
- `src/reference/enums.rs`
### less

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### letter

Found in:
- `repo_book_gen.py`
- `src/reference/enums.rs`
### leu

Found in:
- `src/reference/enums.rs`
### lev

Found in:
- `src/reference/enums.rs`
### level

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### level_filters

Found in:
- `src/live/client.rs`
### levelfilter

Found in:
- `src/live/client.rs`
### liability

Found in:
- `LICENSE`
### liable

Found in:
- `LICENSE`
### liberation

Found in:
- `src/reference/enums.rs`
### liberia

Found in:
- `src/reference/enums.rs`
### liberian

Found in:
- `src/reference/enums.rs`
### library

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `README.md`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### libya

Found in:
- `src/reference/enums.rs`
### libyan

Found in:
- `src/reference/enums.rs`
### licensable

Found in:
- `LICENSE`
### license

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
- `LICENSE`
- `README.md`
### licenses

Found in:
- `LICENSE`
- `README.md`
### licensor

Found in:
- `LICENSE`
### liechtenstein

Found in:
- `src/reference/enums.rs`
### life

Found in:
- `src/reference/security.rs`
### lifetime

Found in:
- `src/live/protocol.rs`
### like

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `scripts/lint.sh`
- `src/reference/adjustment.rs`
### lilangeni

Found in:
- `src/reference/enums.rs`
### limit

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### limitation

Found in:
- `LICENSE`
### limited

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### line

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/reference/enums.rs`
### lines

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
### lines_decoder

Found in:
- `src/historical/client.rs`
### link

Found in:
- `LICENSE`
- `src/error.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### linked

Found in:
- `src/reference/enums.rs`
### linking

Found in:
- `repo_book_gen.py`
### links

Found in:
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### lint

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
### liq

Found in:
- `src/reference/enums.rs`
### liquidation

Found in:
- `src/reference/enums.rs`
### lira

Found in:
- `src/reference/enums.rs`
### lire

Found in:
- `src/reference/enums.rs`
### list

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### list_datasets

Found in:
- `src/historical/metadata.rs`
### list_fields

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### list_files

Found in:
- `src/historical/batch.rs`
### list_jobs

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### list_publishers

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### list_schemas

Found in:
- `src/historical/metadata.rs`
### list_unit_prices

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### listed

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### listener

Found in:
- `src/live/client.rs`
### listfieldsparams

Found in:
- `src/historical/metadata.rs`
### listing

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### listing_country

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listing_created_date

Found in:
- `src/reference/security.rs`
### listing_date

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listing_group_id

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listing_id

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listing_source

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listing_status

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listings

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### listingsource

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### listingstatus

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### listjobsparams

Found in:
- `src/historical/batch.rs`
### lists

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### litas

Found in:
- `src/reference/enums.rs`
### lithuania

Found in:
- `src/reference/enums.rs`
### lithuanian

Found in:
- `src/reference/enums.rs`
### litigation

Found in:
- `LICENSE`
### live

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `scripts/build.sh`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### livebuilder

Found in:
- `CHANGELOG.md`
### liveclient

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
### lkr

Found in:
- `src/reference/enums.rs`
### loa

Found in:
- `src/reference/enums.rs`
### local

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### local_addr

Found in:
- `src/live/client.rs`
### local_code

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### local_code_resulting

Found in:
- `src/reference/adjustment.rs`
### locally

Found in:
- `.github/pull_request_template.md`
- `Cargo.toml`
### located

Found in:
- `repo_book_gen.py`
### lock

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
### log

Found in:
- `CHANGELOG.md`
### logo

Found in:
- `README.md`
### long

Found in:
- `examples/live_smoke_test.rs`
- `src/lib.rs`
### longer

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
### look

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
### lookup_host

Found in:
- `src/live.rs`
### loop

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
### losing

Found in:
- `CHANGELOG.md`
### loss

Found in:
- `LICENSE`
### losses

Found in:
- `LICENSE`
### lot

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### lot_size

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### loti

Found in:
- `src/reference/enums.rs`
### lots

Found in:
- `src/live/client.rs`
### lottery

Found in:
- `src/reference/enums.rs`
### low

Found in:
- `src/historical/metadata.rs`
- `src/live/client.rs`
### lower

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/live/protocol.rs`
### lrd

Found in:
- `src/reference/enums.rs`
### lsg

Found in:
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### lsl

Found in:
- `src/reference/enums.rs`
### lstat

Found in:
- `src/reference/enums.rs`
### ltchg

Found in:
- `src/reference/enums.rs`
### ltl

Found in:
- `src/reference/enums.rs`
### lucia

Found in:
- `src/reference/enums.rs`
### luf

Found in:
- `src/reference/enums.rs`
### luxembourg

Found in:
- `src/reference/enums.rs`
### lvl

Found in:
- `src/reference/enums.rs`
### lyd

Found in:
- `src/reference/enums.rs`

## M

### MAX_RETRIES

Found in:
- `src/historical/batch.rs`
### MandVolu

Found in:
- `src/reference/enums.rs`
### MetadataClient

Found in:
- `src/historical/metadata.rs`
### MockGateway

Found in:
- `src/live/client.rs`
### macao

Found in:
- `src/reference/enums.rs`
### macau

Found in:
- `src/reference/enums.rs`
### macedonia

Found in:
- `src/reference/enums.rs`
### macedonian

Found in:
- `src/reference/enums.rs`
### macos

Found in:
- `.github/workflows/build.yaml`
### macro

Found in:
- `CHANGELOG.md`
### macros

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/reference.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### mad

Found in:
- `src/reference/enums.rs`
### madagascar

Found in:
- `src/reference/enums.rs`
### made

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
- `src/live/client.rs`
- `src/reference/corporate.rs`
### mail

Found in:
- `CODE_OF_CONDUCT.md`
### mailing

Found in:
- `LICENSE`
### main

Found in:
- `.github/workflows/release.yaml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### maintain

Found in:
- `CHANGELOG.md`
### make

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/reference/enums.rs`
### makes

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
### making

Found in:
- `LICENSE`
### malagasy

Found in:
- `src/reference/enums.rs`
### malawi

Found in:
- `src/reference/enums.rs`
### malaysia

Found in:
- `src/reference/enums.rs`
### malaysian

Found in:
- `src/reference/enums.rs`
### maldives

Found in:
- `src/reference/enums.rs`
### maldivian

Found in:
- `src/reference/enums.rs`
### malfunction

Found in:
- `LICENSE`
### mali

Found in:
- `src/reference/enums.rs`
### malta

Found in:
- `src/reference/enums.rs`
### maltese

Found in:
- `src/reference/enums.rs`
### managed

Found in:
- `LICENSE`
### management

Found in:
- `LICENSE`
### manat

Found in:
- `src/reference/enums.rs`
### mand_volu_flag

Found in:
- `src/reference/corporate.rs`
### mandatory

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### mandvolu

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### manifest

Found in:
- `repo_book_gen.py`
### manifest_path

Found in:
- `repo_book_gen.py`
### many

Found in:
- `CHANGELOG.md`
### map

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### map_err

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference/enums.rs`
### map_symbols

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### mapping

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/symbology.rs`
### mappinginterval

Found in:
- `src/historical/symbology.rs`
### mappings

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
### mariana

Found in:
- `src/reference/enums.rs`
### marino

Found in:
- `src/reference/enums.rs`
### markdown

Found in:
- `repo_book_gen.py`
### marked

Found in:
- `CHANGELOG.md`
- `LICENSE`
### marker

Found in:
- `repo_book_gen.py`
### market

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### marking

Found in:
- `src/reference/corporate.rs`
### markka

Found in:
- `src/reference/enums.rs`
### marks

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/reference/enums.rs`
### marshall

Found in:
- `src/reference/enums.rs`
### martinique

Found in:
- `src/reference/enums.rs`
### master

Found in:
- `src/reference/security.rs`
- `src/reference.rs`
### mat

Found in:
- `src/reference/enums.rs`
### match

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### matched

Found in:
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### matchers

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### matches

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/live/client.rs`
### matrix

Found in:
- `.github/workflows/build.yaml`
### maturity

Found in:
- `src/reference/enums.rs`
### mauritania

Found in:
- `src/reference/enums.rs`
### mauritanian

Found in:
- `src/reference/enums.rs`
### mauritius

Found in:
- `src/reference/enums.rs`
### max

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### max_accept_qty

Found in:
- `src/reference/corporate.rs`
### max_offer_qty

Found in:
- `src/reference/corporate.rs`
### max_qualify_qty

Found in:
- `src/reference/corporate.rs`
### max_retries

Found in:
- `src/historical/batch.rs`
### maximum

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### may

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### mayen

Found in:
- `src/reference/enums.rs`
### mayotte

Found in:
- `src/reference/enums.rs`
### mbo

Found in:
- `src/live.rs`
### mbomsg

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
### mbp10msg

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### mbp1msg

Found in:
- `CHANGELOG.md`
### mbp_0

Found in:
- `src/live/client.rs`
### mbp_1

Found in:
- `CHANGELOG.md`
### mbp_10

Found in:
- `CHANGELOG.md`
### mcdonald

Found in:
- `src/reference/enums.rs`
### md_security_trading_status

Found in:
- `CHANGELOG.md`
### mdl

Found in:
- `src/reference/enums.rs`
### mdp3

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### mean

Found in:
- `LICENSE`
### meaning

Found in:
- `CHANGELOG.md`
### means

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/live/client.rs`
### mechanical

Found in:
- `LICENSE`
### mechanism

Found in:
- `src/historical/batch.rs`
### media

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### medium

Found in:
- `LICENSE`
### meet

Found in:
- `LICENSE`
### meeting

Found in:
- `src/reference/enums.rs`
### meets

Found in:
- `src/lib.rs`
### members

Found in:
- `CODE_OF_CONDUCT.md`
### merchantability

Found in:
- `LICENSE`
### merely

Found in:
- `LICENSE`
### merge

Found in:
- `CHANGELOG.md`
- `CONTRIBUTING.md`
### merged

Found in:
- `repo_book_gen.py`
### mergedecoder

Found in:
- `CHANGELOG.md`
### merger

Found in:
- `src/reference/enums.rs`
### mergerecorddecoder

Found in:
- `CHANGELOG.md`
### merges

Found in:
- `repo_book_gen.py`
### merging

Found in:
- `CHANGELOG.md`
### message

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### messages

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
### metadata

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### metadatabuilder

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### metadataclient

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
### method

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### methods

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/reference.rs`
### metical

Found in:
- `src/reference/enums.rs`
### metropolitan

Found in:
- `src/reference/enums.rs`
### mexican

Found in:
- `src/reference/enums.rs`
### mexico

Found in:
- `src/reference/enums.rs`
### mga

Found in:
- `src/reference/enums.rs`
### mic

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### micronesia

Found in:
- `src/reference/enums.rs`
### midnight

Found in:
- `src/historical.rs`
- `src/reference.rs`
### might

Found in:
- `src/reference/adjustment.rs`
### migrating

Found in:
- `CHANGELOG.md`
### mime

Found in:
- `repo_book_gen.py`
### mimetypes

Found in:
- `repo_book_gen.py`
### min

Found in:
- `src/live/client.rs`
### min_accept_qty

Found in:
- `src/reference/corporate.rs`
### min_offer_qty

Found in:
- `src/reference/corporate.rs`
### min_qualify_qty

Found in:
- `src/reference/corporate.rs`
### mini

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/reference/enums.rs`
### minimal

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### minimum

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### minor

Found in:
- `src/reference/enums.rs`
### minute

Found in:
- `src/deserialize.rs`
- `src/live/client.rs`
### minutes

Found in:
- `README.md`
- `src/live/client.rs`
### miquelon

Found in:
- `src/reference/enums.rs`
### mirror

Found in:
- `CONTRIBUTING.md`
### misformatted

Found in:
- `scripts/format.sh`
### missing

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### missing_docs

Found in:
- `src/lib.rs`
### missing_errors_doc

Found in:
- `src/lib.rs`
### mistakes

Found in:
- `CODE_OF_CONDUCT.md`
### mkchg

Found in:
- `src/reference/enums.rs`
### mkd

Found in:
- `src/reference/enums.rs`
### mkdir

Found in:
- `repo_book_gen.py`
### mmk

Found in:
- `src/reference/enums.rs`
### mnt

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### mock

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### mock_server

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### mockgateway

Found in:
- `src/live/client.rs`
### mockserver

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### mod

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
### mode

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### moderation

Found in:
- `CODE_OF_CONDUCT.md`
### modifications

Found in:
- `LICENSE`
### modified

Found in:
- `LICENSE`
- `src/historical/metadata.rs`
### modify

Found in:
- `LICENSE`
### modifying

Found in:
- `CHANGELOG.md`
- `LICENSE`
### module

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### moldova

Found in:
- `src/reference/enums.rs`
### moldovan

Found in:
- `src/reference/enums.rs`
### monaco

Found in:
- `src/reference/enums.rs`
### monetary

Found in:
- `src/reference/enums.rs`
### mongolia

Found in:
- `src/reference/enums.rs`
### mongolian

Found in:
- `src/reference/enums.rs`
### montenegro

Found in:
- `src/reference/enums.rs`
### month

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical.rs`
### monthly

Found in:
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### montserrat

Found in:
- `src/reference/enums.rs`
### mop

Found in:
- `src/reference/enums.rs`
### more

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### moroccan

Found in:
- `src/reference/enums.rs`
### morocco

Found in:
- `src/reference/enums.rs`
### most

Found in:
- `CHANGELOG.md`
### motivation

Found in:
- `.github/pull_request_template.md`
### mount

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### move

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
### moved

Found in:
- `CHANGELOG.md`
### mozambique

Found in:
- `src/reference/enums.rs`
### mozilla

Found in:
- `CODE_OF_CONDUCT.md`
### mpsc

Found in:
- `src/live/client.rs`
### mrgr

Found in:
- `src/reference/enums.rs`
### mro

Found in:
- `src/reference/enums.rs`
### msft

Found in:
- `examples/reference.rs`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### msg

Found in:
- `examples/live_smoke_test.rs`
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### mtl

Found in:
- `src/reference/enums.rs`
### multi

Found in:
- `CHANGELOG.md`
### multi_currency

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### multiline

Found in:
- `repo_book_gen.py`
### multiple

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### multiple_members

Found in:
- `src/historical/timeseries.rs`
### multiprocessing

Found in:
- `repo_book_gen.py`
### mur

Found in:
- `src/reference/enums.rs`
### must

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/reference/corporate.rs`
### mut

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### mutable

Found in:
- `src/live/client.rs`
### mutual

Found in:
- `src/reference/enums.rs`
### mvdol

Found in:
- `src/reference/enums.rs`
### mvr

Found in:
- `src/reference/enums.rs`
### mwc

Found in:
- `src/reference/enums.rs`
### mwk

Found in:
- `src/reference/enums.rs`
### mxn

Found in:
- `src/reference/enums.rs`
### mxv

Found in:
- `src/reference/enums.rs`
### myanmar

Found in:
- `src/reference/enums.rs`
### myr

Found in:
- `src/reference/enums.rs`
### mzn

Found in:
- `src/reference/enums.rs`

## N

### nad

Found in:
- `src/reference/enums.rs`
### naics

Found in:
- `src/reference/security.rs`
### naira

Found in:
- `src/reference/enums.rs`
### nakfa

Found in:
- `src/reference/enums.rs`
### name

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `Cargo.toml`
- `LICENSE`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
### names

Found in:
- `LICENSE`
### namespace

Found in:
- `CHANGELOG.md`
### namespaces

Found in:
- `CHANGELOG.md`
### namibia

Found in:
- `src/reference/enums.rs`
### namibian

Found in:
- `src/reference/enums.rs`
### nanos

Found in:
- `src/historical.rs`
### nanoseconds

Found in:
- `examples/live_smoke_test.rs`
### nasdaq

Found in:
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### nasdaq_symbol

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### nasdaqsymbol

Found in:
- `CHANGELOG.md`
### nationality

Found in:
- `CODE_OF_CONDUCT.md`
### nature

Found in:
- `CODE_OF_CONDUCT.md`
### nauru

Found in:
- `src/reference/enums.rs`
### nautechsystems

Found in:
- `CODE_OF_CONDUCT.md`
### navigate

Found in:
- `repo_book_gen.py`
### ndicates

Found in:
- `src/reference/corporate.rs`
### nearest

Found in:
- `src/historical.rs`
### necessarily

Found in:
- `LICENSE`
- `src/live/client.rs`
### necessary

Found in:
- `.github/pull_request_template.md`
- `src/reference/corporate.rs`
### need

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
### needed

Found in:
- `repo_book_gen.py`
### negligence

Found in:
- `LICENSE`
### negligent

Found in:
- `LICENSE`
### neither

Found in:
- `examples/live_smoke_test.rs`
### nepal

Found in:
- `src/reference/enums.rs`
### nepalese

Found in:
- `src/reference/enums.rs`
### net

Found in:
- `Cargo.toml`
- `src/live/client.rs`
- `src/live.rs`
### netherlands

Found in:
- `src/reference/enums.rs`
### never

Found in:
- `src/live/protocol.rs`
### nevis

Found in:
- `src/reference/enums.rs`
### newline

Found in:
- `src/live/protocol.rs`
### newo

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### next

Found in:
- `README.md`
- `examples/live.rs`
- `src/historical/batch.rs`
- `src/live/client.rs`
### next_day

Found in:
- `src/historical.rs`
### next_line

Found in:
- `src/historical/client.rs`
### next_record

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
### ngn

Found in:
- `src/reference/enums.rs`
### ngultrum

Found in:
- `src/reference/enums.rs`
### nicaragua

Found in:
- `src/reference/enums.rs`
### nicaraguan

Found in:
- `src/reference/enums.rs`
### niger

Found in:
- `src/reference/enums.rs`
### nigeria

Found in:
- `src/reference/enums.rs`
### nigerian

Found in:
- `src/reference/enums.rs`
### nightly

Found in:
- `Cargo.toml`
### nio

Found in:
- `src/reference/enums.rs`
### niue

Found in:
- `src/reference/enums.rs`
### njson

Found in:
- `repo_book_gen.py`
### nkeywords

Found in:
- `repo_book_gen.py`
### nlg

Found in:
- `src/reference/enums.rs`
### nlist

Found in:
- `src/reference/enums.rs`
### no_run

Found in:
- `README.md`
### node_modules

Found in:
- `repo_book_gen.py`
### nok

Found in:
- `src/reference/enums.rs`
### non

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
- `src/lib.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### non_exhaustive

Found in:
- `src/error.rs`
### none

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### nonzerou64

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### nor

Found in:
- `examples/live_smoke_test.rs`
### norfolk

Found in:
- `src/reference/enums.rs`
### normalized

Found in:
- `CHANGELOG.md`
### normalizing

Found in:
- `CHANGELOG.md`
### normally

Found in:
- `LICENSE`
- `src/historical/client.rs`
- `src/reference.rs`
### north

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### northern

Found in:
- `src/reference/enums.rs`
### norway

Found in:
- `src/reference/enums.rs`
### norwegian

Found in:
- `src/reference/enums.rs`
### not_found

Found in:
- `src/historical/symbology.rs`
### note

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
### notebook

Found in:
- `repo_book_gen.py`
### notes

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/reference/enums.rs`
### nothing

Found in:
- `LICENSE`
### notice

Found in:
- `LICENSE`
### notices

Found in:
- `LICENSE`
### notification

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
### notification_date

Found in:
- `src/reference/corporate.rs`
### notify

Found in:
- `CHANGELOG.md`
### notpresent

Found in:
- `src/lib.rs`
### notunicode

Found in:
- `src/lib.rs`
### notwithstanding

Found in:
- `LICENSE`
### now_utc

Found in:
- `src/live/client.rs`
### npr

Found in:
- `src/reference/enums.rs`
### nrenrts

Found in:
- `src/reference/enums.rs`
### nth

Found in:
- `examples/split_symbols.rs`
### nuevo

Found in:
- `src/reference/enums.rs`
### null

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### num

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### number

Found in:
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### numerator

Found in:
- `src/reference/corporate.rs`
### numerical

Found in:
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### nzd

Found in:
- `src/reference/enums.rs`

## O

### OutturnStyle

Found in:
- `src/reference/enums.rs`
### object

Found in:
- `LICENSE`
- `repo_book_gen.py`
- `src/reference.rs`
### obligated

Found in:
- `CODE_OF_CONDUCT.md`
### obligations

Found in:
- `LICENSE`
### obtained

Found in:
- `CHANGELOG.md`
### occur

Found in:
- `src/error.rs`
- `src/reference/corporate.rs`
### occurring

Found in:
- `src/error.rs`
### ocean

Found in:
- `src/reference/enums.rs`
### octet

Found in:
- `src/historical/timeseries.rs`
### odd

Found in:
- `src/reference/enums.rs`
### oddlt

Found in:
- `src/reference/enums.rs`
### off

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### offensive

Found in:
- `CODE_OF_CONDUCT.md`
### offer

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### offered

Found in:
- `src/reference/corporate.rs`
### offeror

Found in:
- `src/reference/corporate.rs`
### official

Found in:
- `CODE_OF_CONDUCT.md`
- `Cargo.toml`
- `README.md`
### officially

Found in:
- `CODE_OF_CONDUCT.md`
- `src/reference/corporate.rs`
### offline

Found in:
- `CODE_OF_CONDUCT.md`
### offset_hour

Found in:
- `src/deserialize.rs`
### offset_minute

Found in:
- `src/deserialize.rs`
### offsetdatetime

Found in:
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### often

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### ohlcv

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### ohlcv1h

Found in:
- `CHANGELOG.md`
### ohlcv1m

Found in:
- `src/live/client.rs`
### ohlcv1s

Found in:
- `src/historical/metadata.rs`
### ohlcv_1m

Found in:
- `src/live/client.rs`
### ohlcvmsg

Found in:
- `src/live/client.rs`
### ok_or_else

Found in:
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
### older

Found in:
- `README.md`
- `src/historical/client.rs`
### oman

Found in:
- `src/reference/enums.rs`
### omani

Found in:
- `src/reference/enums.rs`
### omr

Found in:
- `src/reference/enums.rs`
### on_instrument_def

Found in:
- `CHANGELOG.md`
### on_record

Found in:
- `README.md`
- `examples/live.rs`
### once

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
### online

Found in:
- `CODE_OF_CONDUCT.md`
### only

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### open

Found in:
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/enums.rs`
### open_date

Found in:
- `src/reference/corporate.rs`
### openoptions

Found in:
- `src/historical/batch.rs`
### opens

Found in:
- `src/reference/corporate.rs`
### openssl

Found in:
- `CHANGELOG.md`
- `README.md`
### operating

Found in:
- `CHANGELOG.md`
### operating_mic

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### opinions

Found in:
- `CODE_OF_CONDUCT.md`
### opoff

Found in:
- `src/reference/enums.rs`
### opra

Found in:
- `CHANGELOG.md`
### oprapillar

Found in:
- `src/live/client.rs`
### opt

Found in:
- `src/historical/batch.rs`
### opt_date_str

Found in:
- `src/historical/metadata.rs`
### optimized

Found in:
- `CHANGELOG.md`
### option

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live/client.rs`
### option_election_date

Found in:
- `src/reference/corporate.rs`
### option_expiry_time

Found in:
- `src/reference/corporate.rs`
### option_expiry_tz

Found in:
- `src/reference/corporate.rs`
### option_id

Found in:
- `src/reference/corporate.rs`
### optional

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### options

Found in:
- `.github/pull_request_template.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### or_else

Found in:
- `src/deserialize.rs`
### ord

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### order

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
### ordered

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### ordering

Found in:
- `src/historical/batch.rs`
### ordinary

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### org

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `README.md`
### organization

Found in:
- `repo_book_gen.py`
### orientation

Found in:
- `CODE_OF_CONDUCT.md`
### oriented

Found in:
- `repo_book_gen.py`
### origin

Found in:
- `LICENSE`
### original

Found in:
- `CONTRIBUTING.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/live/client.rs`
### oro

Found in:
- `src/reference/enums.rs`
### ors

Found in:
- `src/reference/corporate.rs`
### other

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
### others

Found in:
- `CODE_OF_CONDUCT.md`
### otherwise

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### ouguiya

Found in:
- `src/reference/enums.rs`
### out_dir

Found in:
- `repo_book_gen.py`
### outcomes

Found in:
- `src/reference/corporate.rs`
### outlying

Found in:
- `src/reference/enums.rs`
### output

Found in:
- `.github/workflows/release.yaml`
- `README.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### output_dir

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### output_path

Found in:
- `src/historical/batch.rs`
### output_pattern

Found in:
- `examples/split_symbols.rs`
### outputs

Found in:
- `.github/workflows/release.yaml`
### outside

Found in:
- `examples/live_smoke_test.rs`
### outstanding

Found in:
- `LICENSE`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### outturn

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### outturn_bbg_comp_id

Found in:
- `src/reference/corporate.rs`
### outturn_bbg_comp_ticker

Found in:
- `src/reference/corporate.rs`
### outturn_figi

Found in:
- `src/reference/corporate.rs`
### outturn_figi_ticker

Found in:
- `src/reference/corporate.rs`
### outturn_isin

Found in:
- `src/reference/corporate.rs`
### outturn_local_code

Found in:
- `src/reference/corporate.rs`
### outturn_security_id

Found in:
- `src/reference/corporate.rs`
### outturn_security_type

Found in:
- `src/reference/corporate.rs`
### outturn_style

Found in:
- `src/reference/corporate.rs`
### outturn_us_code

Found in:
- `src/reference/corporate.rs`
### outturnstyle

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### overall

Found in:
- `CODE_OF_CONDUCT.md`
### override

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### overrides

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### overriding

Found in:
- `CHANGELOG.md`
### overrun

Found in:
- `CHANGELOG.md`
### overview

Found in:
- `repo_book_gen.py`
### own

Found in:
- `LICENSE`
- `src/error.rs`
- `src/historical/symbology.rs`
### owned

Found in:
- `CHANGELOG.md`
### owner

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### ownership

Found in:
- `LICENSE`

## P

### PARAM_NAME

Found in:
- `src/live.rs`
### PATH_PREFIX

Found in:
- `src/historical/batch.rs`
### Path

Found in:
- `repo_book_gen.py`
### PaymentType

Found in:
- `src/reference/enums.rs`
### Protocol

Found in:
- `src/live/protocol.rs`
### PublisherDetail

Found in:
- `src/historical/metadata.rs`
### pab

Found in:
- `src/reference/enums.rs`
### package

Found in:
- `Cargo.toml`
### package_size

Found in:
- `src/historical/batch.rs`
### packaging

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### padding

Found in:
- `CHANGELOG.md`
### paid

Found in:
- `src/reference/adjustment.rs`
### pairs

Found in:
- `src/live/protocol.rs`
### pakistan

Found in:
- `src/reference/enums.rs`
### palau

Found in:
- `src/reference/enums.rs`
### palestine

Found in:
- `src/reference/enums.rs`
### panama

Found in:
- `src/reference/enums.rs`
### panic

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
### papua

Found in:
- `src/reference/enums.rs`
### par

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### par_value

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### par_value_currency

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### par_value_new

Found in:
- `src/reference/corporate.rs`
### par_value_old

Found in:
- `src/reference/corporate.rs`
### paraguay

Found in:
- `src/reference/enums.rs`
### parallel

Found in:
- `repo_book_gen.py`
- `src/reference/enums.rs`
### param

Found in:
- `src/historical/metadata.rs`
- `src/historical.rs`
### param_name

Found in:
- `src/error.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### parameter

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/live.rs`
### parameters

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### params

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### parent

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### parents

Found in:
- `repo_book_gen.py`
### parse

Found in:
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### parse_args

Found in:
- `repo_book_gen.py`
### parser

Found in:
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
### parses

Found in:
- `src/live/protocol.rs`
### parsing

Found in:
- `Cargo.toml`
### part

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/symbology.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### partial

Found in:
- `src/historical/symbology.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### partialeq

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### partially

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### partialord

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### participants

Found in:
- `src/reference/corporate.rs`
### participate

Found in:
- `src/reference/corporate.rs`
### participation

Found in:
- `CODE_OF_CONDUCT.md`
- `src/reference/corporate.rs`
### particular

Found in:
- `LICENSE`
- `src/historical/metadata.rs`
- `src/lib.rs`
### parts

Found in:
- `repo_book_gen.py`
### party

Found in:
- `LICENSE`
### pass

Found in:
- `.github/pull_request_template.md`
- `src/lib.rs`
- `src/live.rs`
### passed

Found in:
- `CHANGELOG.md`
- `src/error.rs`
### password

Found in:
- `repo_book_gen.py`
### pataca

Found in:
- `src/reference/enums.rs`
### patent

Found in:
- `LICENSE`
### path

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
### path_prefix

Found in:
- `src/historical/batch.rs`
### pathbuf

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### pathlib

Found in:
- `repo_book_gen.py`
### paths

Found in:
- `src/historical/batch.rs`
### pattern

Found in:
- `CODE_OF_CONDUCT.md`
### patterns

Found in:
- `repo_book_gen.py`
### payment

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### payment_date

Found in:
- `src/reference/corporate.rs`
### payment_type

Found in:
- `src/reference/corporate.rs`
### paymentdetailscancelledbyissuer

Found in:
- `src/reference/enums.rs`
### paymentdetailsdeletedbysupplier

Found in:
- `src/reference/enums.rs`
### payments

Found in:
- `src/reference/corporate.rs`
### paymenttype

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### peer_addr

Found in:
- `src/live/client.rs`
### pen

Found in:
- `src/reference/enums.rs`
### pence

Found in:
- `src/reference/enums.rs`
### pending

Found in:
- `src/historical/metadata.rs`
- `src/reference/enums.rs`
### pension

Found in:
- `src/reference/enums.rs`
### people

Found in:
- `CODE_OF_CONDUCT.md`
### per

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/reference/security.rs`
### percent

Found in:
- `LICENSE`
### perf_sec

Found in:
- `repo_book_gen.py`
### perform

Found in:
- `LICENSE`
### performance

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### performed

Found in:
- `src/live/client.rs`
### performs

Found in:
- `src/live/protocol.rs`
### period

Found in:
- `CODE_OF_CONDUCT.md`
- `src/reference/corporate.rs`
### permanent

Found in:
- `CODE_OF_CONDUCT.md`
### permission

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### permissions

Found in:
- `LICENSE`
### permitted

Found in:
- `src/reference/enums.rs`
### perpetual

Found in:
- `LICENSE`
### persist

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
### persisted

Found in:
- `src/historical/timeseries.rs`
### personal

Found in:
- `CODE_OF_CONDUCT.md`
### pertain

Found in:
- `LICENSE`
### peru

Found in:
- `src/reference/enums.rs`
### peruvian

Found in:
- `src/reference/enums.rs`
### peseta

Found in:
- `src/reference/enums.rs`
### pesetas

Found in:
- `src/reference/enums.rs`
### peso

Found in:
- `src/reference/enums.rs`
### pfs

Found in:
- `src/reference/enums.rs`
### pgk

Found in:
- `src/reference/enums.rs`
### philippines

Found in:
- `src/reference/enums.rs`
### php

Found in:
- `src/reference/enums.rs`
### physical

Found in:
- `CODE_OF_CONDUCT.md`
### pid

Found in:
- `src/reference/enums.rs`
### piecemeal

Found in:
- `CHANGELOG.md`
### pierre

Found in:
- `src/reference/enums.rs`
### pitcairn

Found in:
- `src/reference/enums.rs`
### pitsymbolmap

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
### pkr

Found in:
- `src/reference/enums.rs`
### placeholder

Found in:
- `repo_book_gen.py`
- `src/lib.rs`
### places

Found in:
- `LICENSE`
### plan

Found in:
- `src/reference/enums.rs`
### plans

Found in:
- `src/historical/metadata.rs`
### platform

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### please

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/lib.rs`
### pledge

Found in:
- `CODE_OF_CONDUCT.md`
### pln

Found in:
- `src/reference/enums.rs`
### poff

Found in:
- `src/reference/enums.rs`
### point

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### poland

Found in:
- `src/reference/enums.rs`
### policies

Found in:
- `CHANGELOG.md`
### policy

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### polish

Found in:
- `src/reference/enums.rs`
### political

Found in:
- `CODE_OF_CONDUCT.md`
### polynesia

Found in:
- `src/reference/enums.rs`
### pop

Found in:
- `src/live/protocol.rs`
### populated

Found in:
- `src/reference/corporate.rs`
### port

Found in:
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### portal

Found in:
- `src/historical/batch.rs`
### portugal

Found in:
- `src/reference/enums.rs`
### portuguese

Found in:
- `src/reference/enums.rs`
### position

Found in:
- `CHANGELOG.md`
### positive

Found in:
- `CODE_OF_CONDUCT.md`
### possibility

Found in:
- `LICENSE`
### post

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### posting

Found in:
- `CODE_OF_CONDUCT.md`
### potential

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/live/client.rs`
### pound

Found in:
- `src/reference/enums.rs`
### pounds

Found in:
- `src/reference/enums.rs`
### power

Found in:
- `LICENSE`
### prchg

Found in:
- `src/reference/enums.rs`
### precision

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live.rs`
### predicate

Found in:
- `CHANGELOG.md`
### preference

Found in:
- `src/reference/enums.rs`
### preferential

Found in:
- `src/reference/enums.rs`
### preferred

Found in:
- `LICENSE`
- `src/reference/enums.rs`
### premium

Found in:
- `src/reference/enums.rs`
### preparation

Found in:
- `CHANGELOG.md`
### prepare

Found in:
- `LICENSE`
### prerelease

Found in:
- `.github/workflows/release.yaml`
### present

Found in:
- `CHANGELOG.md`
### preset

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### pretty

Found in:
- `CHANGELOG.md`
### pretty_auction_time

Found in:
- `CHANGELOG.md`
### pretty_px

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### pretty_ts

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### prev_downloaded_bytes

Found in:
- `src/historical/batch.rs`
### previous

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
### previously

Found in:
- `CHANGELOG.md`
### previsional

Found in:
- `src/reference/enums.rs`
### prf

Found in:
- `src/reference/enums.rs`
### price

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### prices

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### primarily

Found in:
- `src/historical/symbology.rs`
- `src/live/client.rs`
### primary

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### primary_exchange

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### primitivedatetime

Found in:
- `src/deserialize.rs`
### principe

Found in:
- `src/reference/enums.rs`
### print

Found in:
- `repo_book_gen.py`
- `src/lib.rs`
### printable

Found in:
- `CHANGELOG.md`
### println

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
### prior

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
### priority

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### privacy

Found in:
- `CODE_OF_CONDUCT.md`
### private

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/timeseries.rs`
### prl

Found in:
- `src/reference/enums.rs`
### problem

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
### procedural

Found in:
- `repo_book_gen.py`
### proceeding

Found in:
- `src/live/client.rs`
### process

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
### process_file

Found in:
- `repo_book_gen.py`
### process_folders

Found in:
- `repo_book_gen.py`
### processed

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
### processing

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
### product

Found in:
- `LICENSE`
- `src/reference/enums.rs`
### products

Found in:
- `CHANGELOG.md`
### professional

Found in:
- `CODE_OF_CONDUCT.md`
### profile

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
### program

Found in:
- `README.md`
- `examples/split_symbols.rs`
### progress

Found in:
- `src/historical/batch.rs`
### project

Found in:
- `CONTRIBUTING.md`
- `README.md`
### project_root_dir

Found in:
- `scripts/get_version.sh`
### prominent

Found in:
- `LICENSE`
### promptly

Found in:
- `CODE_OF_CONDUCT.md`
### properties

Found in:
- `CHANGELOG.md`
### property

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### proposal

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
### protocol

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### prove

Found in:
- `.github/pull_request_template.md`
### provide

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
### provided

Found in:
- `LICENSE`
- `README.md`
- `src/historical/metadata.rs`
### provides

Found in:
- `CHANGELOG.md`
- `LICENSE`
### providing

Found in:
- `CODE_OF_CONDUCT.md`
### pte

Found in:
- `src/reference/enums.rs`
### pub

Found in:
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### public

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/reference/corporate.rs`
### publicly

Found in:
- `LICENSE`
### publish

Found in:
- `.github/workflows/release.yaml`
### published

Found in:
- `CHANGELOG.md`
### publisher

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### publisher_id

Found in:
- `src/historical/metadata.rs`
### publisher_specific

Found in:
- `CHANGELOG.md`
### publisherdetail

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### publishers

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/live/client.rs`
### publishing

Found in:
- `CODE_OF_CONDUCT.md`
### puerto

Found in:
- `src/reference/enums.rs`
### pula

Found in:
- `src/reference/enums.rs`
### pull

Found in:
- `.github/pull_request_template.md`
- `CONTRIBUTING.md`
### pull_request

Found in:
- `.github/workflows/build.yaml`
### pulling

Found in:
- `CHANGELOG.md`
### punt

Found in:
- `src/reference/enums.rs`
### purchase

Found in:
- `src/reference/enums.rs`
### purpose

Found in:
- `LICENSE`
- `repo_book_gen.py`
### purposes

Found in:
- `LICENSE`
- `src/historical/batch.rs`
- `src/reference/enums.rs`
### push

Found in:
- `.github/workflows/build.yaml`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### pvrd

Found in:
- `src/reference/enums.rs`
### pwd

Found in:
- `scripts/get_version.sh`
### pyg

Found in:
- `src/reference/enums.rs`
### pyo3

Found in:
- `CHANGELOG.md`
### pytest

Found in:
- `repo_book_gen.py`
### pytest_cache

Found in:
- `repo_book_gen.py`
### python

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### python3

Found in:
- `repo_book_gen.py`

## Q

### qar

Found in:
- `src/reference/enums.rs`
### qatar

Found in:
- `src/reference/enums.rs`
### qqq

Found in:
- `src/live/client.rs`
### qtr

Found in:
- `src/reference/enums.rs`
### qualify

Found in:
- `src/reference/corporate.rs`
### quality

Found in:
- `src/historical/metadata.rs`
### quantity

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
### quarterly

Found in:
- `src/reference/enums.rs`
### query

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### query_param

Found in:
- `src/historical/metadata.rs`
### query_param_is_missing

Found in:
- `src/historical/batch.rs`
### questions

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CODE_OF_CONDUCT.md`
### quetzal

Found in:
- `src/reference/enums.rs`
### queued

Found in:
- `src/historical/batch.rs`
### quick

Found in:
- `repo_book_gen.py`
### quoted

Found in:
- `CHANGELOG.md`

## R

### README

Found in:
- `examples/historical.rs`
- `examples/live.rs`
### REC

Found in:
- `src/live/client.rs`
### REQUEST_ID_HEADER

Found in:
- `src/historical/client.rs`
### RepoBookGenerator

Found in:
- `repo_book_gen.py`
### Resolution

Found in:
- `src/historical/symbology.rs`
### ResolutionResp

Found in:
- `src/historical/symbology.rs`
### ResolveParams

Found in:
- `src/historical/symbology.rs`
### race

Found in:
- `CODE_OF_CONDUCT.md`
### ran

Found in:
- `.github/pull_request_template.md`
### rand

Found in:
- `src/reference/enums.rs`
### range

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### range_by_schema

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### range_equivalency

Found in:
- `src/historical.rs`
### ranges

Found in:
- `src/historical/metadata.rs`
### rate

Found in:
- `src/historical/metadata.rs`
### rate_currency

Found in:
- `src/reference/corporate.rs`
### rate_info

Found in:
- `src/reference/corporate.rs`
### rather

Found in:
- `CHANGELOG.md`
### ratio

Found in:
- `src/reference/corporate.rs`
### ratio_new

Found in:
- `src/reference/corporate.rs`
### ratio_old

Found in:
- `src/reference/corporate.rs`
### raw

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live/protocol.rs`
### raw_instrument_id

Found in:
- `CHANGELOG.md`
### raw_symbol

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### rawsymbol

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### rcap

Found in:
- `src/reference/enums.rs`
### rcp

Found in:
- `src/reference/enums.rs`
### rd_priority

Found in:
- `src/reference/corporate.rs`
### rdr

Found in:
- `src/reference/enums.rs`
### rds

Found in:
- `src/reference/enums.rs`
### reaction

Found in:
- `src/reference/adjustment.rs`
### read

Found in:
- `repo_book_gen.py`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
### read_file_safe

Found in:
- `repo_book_gen.py`
### read_line

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### readable

Found in:
- `Cargo.toml`
- `LICENSE`
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
### reader

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### readhalf

Found in:
- `src/live/client.rs`
### reading

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### readme

Found in:
- `examples/historical.rs`
- `examples/live.rs`
- `repo_book_gen.py`
- `src/lib.rs`
### readme_path

Found in:
- `repo_book_gen.py`
### ready

Found in:
- `src/historical/batch.rs`
### real

Found in:
- `Cargo.toml`
- `README.md`
- `src/historical/metadata.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/enums.rs`
### reason

Found in:
- `LICENSE`
- `src/reference/adjustment.rs`
### reasonable

Found in:
- `LICENSE`
### reasonably

Found in:
- `CODE_OF_CONDUCT.md`
### reasons

Found in:
- `CODE_OF_CONDUCT.md`
### reattempted

Found in:
- `src/live/client.rs`
### rec

Found in:
- `README.md`
- `examples/live.rs`
- `examples/split_symbols.rs`
- `src/live/client.rs`
### rec_ref

Found in:
- `src/historical/timeseries.rs`
### receipt

Found in:
- `src/reference/enums.rs`
### receipts

Found in:
- `src/reference/enums.rs`
### receive

Found in:
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### received

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### received_snapshot_record

Found in:
- `examples/live_smoke_test.rs`
### receives

Found in:
- `src/live/client.rs`
### receiving

Found in:
- `CHANGELOG.md`
### recipients

Found in:
- `LICENSE`
### reclassification

Found in:
- `src/reference/enums.rs`
### recognized

Found in:
- `src/reference/corporate.rs`
### reconnect

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### reconnecting

Found in:
- `src/live/client.rs`
### record

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### record_count

Found in:
- `src/historical/batch.rs`
### record_date

Found in:
- `src/reference/corporate.rs`
### record_date_id

Found in:
- `src/reference/corporate.rs`
### recorded

Found in:
- `src/reference/corporate.rs`
### recordenum

Found in:
- `CHANGELOG.md`
### recordheader

Found in:
- `src/live/client.rs`
### recordref

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### recordrefenum

Found in:
- `CHANGELOG.md`
### records

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
### recursively

Found in:
- `repo_book_gen.py`
### recv

Found in:
- `src/live/client.rs`
### recver

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### redeemable

Found in:
- `src/reference/enums.rs`
### redem

Found in:
- `src/reference/enums.rs`
### redemption

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### redenomination

Found in:
- `src/reference/enums.rs`
### redistributing

Found in:
- `LICENSE`
### redistribution

Found in:
- `LICENSE`
### reduce

Found in:
- `CHANGELOG.md`
### reducing

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### reduction

Found in:
- `src/reference/enums.rs`
### redundant

Found in:
- `CHANGELOG.md`
### ref

Found in:
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### ref_path

Found in:
- `repo_book_gen.py`
### refer

Found in:
- `repo_book_gen.py`
### reference

Found in:
- `CHANGELOG.md`
- `examples/reference.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### referenceclient

Found in:
- `examples/reference.rs`
- `src/lib.rs`
- `src/reference.rs`
### referring

Found in:
- `CHANGELOG.md`
### reflect

Found in:
- `CHANGELOG.md`
### regarding

Found in:
- `LICENSE`
### regardless

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
### regenerate

Found in:
- `repo_book_gen.py`
### regenerating

Found in:
- `repo_book_gen.py`
### register

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### register_country

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### registration

Found in:
- `src/reference/corporate.rs`
### registration_date

Found in:
- `src/reference/corporate.rs`
### registry

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### regular

Found in:
- `src/reference/enums.rs`
### reinvestment

Found in:
- `src/reference/enums.rs`
### reject

Found in:
- `CODE_OF_CONDUCT.md`
### rejected

Found in:
- `src/live/protocol.rs`
### rejecting

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### rel_path

Found in:
- `repo_book_gen.py`
### related

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### related_event

Found in:
- `src/reference/corporate.rs`
### related_event_id

Found in:
- `src/reference/corporate.rs`
### relative_to

Found in:
- `repo_book_gen.py`
### relaxed

Found in:
- `CHANGELOG.md`
### release

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
### release_name

Found in:
- `.github/workflows/release.yaml`
### released

Found in:
- `CHANGELOG.md`
### releases

Found in:
- `CHANGELOG.md`
### relevant

Found in:
- `.github/pull_request_template.md`
### religion

Found in:
- `CODE_OF_CONDUCT.md`
### remain

Found in:
- `LICENSE`
- `src/reference/adjustment.rs`
### remains

Found in:
- `CHANGELOG.md`
### removal

Found in:
- `CHANGELOG.md`
### remove

Found in:
- `.github/workflows/release.yaml`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/live/protocol.rs`
### removed

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
### removing

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### rename

Found in:
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### renamed

Found in:
- `CHANGELOG.md`
### renminbi

Found in:
- `src/reference/enums.rs`
### renounceable

Found in:
- `src/reference/enums.rs`
### reopens

Found in:
- `src/live/client.rs`
### replace

Found in:
- `examples/split_symbols.rs`
- `src/live/protocol.rs`
### replay

Found in:
- `README.md`
- `src/live/client.rs`
- `src/live.rs`
### reply

Found in:
- `src/live/protocol.rs`
### repo

Found in:
- `repo_book_gen.py`
### repo_book_gen

Found in:
- `repo_book_gen.py`
### repo_fingerprint

Found in:
- `repo_book_gen.py`
### repo_path

Found in:
- `repo_book_gen.py`
### repo_source

Found in:
- `repo_book_gen.py`
### repobookgenerator

Found in:
- `repo_book_gen.py`
### report

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `repo_book_gen.py`
### report_path

Found in:
- `repo_book_gen.py`
### reported

Found in:
- `CODE_OF_CONDUCT.md`
### reporter

Found in:
- `CODE_OF_CONDUCT.md`
### reporting

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### repositories

Found in:
- `repo_book_gen.py`
### repository

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `repo_book_gen.py`
### repr

Found in:
- `src/reference/enums.rs`
### represent

Found in:
- `LICENSE`
### representation

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/lib.rs`
### representative

Found in:
- `CODE_OF_CONDUCT.md`
### representatives

Found in:
- `LICENSE`
### representing

Found in:
- `CODE_OF_CONDUCT.md`
### represents

Found in:
- `src/reference/adjustment.rs`
### reproduce

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/pull_request_template.md`
- `LICENSE`
### reproducing

Found in:
- `LICENSE`
### reproduction

Found in:
- `LICENSE`
### republic

Found in:
- `src/reference/enums.rs`
### req

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### request

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### request_id

Found in:
- `src/error.rs`
- `src/historical/client.rs`
### request_id_header

Found in:
- `src/historical/client.rs`
### requestbuilder

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### requested

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
### requesting

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
### requests

Found in:
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### required

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### requirement

Found in:
- `src/reference/corporate.rs`
### requirements

Found in:
- `CHANGELOG.md`
- `src/lib.rs`
### requires

Found in:
- `.github/pull_request_template.md`
- `src/reference/adjustment.rs`
### reqwest

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### reqwestform

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### res

Found in:
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### rescind

Found in:
- `src/reference/enums.rs`
### reserved4

Found in:
- `CHANGELOG.md`
### reserves

Found in:
- `src/reference/enums.rs`
### reset

Found in:
- `src/live/client.rs`
### resolution

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
### resolutionresp

Found in:
- `src/historical/symbology.rs`
### resolutions

Found in:
- `src/historical/client.rs`
### resolve

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/symbology.rs`
- `src/live.rs`
### resolved

Found in:
- `src/historical/symbology.rs`
### resolveparams

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
### resolves

Found in:
- `src/historical/symbology.rs`
### resp

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### respect

Found in:
- `CODE_OF_CONDUCT.md`
### respectful

Found in:
- `CODE_OF_CONDUCT.md`
### respectively

Found in:
- `CHANGELOG.md`
### respects

Found in:
- `src/historical/metadata.rs`
### respond

Found in:
- `src/live/protocol.rs`
### respond_with

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### response

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/error.rs`
- `src/historical/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### responses

Found in:
- `CHANGELOG.md`
### responsetemplate

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### responsibilities

Found in:
- `CODE_OF_CONDUCT.md`
### responsibility

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### responsible

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
### resub

Found in:
- `src/live/client.rs`
### resubscribe

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### resubscribes

Found in:
- `src/live/client.rs`
### result

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/deserialize.rs`
### resultant

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### resulting

Found in:
- `LICENSE`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### resume

Found in:
- `CHANGELOG.md`
### resumed

Found in:
- `src/historical/batch.rs`
- `src/reference/enums.rs`
### resuming

Found in:
- `src/historical/batch.rs`
### resumption

Found in:
- `CHANGELOG.md`
### retain

Found in:
- `LICENSE`
### retract

Found in:
- `src/reference/corporate.rs`
### retracting

Found in:
- `src/reference/corporate.rs`
### retries

Found in:
- `src/historical/batch.rs`
### retrieve

Found in:
- `CHANGELOG.md`
- `src/reference.rs`
### retry

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### retrying

Found in:
- `src/historical/batch.rs`
### return

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### returned

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### returning

Found in:
- `CHANGELOG.md`
### returns

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### reunion

Found in:
- `src/reference/enums.rs`
### reused

Found in:
- `CHANGELOG.md`
### reverse

Found in:
- `src/reference/enums.rs`
### review

Found in:
- `repo_book_gen.py`
### reviewed

Found in:
- `CODE_OF_CONDUCT.md`
### reviews

Found in:
- `src/reference/corporate.rs`
### revisions

Found in:
- `LICENSE`
### rfc

Found in:
- `examples/live_smoke_test.rs`
### rfc3339

Found in:
- `examples/live_smoke_test.rs`
### rial

Found in:
- `src/reference/enums.rs`
### rica

Found in:
- `src/reference/enums.rs`
### rican

Found in:
- `src/reference/enums.rs`
### rico

Found in:
- `src/reference/enums.rs`
### riel

Found in:
- `src/reference/enums.rs`
### right

Found in:
- `CODE_OF_CONDUCT.md`
### rights

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### ringgit

Found in:
- `src/reference/enums.rs`
### risks

Found in:
- `LICENSE`
### riyal

Found in:
- `src/reference/enums.rs`
### rol

Found in:
- `src/reference/enums.rs`
### rolled

Found in:
- `CHANGELOG.md`
### romania

Found in:
- `src/reference/enums.rs`
### romanian

Found in:
- `src/reference/enums.rs`
### ron

Found in:
- `src/reference/enums.rs`
### root

Found in:
- `repo_book_gen.py`
### root_doc_path

Found in:
- `repo_book_gen.py`
### root_path

Found in:
- `repo_book_gen.py`
### rough

Found in:
- `repo_book_gen.py`
### round

Found in:
- `src/historical.rs`
- `src/reference/enums.rs`
### rounddown

Found in:
- `src/reference/enums.rs`
### roundup

Found in:
- `src/reference/enums.rs`
### rows

Found in:
- `src/reference/corporate.rs`
### royalty

Found in:
- `LICENSE`
### rpodelisted

Found in:
- `src/reference/enums.rs`
### rpolisted

Found in:
- `src/reference/enums.rs`
### rposuspended

Found in:
- `src/reference/enums.rs`
### rsd

Found in:
- `src/reference/enums.rs`
### rsplt

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### rstest

Found in:
- `Cargo.toml`
- `src/historical/timeseries.rs`
- `src/reference/security.rs`
### rts

Found in:
- `src/reference/enums.rs`
### rtype

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
### rtype_dispatch

Found in:
- `CHANGELOG.md`
### rub

Found in:
- `src/reference/enums.rs`
### ruble

Found in:
- `src/reference/enums.rs`
### rufiyaa

Found in:
- `src/reference/enums.rs`
### rule

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### run

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `README.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
### run_with_snapshot

Found in:
- `examples/live_smoke_test.rs`
### runner

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### runs

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### runtime

Found in:
- `README.md`
### rupee

Found in:
- `src/reference/enums.rs`
### rupees

Found in:
- `src/reference/enums.rs`
### rupiah

Found in:
- `src/reference/enums.rs`
### rur

Found in:
- `src/reference/enums.rs`
### russia

Found in:
- `src/reference/enums.rs`
### russian

Found in:
- `src/reference/enums.rs`
### rust

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `README.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `scripts/lint.sh`
- `src/lib.rs`
### rustdoc

Found in:
- `Cargo.toml`
- `src/lib.rs`
### rustdocflags

Found in:
- `Cargo.toml`
- `scripts/lint.sh`
### rustfmt

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### rustls

Found in:
- `CHANGELOG.md`
- `README.md`
### rustup

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### rwanda

Found in:
- `src/reference/enums.rs`
### rwandan

Found in:
- `src/reference/enums.rs`
### rwf

Found in:
- `src/reference/enums.rs`

## S

### SCHEMA

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### START

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### SYMBOL

Found in:
- `src/live/client.rs`
### SYMBOL_COUNT

Found in:
- `src/live/client.rs`
### SecurityMaster

Found in:
- `src/reference/security.rs`
### SecurityMasterClient

Found in:
- `src/reference/security.rs`
### SecurityType

Found in:
- `src/reference/enums.rs`
### Some

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
### SplitDuration

Found in:
- `src/historical/batch.rs`
### SplitSize

Found in:
- `src/historical/batch.rs`
### Start

Found in:
- `src/reference.rs`
### StartRequest

Found in:
- `src/live/protocol.rs`
### SubRequest

Found in:
- `src/live/protocol.rs`
### SubmitJobParams

Found in:
- `src/historical/batch.rs`
### Subscription

Found in:
- `src/live/protocol.rs`
- `src/live.rs`
### SymbologyClient

Found in:
- `src/historical/symbology.rs`
### Symbols

Found in:
- `src/lib.rs`
### safe

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### safely

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### safety

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### sahara

Found in:
- `src/reference/enums.rs`
### saint

Found in:
- `src/reference/enums.rs`
### sale

Found in:
- `src/reference/enums.rs`
### salsify

Found in:
- `.github/workflows/release.yaml`
### salvador

Found in:
- `src/reference/enums.rs`
### same

Found in:
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### samoa

Found in:
- `src/reference/enums.rs`
### samoan

Found in:
- `src/reference/enums.rs`
### san

Found in:
- `src/reference/enums.rs`
### sao

Found in:
- `src/reference/enums.rs`
### sar

Found in:
- `src/reference/enums.rs`
### saturating_sub

Found in:
- `src/lib.rs`
### saudi

Found in:
- `src/reference/enums.rs`
### save

Found in:
- `repo_book_gen.py`
### save_manifest

Found in:
- `repo_book_gen.py`
### saving

Found in:
- `repo_book_gen.py`
- `src/live/client.rs`
### sbd

Found in:
- `src/reference/enums.rs`
### scalar

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### scale

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### scan

Found in:
- `repo_book_gen.py`
### scan_files

Found in:
- `repo_book_gen.py`
### scanned

Found in:
- `repo_book_gen.py`
### scanning

Found in:
- `repo_book_gen.py`
### scchg

Found in:
- `src/reference/enums.rs`
### scheduled

Found in:
- `src/reference/corporate.rs`
### schema

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
### schema_dispatch

Found in:
- `CHANGELOG.md`
### schemas

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### schilling

Found in:
- `src/reference/enums.rs`
### scope

Found in:
- `CODE_OF_CONDUCT.md`
### scr

Found in:
- `src/reference/enums.rs`
### script

Found in:
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
### scripts

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### scripts_dir

Found in:
- `scripts/get_version.sh`
### scswp

Found in:
- `src/reference/enums.rs`
### sdchg

Found in:
- `src/reference/enums.rs`
### sdd

Found in:
- `src/reference/enums.rs`
### sdg

Found in:
- `src/reference/enums.rs`
### seamless

Found in:
- `CHANGELOG.md`
### seanmonstar

Found in:
- `README.md`
### search

Found in:
- `repo_book_gen.py`
### sec_master

Found in:
- `examples/reference.rs`
### second

Found in:
- `src/deserialize.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/enums.rs`
### secondary

Found in:
- `src/reference/enums.rs`
### seconds

Found in:
- `src/live/client.rs`
### secrc

Found in:
- `src/reference/enums.rs`
### secrets

Found in:
- `.github/workflows/release.yaml`
### section

Found in:
- `LICENSE`
- `repo_book_gen.py`
### sections

Found in:
- `LICENSE`
- `repo_book_gen.py`
### securities

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### security

Found in:
- `CODE_OF_CONDUCT.md`
- `examples/reference.rs`
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### security_description

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### security_id

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### security_master

Found in:
- `examples/reference.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### security_masters

Found in:
- `src/reference/security.rs`
### security_type

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### security_types

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### securitymaster

Found in:
- `src/reference/security.rs`
### securitymasterclient

Found in:
- `src/reference/security.rs`
- `src/reference.rs`
### securitytype

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### securityupdateaction

Found in:
- `CHANGELOG.md`
### sed

Found in:
- `.github/workflows/release.yaml`
### sedol

Found in:
- `src/reference/enums.rs`
### seek

Found in:
- `CHANGELOG.md`
### seeking

Found in:
- `CHANGELOG.md`
### segment

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### segment_mic

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### segment_mic_name

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### sek

Found in:
- `src/reference/enums.rs`
### select

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
### self

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### sell

Found in:
- `LICENSE`
### semi

Found in:
- `src/reference/enums.rs`
### semiannual

Found in:
- `src/reference/enums.rs`
### send

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### send_record

Found in:
- `src/live/client.rs`
### send_ts_out

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### sender

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### sending

Found in:
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### sendrecord

Found in:
- `src/live/client.rs`
### sends

Found in:
- `src/live/protocol.rs`
### senegal

Found in:
- `src/reference/enums.rs`
### sent

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### sentiment

Found in:
- `src/reference/adjustment.rs`
### sentinel

Found in:
- `src/lib.rs`
### separable

Found in:
- `LICENSE`
### separate

Found in:
- `LICENSE`
### sequence

Found in:
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### serbia

Found in:
- `src/reference/enums.rs`
### serbian

Found in:
- `src/reference/enums.rs`
### serde

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/reference/adjustment.rs`
### serde_json

Found in:
- `Cargo.toml`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
### serial

Found in:
- `src/reference/corporate.rs`
### serial_id

Found in:
- `src/reference/corporate.rs`
### serialize

Found in:
- `CHANGELOG.md`
- `src/reference/enums.rs`
### serialized

Found in:
- `src/historical/batch.rs`
### serializer

Found in:
- `src/reference/enums.rs`
### serials

Found in:
- `src/reference/corporate.rs`
### series

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/metadata.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### serious

Found in:
- `CODE_OF_CONDUCT.md`
### served

Found in:
- `CHANGELOG.md`
### server

Found in:
- `src/historical/client.rs`
### service

Found in:
- `LICENSE`
### services

Found in:
- `src/reference/security.rs`
### serving

Found in:
- `CHANGELOG.md`
### session

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### session_id

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### set

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `README.md`
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
### set_body_bytes

Found in:
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### set_body_json

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### set_body_string

Found in:
- `src/historical/client.rs`
### set_nodelay

Found in:
- `src/live/client.rs`
### sets

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### setter

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### setters

Found in:
- `CHANGELOG.md`
### setting

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### settl_price_type

Found in:
- `CHANGELOG.md`
### settlement

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### setup

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `src/live/client.rs`
### several

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/metadata.rs`
- `src/reference/corporate.rs`
### sex

Found in:
- `CODE_OF_CONDUCT.md`
### sexual

Found in:
- `CODE_OF_CONDUCT.md`
### sexualized

Found in:
- `CODE_OF_CONDUCT.md`
### seychelles

Found in:
- `src/reference/enums.rs`
### sgd

Found in:
- `src/reference/enums.rs`
### sgm

Found in:
- `src/reference/enums.rs`
### sha

Found in:
- `repo_book_gen.py`
### sha2

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### sha256

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### shall

Found in:
- `LICENSE`
### shanghai

Found in:
- `src/reference/enums.rs`
### share

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### shareholder

Found in:
- `src/reference/corporate.rs`
### shareholders

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### shares

Found in:
- `LICENSE`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### shares_outstanding

Found in:
- `src/reference/security.rs`
### shares_outstanding_date

Found in:
- `src/reference/security.rs`
### shekel

Found in:
- `src/reference/enums.rs`
### shell

Found in:
- `.github/workflows/build.yaml`
### shenzhen

Found in:
- `src/reference/enums.rs`
### shields

Found in:
- `README.md`
### shilling

Found in:
- `src/reference/enums.rs`
### shoch

Found in:
- `examples/reference.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### short

Found in:
- `src/reference/security.rs`
### should

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### show

Found in:
- `src/reference/corporate.rs`
### shp

Found in:
- `src/reference/enums.rs`
### shut

Found in:
- `src/live/protocol.rs`
### shutdown

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### shuts

Found in:
- `src/live/protocol.rs`
### sic

Found in:
- `src/reference/security.rs`
### sid

Found in:
- `src/live/protocol.rs`
### side

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### sierra

Found in:
- `src/reference/enums.rs`
### sign

Found in:
- `CHANGELOG.md`
### significant

Found in:
- `repo_book_gen.py`
### signifying

Found in:
- `src/reference/corporate.rs`
### similar

Found in:
- `CHANGELOG.md`
- `README.md`
### simple

Found in:
- `README.md`
- `src/historical/client.rs`
### simpler

Found in:
- `CHANGELOG.md`
### simplified

Found in:
- `CHANGELOG.md`
### simply

Found in:
- `src/reference/adjustment.rs`
### since

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### singapore

Found in:
- `src/reference/enums.rs`
### single

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
### single_date_conversion

Found in:
- `src/historical.rs`
### sit

Found in:
- `src/reference/enums.rs`
### site

Found in:
- `README.md`
### size

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### skip

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### skip_all

Found in:
- `src/live/client.rs`
### skipbytes

Found in:
- `CHANGELOG.md`
### skipped

Found in:
- `repo_book_gen.py`
### skipped_files

Found in:
- `repo_book_gen.py`
### skipping

Found in:
- `src/historical/batch.rs`
### skk

Found in:
- `src/reference/enums.rs`
### slack

Found in:
- `CONTRIBUTING.md`
- `README.md`
### slf

Found in:
- `src/reference/security.rs`
### slice

Found in:
- `src/lib.rs`
- `src/live/protocol.rs`
### sll

Found in:
- `src/reference/enums.rs`
### slovak

Found in:
- `src/reference/enums.rs`
### slovenia

Found in:
- `src/reference/enums.rs`
### slovenian

Found in:
- `src/reference/enums.rs`
### slug

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### sma

Found in:
- `src/reference/enums.rs`
### snake_case

Found in:
- `repo_book_gen.py`
### snapshot

Found in:
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### soa

Found in:
- `src/reference/enums.rs`
### social

Found in:
- `CODE_OF_CONDUCT.md`
### socio

Found in:
- `CODE_OF_CONDUCT.md`
### socket

Found in:
- `CHANGELOG.md`
- `src/live.rs`
### socketaddr

Found in:
- `src/live/client.rs`
- `src/live.rs`
### soff

Found in:
- `src/reference/enums.rs`
### softprops

Found in:
- `.github/workflows/release.yaml`
### software

Found in:
- `LICENSE`
### sol

Found in:
- `src/reference/enums.rs`
### sola

Found in:
- `src/reference/security.rs`
### sole

Found in:
- `LICENSE`
### solely

Found in:
- `LICENSE`
### solomon

Found in:
- `src/reference/enums.rs`
### som

Found in:
- `src/reference/enums.rs`
### somalia

Found in:
- `src/reference/enums.rs`
### some

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### something

Found in:
- `src/live/protocol.rs`
### somoni

Found in:
- `src/reference/enums.rs`
### soon

Found in:
- `src/historical/metadata.rs`
### sort

Found in:
- `CODE_OF_CONDUCT.md`
### sort_by_key

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### sorted

Found in:
- `repo_book_gen.py`
- `src/reference/security.rs`
### sorting

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### sos

Found in:
- `src/reference/enums.rs`
### source

Found in:
- `CONTRIBUTING.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/error.rs`
- `src/reference/enums.rs`
### south

Found in:
- `src/reference/enums.rs`
### southern

Found in:
- `src/reference/enums.rs`
### sovereign

Found in:
- `src/reference/enums.rs`
### spa

Found in:
- `src/reference/enums.rs`
### spaces

Found in:
- `CODE_OF_CONDUCT.md`
### spain

Found in:
- `src/reference/enums.rs`
### span

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
### spanish

Found in:
- `src/reference/enums.rs`
### spawn

Found in:
- `src/live/client.rs`
### special

Found in:
- `LICENSE`
- `src/live.rs`
- `src/reference/enums.rs`
### specific

Found in:
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### specifications

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
### specified

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/live.rs`
### specify

Found in:
- `CHANGELOG.md`
### spin

Found in:
- `src/reference/enums.rs`
### splice

Found in:
- `src/lib.rs`
### split

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/enums.rs`
### split_duration

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### split_once

Found in:
- `src/historical/batch.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### split_size

Found in:
- `src/historical/batch.rs`
### split_symbols

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
### splitduration

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### splitlines

Found in:
- `repo_book_gen.py`
### splits

Found in:
- `examples/split_symbols.rs`
- `src/lib.rs`
### splitsize

Found in:
- `src/historical/batch.rs`
### splitting

Found in:
- `src/historical/batch.rs`
### spot

Found in:
- `src/historical/timeseries.rs`
### spp

Found in:
- `src/reference/enums.rs`
### spy

Found in:
- `src/live/client.rs`
### srd

Found in:
- `src/reference/enums.rs`
### sri

Found in:
- `src/reference/enums.rs`
### srt

Found in:
- `src/reference/enums.rs`
### st_size

Found in:
- `repo_book_gen.py`
### stable

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `src/reference/adjustment.rs`
### stakeholders

Found in:
- `src/reference/corporate.rs`
### standard

Found in:
- `src/reference/security.rs`
### standardized

Found in:
- `CHANGELOG.md`
### standards

Found in:
- `CODE_OF_CONDUCT.md`
- `README.md`
### stapled

Found in:
- `src/reference/enums.rs`
### start

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
### start_date

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/reference/corporate.rs`
### start_line

Found in:
- `src/live/client.rs`
### start_nanos

Found in:
- `src/live/protocol.rs`
### start_session

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### start_subscription_date

Found in:
- `src/reference/corporate.rs`
### start_time

Found in:
- `examples/live_smoke_test.rs`
### started

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/live/client.rs`
- `src/live.rs`
### starting

Found in:
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/live/client.rs`
### startrequest

Found in:
- `src/live/protocol.rs`
### starts

Found in:
- `src/historical/batch.rs`
### starts_with

Found in:
- `src/live/protocol.rs`
### startswith

Found in:
- `repo_book_gen.py`
### stat

Found in:
- `repo_book_gen.py`
### state

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/live/client.rs`
### stated

Found in:
- `LICENSE`
### statement

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/live/client.rs`
- `src/live/protocol.rs`
### states

Found in:
- `src/historical/batch.rs`
- `src/reference/enums.rs`
### states_str

Found in:
- `src/historical/batch.rs`
### static

Found in:
- `src/deserialize.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/enums.rs`
### stating

Found in:
- `LICENSE`
### statistics

Found in:
- `CHANGELOG.md`
### statmsg

Found in:
- `CHANGELOG.md`
### statmsgv2

Found in:
- `CHANGELOG.md`
### statrec

Found in:
- `CHANGELOG.md`
### stattype

Found in:
- `CHANGELOG.md`
### statupdateaction

Found in:
- `CHANGELOG.md`
### status

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### status_code

Found in:
- `src/error.rs`
- `src/historical/client.rs`
### statuscode

Found in:
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### statusmsg

Found in:
- `CHANGELOG.md`
### stay

Found in:
- `src/lib.rs`
### std

Found in:
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### step

Found in:
- `repo_book_gen.py`
- `src/reference/corporate.rs`
### steps

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### sterling

Found in:
- `src/reference/enums.rs`
### still

Found in:
- `CHANGELOG.md`
### stl

Found in:
- `src/reference/enums.rs`
### stock

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### stop

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
### stoppage

Found in:
- `LICENSE`
### store

Found in:
- `CHANGELOG.md`
### stp

Found in:
- `src/reference/enums.rs`
### str

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### strategy

Found in:
- `.github/workflows/build.yaml`
- `CHANGELOG.md`
### stream

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### stream_reader

Found in:
- `src/historical/client.rs`
### streamext

Found in:
- `src/historical/batch.rs`
### streaming

Found in:
- `README.md`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### streaming_iterator

Found in:
- `CHANGELOG.md`
### streamreader

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### streams

Found in:
- `CHANGELOG.md`
### string

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/deserialize.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### strings

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### strip

Found in:
- `repo_book_gen.py`
### strip_bool

Found in:
- `src/live.rs`
### strip_option

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
### struct

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### structs

Found in:
- `CHANGELOG.md`
### structure

Found in:
- `repo_book_gen.py`
- `src/reference/security.rs`
### structured

Found in:
- `src/reference/enums.rs`
### style

Found in:
- `.github/pull_request_template.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### stype

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
### stype_in

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### stype_out

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### sub

Found in:
- `repo_book_gen.py`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### sub_base

Found in:
- `src/live/client.rs`
### sub_content

Found in:
- `repo_book_gen.py`
### sub_counter

Found in:
- `src/live/client.rs`
### sub_line

Found in:
- `src/live/client.rs`
### sub_path

Found in:
- `repo_book_gen.py`
### sub_req

Found in:
- `src/live/protocol.rs`
### subclient

Found in:
- `src/historical/client.rs`
- `src/reference.rs`
### subclients

Found in:
- `src/historical/client.rs`
- `src/reference.rs`
### subdir

Found in:
- `repo_book_gen.py`
### subdirectories

Found in:
- `repo_book_gen.py`
### subdirs

Found in:
- `repo_book_gen.py`
### subfolders

Found in:
- `repo_book_gen.py`
### subject

Found in:
- `LICENSE`
- `src/live/protocol.rs`
### sublicense

Found in:
- `LICENSE`
### submission

Found in:
- `LICENSE`
### submit

Found in:
- `LICENSE`
### submit_job

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### submitjobparams

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### submits

Found in:
- `src/historical/batch.rs`
### submitted

Found in:
- `LICENSE`
- `src/historical/batch.rs`
### submitting

Found in:
- `src/historical/client.rs`
### subrequest

Found in:
- `CHANGELOG.md`
- `src/live/protocol.rs`
### subsampled

Found in:
- `CHANGELOG.md`
### subscribe

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### subscriber

Found in:
- `Cargo.toml`
### subscribing

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### subscription

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### subscriptions

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### subscriptions_mut

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### subsec_nanoseconds

Found in:
- `src/live.rs`
### subsecond

Found in:
- `src/deserialize.rs`
- `src/live.rs`
### subsequently

Found in:
- `LICENSE`
### subset

Found in:
- `CHANGELOG.md`
### subtrait

Found in:
- `CHANGELOG.md`
### subtype

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### succeeded

Found in:
- `src/live/client.rs`
### success

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/live/client.rs`
- `src/live/protocol.rs`
### successfully

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### such

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/live/protocol.rs`
### sucre

Found in:
- `src/reference/enums.rs`
### sudan

Found in:
- `src/reference/enums.rs`
### sudanese

Found in:
- `src/reference/enums.rs`
### suffix

Found in:
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### sum

Found in:
- `src/reference/enums.rs`
### summary

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
### sun

Found in:
- `src/reference/security.rs`
### sunday

Found in:
- `src/historical/batch.rs`
### super

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
### supersede

Found in:
- `LICENSE`
### supplied

Found in:
- `src/reference/corporate.rs`
### supplier

Found in:
- `src/reference/enums.rs`
### support

Found in:
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `LICENSE`
- `README.md`
### supported

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/live.rs`
- `src/reference/enums.rs`
### supporting

Found in:
- `CHANGELOG.md`
### supranational

Found in:
- `src/reference/enums.rs`
### surinam

Found in:
- `src/reference/enums.rs`
### suriname

Found in:
- `src/reference/enums.rs`
### suspended

Found in:
- `src/reference/enums.rs`
### sustained

Found in:
- `CODE_OF_CONDUCT.md`
### svalbard

Found in:
- `src/reference/enums.rs`
### svc

Found in:
- `src/reference/enums.rs`
### svg

Found in:
- `README.md`
### swap

Found in:
- `src/reference/enums.rs`
### swaziland

Found in:
- `src/reference/enums.rs`
### sweden

Found in:
- `src/reference/enums.rs`
### swedish

Found in:
- `src/reference/enums.rs`
### swiss

Found in:
- `src/reference/enums.rs`
### switch

Found in:
- `CHANGELOG.md`
### switched

Found in:
- `CHANGELOG.md`
### switzerland

Found in:
- `src/reference/enums.rs`
### sym

Found in:
- `src/lib.rs`
### sym_str

Found in:
- `src/live/protocol.rs`
### symbol

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
### symbol_chunks

Found in:
- `src/live/protocol.rs`
### symbol_count

Found in:
- `src/live/client.rs`
### symbol_cstr_len

Found in:
- `CHANGELOG.md`
### symbol_map

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/split_symbols.rs`
- `src/historical/symbology.rs`
### symbol_map_for_date

Found in:
- `README.md`
- `examples/historical.rs`
### symbol_res

Found in:
- `src/lib.rs`
### symbolindex

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
### symbolmap

Found in:
- `CHANGELOG.md`
### symbolmapping

Found in:
- `examples/live_smoke_test.rs`
### symbolmappingmsg

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
### symbolmappingmsgv1

Found in:
- `CHANGELOG.md`
### symbology

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### symbologyclient

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
### symbols

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
### symbols_to_parent

Found in:
- `examples/split_symbols.rs`
### sync

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
### synchronized

Found in:
- `src/lib.rs`
### syp

Found in:
- `src/reference/enums.rs`
### syria

Found in:
- `src/reference/enums.rs`
### syrian

Found in:
- `src/reference/enums.rs`
### sys

Found in:
- `repo_book_gen.py`
### system

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### systemcode

Found in:
- `CHANGELOG.md`
### systemmsg

Found in:
- `CHANGELOG.md`
### systemmsgv1

Found in:
- `CHANGELOG.md`
### systems

Found in:
- `LICENSE`
### szl

Found in:
- `src/reference/enums.rs`

## T

### TEST_DATA_PATH

Found in:
- `src/lib.rs`
### Test

Found in:
- `src/historical/batch.rs`
### TimeseriesClient

Found in:
- `src/historical/timeseries.rs`
### t7knhwj4xqr0qyjzfktbeg2ec2pxj4fk

Found in:
- `src/live/client.rs`
### tag

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
### tag_name

Found in:
- `.github/workflows/release.yaml`
### taiwan

Found in:
- `src/reference/enums.rs`
### tajikistan

Found in:
- `src/reference/enums.rs`
### tajikistani

Found in:
- `src/reference/enums.rs`
### taka

Found in:
- `src/reference/enums.rs`
### take

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/reference/corporate.rs`
### takeover

Found in:
- `src/reference/enums.rs`
### taking

Found in:
- `CONTRIBUTING.md`
- `src/reference/corporate.rs`
### tala

Found in:
- `src/reference/enums.rs`
### tanzania

Found in:
- `src/reference/enums.rs`
### tanzanian

Found in:
- `src/reference/enums.rs`
### tar

Found in:
- `CHANGELOG.md`
### target

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `.gitignore`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live/client.rs`
### task

Found in:
- `src/live/client.rs`
### tax

Found in:
- `src/reference/enums.rs`
### taxes

Found in:
- `src/reference/adjustment.rs`
### tba

Found in:
- `src/reference/enums.rs`
### tbbo

Found in:
- `src/historical/metadata.rs`
### tcp

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live.rs`
### tcplistener

Found in:
- `src/live/client.rs`
### tcpstream

Found in:
- `src/live/client.rs`
### technologies

Found in:
- `src/reference/corporate.rs`
### temp_dir

Found in:
- `src/historical/timeseries.rs`
### tempdir

Found in:
- `src/historical/timeseries.rs`
### tempfile

Found in:
- `Cargo.toml`
- `src/historical/timeseries.rs`
### temporary

Found in:
- `CODE_OF_CONDUCT.md`
### tend

Found in:
- `src/reference/enums.rs`
### tender

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### tender_price_step

Found in:
- `src/reference/corporate.rs`
### tender_strike_price

Found in:
- `src/reference/corporate.rs`
### tendered

Found in:
- `src/reference/enums.rs`
### tendering

Found in:
- `src/reference/corporate.rs`
### tendmrgr

Found in:
- `src/reference/enums.rs`
### tenge

Found in:
- `src/reference/enums.rs`
### terminate

Found in:
- `LICENSE`
### terms

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
### territories

Found in:
- `src/reference/enums.rs`
### territory

Found in:
- `src/reference/enums.rs`
### test

Found in:
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `repo_book_gen.py`
- `scripts/test.sh`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### test_

Found in:
- `repo_book_gen.py`
### test_cancellation_safety

Found in:
- `src/live/client.rs`
### test_close

Found in:
- `src/live/client.rs`
### test_data

Found in:
- `src/lib.rs`
### test_data_path

Found in:
- `src/lib.rs`
### test_deserialize_compression

Found in:
- `src/historical/batch.rs`
### test_deserialize_symbols

Found in:
- `src/lib.rs`
### test_endpoint

Found in:
- `src/reference/security.rs`
### test_error_without_success

Found in:
- `src/live/client.rs`
### test_get_dataset_condition

Found in:
- `src/historical/metadata.rs`
### test_get_dataset_range

Found in:
- `src/historical/metadata.rs`
### test_get_range

Found in:
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### test_get_range_to_file

Found in:
- `src/historical/timeseries.rs`
### test_info

Found in:
- `repo_book_gen.py`
### test_infra

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### test_key_debug_doesnt_underflow

Found in:
- `src/lib.rs`
### test_key_debug_truncates

Found in:
- `src/lib.rs`
### test_list_fields

Found in:
- `src/historical/metadata.rs`
### test_list_jobs

Found in:
- `src/historical/batch.rs`
### test_list_unit_prices

Found in:
- `src/historical/metadata.rs`
### test_next_record

Found in:
- `src/live/client.rs`
### test_next_record_with_ts_out

Found in:
- `src/live/client.rs`
### test_reconnect

Found in:
- `src/live/client.rs`
### test_resolve

Found in:
- `src/historical/symbology.rs`
### test_submit_job

Found in:
- `src/historical/batch.rs`
### test_subscribe

Found in:
- `src/live/client.rs`
### test_subscribe_snapshot

Found in:
- `src/live/client.rs`
### test_subscribe_snapshot_failed

Found in:
- `src/live/client.rs`
### test_subscription_chunking

Found in:
- `src/live/client.rs`
### test_user

Found in:
- `src/historical/batch.rs`
### tested

Found in:
- `.github/pull_request_template.md`
### testing

Found in:
- `repo_book_gen.py`
- `src/reference/enums.rs`
### tests

Found in:
- `.github/pull_request_template.md`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
### text

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
### thai

Found in:
- `src/reference/enums.rs`
### thailand

Found in:
- `src/reference/enums.rs`
### than

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### thank

Found in:
- `CONTRIBUTING.md`
### that

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `README.md`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
### thb

Found in:
- `src/reference/enums.rs`
### their

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/symbology.rs`
- `src/lib.rs`
- `src/reference/corporate.rs`
### them

Found in:
- `CHANGELOG.md`
- `src/live.rs`
- `src/reference/corporate.rs`
### then

Found in:
- `LICENSE`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
### theory

Found in:
- `LICENSE`
### there

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### thereof

Found in:
- `LICENSE`
### these

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### they

Found in:
- `CODE_OF_CONDUCT.md`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### third

Found in:
- `LICENSE`
### this

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `README.md`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
### thiserror

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/error.rs`
### those

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/live/protocol.rs`
### threading

Found in:
- `repo_book_gen.py`
### threatening

Found in:
- `CODE_OF_CONDUCT.md`
### three

Found in:
- `src/reference.rs`
### through

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `LICENSE`
- `README.md`
- `repo_book_gen.py`
- `src/historical/client.rs`
- `src/reference.rs`
### tick

Found in:
- `Cargo.toml`
- `src/live/client.rs`
### ticker

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### time

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `src/deserialize.rs`
- `src/historical/batch.rs`
### timely

Found in:
- `src/reference/adjustment.rs`
### timeout

Found in:
- `CHANGELOG.md`
### timeseries

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/split_symbols.rs`
- `src/historical/client.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### timeseriesclient

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### timestamp

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### timestamp_end

Found in:
- `repo_book_gen.py`
### timestamp_start

Found in:
- `repo_book_gen.py`
### timestamps

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
### timor

Found in:
- `src/reference/enums.rs`
### timseries

Found in:
- `CHANGELOG.md`
### title

Found in:
- `LICENSE`
### tjs

Found in:
- `src/reference/enums.rs`
### tkovr

Found in:
- `src/reference/enums.rs`
### tkovrmini

Found in:
- `src/reference/enums.rs`
### tls

Found in:
- `Cargo.toml`
- `README.md`
### tmm

Found in:
- `src/reference/enums.rs`
### tnd

Found in:
- `src/reference/enums.rs`
### to_api_string

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### to_ascii_lowercase

Found in:
- `src/live/protocol.rs`
### to_chunked_api_string

Found in:
- `CHANGELOG.md`
- `src/lib.rs`
- `src/live/protocol.rs`
### to_date

Found in:
- `src/reference/corporate.rs`
### to_date_time

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### to_offset

Found in:
- `src/historical.rs`
### to_owned

Found in:
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### to_str

Found in:
- `src/historical/client.rs`
### to_string

Found in:
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### tobago

Found in:
- `src/reference/enums.rs`
### tobeannounced

Found in:
- `src/reference/enums.rs`
### today

Found in:
- `src/reference/adjustment.rs`
### together

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### togo

Found in:
- `src/reference/enums.rs`
### tohex

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### tokelau

Found in:
- `src/reference/enums.rs`
### token

Found in:
- `.github/workflows/release.yaml`
### tokio

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### tokio_util

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### tolar

Found in:
- `src/reference/enums.rs`
### tome

Found in:
- `src/reference/enums.rs`
### toml

Found in:
- `README.md`
- `repo_book_gen.py`
- `scripts/get_version.sh`
### tonga

Found in:
- `src/reference/enums.rs`
### too_many_arguments

Found in:
- `src/historical/timeseries.rs`
### tool

Found in:
- `CHANGELOG.md`
### toolchain

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### toowned

Found in:
- `src/historical/client.rs`
- `src/lib.rs`
### top

Found in:
- `CHANGELOG.md`
- `README.md`
- `src/reference/enums.rs`
### tort

Found in:
- `LICENSE`
### tosocketaddrs

Found in:
- `src/live/client.rs`
- `src/live.rs`
### tostring

Found in:
- `CHANGELOG.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### total

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### total_bytes

Found in:
- `src/historical/batch.rs`
### toward

Found in:
- `CODE_OF_CONDUCT.md`
### tpdelisted

Found in:
- `src/reference/enums.rs`
### tplisted

Found in:
- `src/reference/enums.rs`
### tpsuspended

Found in:
- `src/reference/enums.rs`
### tracing

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### tracing_subscriber

Found in:
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### tracking

Found in:
- `LICENSE`
### trade

Found in:
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `src/live/client.rs`
### tradeable

Found in:
- `src/reference/enums.rs`
### traded

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### trademark

Found in:
- `LICENSE`
### trademarks

Found in:
- `LICENSE`
### trademsg

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### trades

Found in:
- `CHANGELOG.md`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### trading

Found in:
- `Cargo.toml`
- `examples/live_smoke_test.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### trading_currency

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### trading_reference_date

Found in:
- `CHANGELOG.md`
### trading_reference_price

Found in:
- `CHANGELOG.md`
### trait

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `repo_book_gen.py`
- `src/historical.rs`
- `src/reference.rs`
### traits

Found in:
- `CHANGELOG.md`
### transaction

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### transactions

Found in:
- `src/reference/enums.rs`
### transfer

Found in:
- `LICENSE`
### transform

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### transformation

Found in:
- `LICENSE`
### translation

Found in:
- `LICENSE`
### translations

Found in:
- `CODE_OF_CONDUCT.md`
### tried

Found in:
- `src/lib.rs`
### trigger

Found in:
- `src/reference/enums.rs`
### trimesterly

Found in:
- `src/reference/enums.rs`
### trinidad

Found in:
- `src/reference/enums.rs`
### trl

Found in:
- `src/reference/enums.rs`
### trm

Found in:
- `src/reference/enums.rs`
### trolling

Found in:
- `CODE_OF_CONDUCT.md`
### troubleshooting

Found in:
- `CHANGELOG.md`
### trt

Found in:
- `src/reference/enums.rs`
### true

Found in:
- `.github/workflows/release.yaml`
- `Cargo.toml`
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### truncate

Found in:
- `repo_book_gen.py`
### truncated

Found in:
- `repo_book_gen.py`
### truncated_content

Found in:
- `repo_book_gen.py`
### trust

Found in:
- `src/reference/adjustment.rs`
### try

Found in:
- `repo_book_gen.py`
- `src/reference/enums.rs`
### try_from

Found in:
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/reference/enums.rs`
### try_init

Found in:
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### tryfrom

Found in:
- `src/historical/symbology.rs`
- `src/historical.rs`
- `src/reference/enums.rs`
### trystreamext

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### ts_created

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### ts_effective

Found in:
- `src/reference/security.rs`
### ts_event

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
### ts_expiration

Found in:
- `src/historical/batch.rs`
### ts_in_delta

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
### ts_out

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### ts_process_done

Found in:
- `src/historical/batch.rs`
### ts_process_start

Found in:
- `src/historical/batch.rs`
### ts_queued

Found in:
- `src/historical/batch.rs`
### ts_received

Found in:
- `src/historical/batch.rs`
### ts_record

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### ts_recv

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### tseffective

Found in:
- `src/reference/security.rs`
### tsla

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
### tsrecord

Found in:
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### tss

Found in:
- `src/reference/enums.rs`
### tssymbolmap

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
### ttd

Found in:
- `src/reference/enums.rs`
### tugrik

Found in:
- `src/reference/enums.rs`
### tunisia

Found in:
- `src/reference/enums.rs`
### tunisian

Found in:
- `src/reference/enums.rs`
### tuple

Found in:
- `repo_book_gen.py`
### turkey

Found in:
- `src/reference/enums.rs`
### turkish

Found in:
- `src/reference/enums.rs`
### turkmenistan

Found in:
- `src/reference/enums.rs`
### turks

Found in:
- `src/reference/enums.rs`
### tutorials

Found in:
- `README.md`
### tuvalu

Found in:
- `src/reference/enums.rs`
### twd

Found in:
- `src/reference/enums.rs`
### txt

Found in:
- `repo_book_gen.py`
### type

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### type_name

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
### typed

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
### typed_builder

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### typedbuilder

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### types

Found in:
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `LICENSE`
- `src/error.rs`
- `src/historical.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
- `src/reference.rs`
### typescript

Found in:
- `repo_book_gen.py`
### typing

Found in:
- `repo_book_gen.py`
### tzs

Found in:
- `src/reference/enums.rs`

## U

### UnitPricesForMode

Found in:
- `src/historical/metadata.rs`
### Unset

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### u16

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/metadata.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### u32

Found in:
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### u64

Found in:
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### uae

Found in:
- `src/reference/enums.rs`
### uah

Found in:
- `src/reference/enums.rs`
### ubuntu

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
### udi

Found in:
- `src/reference/enums.rs`
### uganda

Found in:
- `src/reference/enums.rs`
### ugandan

Found in:
- `src/reference/enums.rs`
### ugx

Found in:
- `src/reference/enums.rs`
### uic

Found in:
- `src/reference/enums.rs`
### uint64_t

Found in:
- `src/historical/metadata.rs`
### uint8_t

Found in:
- `src/historical/metadata.rs`
### ukraine

Found in:
- `src/reference/enums.rs`
### ukrainian

Found in:
- `src/reference/enums.rs`
### ukwnsubtyp

Found in:
- `src/reference/enums.rs`
### unable

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### unacceptable

Found in:
- `CODE_OF_CONDUCT.md`
### unambiguously

Found in:
- `CHANGELOG.md`
### unbounded_channel

Found in:
- `src/live/client.rs`
### unboundedsender

Found in:
- `src/live/client.rs`
### unclassified

Found in:
- `src/reference/enums.rs`
### uncompressed

Found in:
- `src/historical/metadata.rs`
### undef_stat_quantity

Found in:
- `CHANGELOG.md`
### under

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
- `README.md`
### unexpected

Found in:
- `src/historical/batch.rs`
### unfranked

Found in:
- `src/reference/enums.rs`
### unicode

Found in:
- `src/lib.rs`
### unicodedecodeerror

Found in:
- `repo_book_gen.py`
### unidad

Found in:
- `src/reference/enums.rs`
### union

Found in:
- `LICENSE`
### unique

Found in:
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### unit

Found in:
- `.github/pull_request_template.md`
- `src/historical/metadata.rs`
- `src/reference/enums.rs`
### unit_prices

Found in:
- `src/historical/metadata.rs`
### united

Found in:
- `src/reference/enums.rs`
### unitpricesformode

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### units

Found in:
- `src/reference/enums.rs`
### unittest

Found in:
- `repo_book_gen.py`
### unix

Found in:
- `src/historical.rs`
### unix_epoch

Found in:
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live.rs`
### unix_timestamp_nanos

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference.rs`
### unknown

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/live/client.rs`
- `src/reference/enums.rs`
### unless

Found in:
- `LICENSE`
### unlike

Found in:
- `src/historical/timeseries.rs`
### unofficial

Found in:
- `src/reference/enums.rs`
### unpaired_side

Found in:
- `CHANGELOG.md`
### unpin

Found in:
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
### unprofessional

Found in:
- `CODE_OF_CONDUCT.md`
### unreleased

Found in:
- `CHANGELOG.md`
### unsafe

Found in:
- `CHANGELOG.md`
### unset

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
- `src/reference.rs`
### unsolicited

Found in:
- `CODE_OF_CONDUCT.md`
### unspecified

Found in:
- `src/reference/enums.rs`
### unsuccessful

Found in:
- `src/live/client.rs`
### unsupported

Found in:
- `src/historical/batch.rs`
### unt

Found in:
- `src/reference/enums.rs`
### untagged

Found in:
- `src/historical/client.rs`
- `src/lib.rs`
### until

Found in:
- `src/historical/batch.rs`
### untrusted

Found in:
- `repo_book_gen.py`
### unused

Found in:
- `CHANGELOG.md`
### unwelcome

Found in:
- `CODE_OF_CONDUCT.md`
### unwrap

Found in:
- `README.md`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
### unwrap_err

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
### unwrap_or

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### unwrap_or_default

Found in:
- `src/historical/client.rs`
- `src/live/protocol.rs`
### unwrap_or_else

Found in:
- `src/historical/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### update

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### updated

Found in:
- `CHANGELOG.md`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### upgrade

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### upgrade_policy

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### upgraded

Found in:
- `CHANGELOG.md`
### upgradetov2

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
### upgradetov3

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
### upgrading

Found in:
- `CHANGELOG.md`
### upload_url

Found in:
- `.github/workflows/release.yaml`
### upper

Found in:
- `repo_book_gen.py`
### upstream

Found in:
- `CONTRIBUTING.md`
### uri

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference.rs`
### url

Found in:
- `.github/ISSUE_TEMPLATE/config.yml`
- `CHANGELOG.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical.rs`
- `src/reference.rs`
### urls

Found in:
- `src/historical/batch.rs`
### uruguay

Found in:
- `src/reference/enums.rs`
### uruguayan

Found in:
- `src/reference/enums.rs`
### us92189h4092

Found in:
- `src/reference/adjustment.rs`
### us_code

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### usable

Found in:
- `src/live/client.rs`
### usage

Found in:
- `CHANGELOG.md`
- `README.md`
- `repo_book_gen.py`
### usbats

Found in:
- `src/reference/adjustment.rs`
### usd

Found in:
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### usd0

Found in:
- `src/reference/adjustment.rs`
### use_snapshot

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
### used

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### useful

Found in:
- `src/live/client.rs`
### user

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/live.rs`
- `src/reference.rs`
### user_agent

Found in:
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference.rs`
### user_agent_ext

Found in:
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/live.rs`
- `src/reference.rs`
### user_agent_extension

Found in:
- `src/historical/client.rs`
- `src/live.rs`
- `src/reference.rs`
### user_id

Found in:
- `src/historical/batch.rs`
### users

Found in:
- `CHANGELOG.md`
### uses

Found in:
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `README.md`
- `repo_book_gen.py`
### using

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
### usize

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
### usnasd

Found in:
- `src/reference/corporate.rs`
### usnyse

Found in:
- `src/reference/security.rs`
### usr

Found in:
- `repo_book_gen.py`
- `scripts/build.sh`
- `scripts/format.sh`
- `scripts/get_version.sh`
- `scripts/lint.sh`
- `scripts/test.sh`
### ussr

Found in:
- `src/reference/enums.rs`
### usually

Found in:
- `CHANGELOG.md`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### usx

Found in:
- `src/reference/enums.rs`
### utc

Found in:
- `README.md`
- `examples/historical.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### utc_end

Found in:
- `src/historical.rs`
### utcoffset

Found in:
- `src/historical.rs`
### utf

Found in:
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/error.rs`
### utf8

Found in:
- `src/error.rs`
### utf8error

Found in:
- `src/error.rs`
### util

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
### utils

Found in:
- `Cargo.toml`
### uyi

Found in:
- `src/reference/enums.rs`
### uyu

Found in:
- `src/reference/enums.rs`
### uyw

Found in:
- `src/reference/enums.rs`
### uzbekistan

Found in:
- `src/reference/enums.rs`
### uzs

Found in:
- `src/reference/enums.rs`

## V

### Veb

Found in:
- `src/reference/enums.rs`
### Ves

Found in:
- `src/reference/enums.rs`
### Voting

Found in:
- `src/reference/enums.rs`
### val

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
### valid

Found in:
- `CHANGELOG.md`
- `examples/live_smoke_test.rs`
- `src/historical/batch.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### validated

Found in:
- `src/lib.rs`
### validates

Found in:
- `src/lib.rs`
### validation

Found in:
- `src/historical/batch.rs`
- `src/live/protocol.rs`
### valor

Found in:
- `src/reference/enums.rs`
### value

Found in:
- `CHANGELOG.md`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/protocol.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
- `src/reference/security.rs`
### values

Found in:
- `CHANGELOG.md`
- `src/reference/security.rs`
### vaneck

Found in:
- `src/reference/adjustment.rs`
### vanuatu

Found in:
- `src/reference/enums.rs`
### var

Found in:
- `examples/live_smoke_test.rs`
- `repo_book_gen.py`
- `src/lib.rs`
### varerror

Found in:
- `src/lib.rs`
### variable

Found in:
- `README.md`
- `src/historical/client.rs`
- `src/lib.rs`
- `src/live.rs`
- `src/reference.rs`
### variables

Found in:
- `.github/workflows/release.yaml`
- `repo_book_gen.py`
### variant

Found in:
- `CHANGELOG.md`
- `src/historical/batch.rs`
- `src/reference/enums.rs`
### variants

Found in:
- `CHANGELOG.md`
### various

Found in:
- `CHANGELOG.md`
### vars

Found in:
- `.github/workflows/release.yaml`
### vatican

Found in:
- `src/reference/enums.rs`
### vatu

Found in:
- `src/reference/enums.rs`
### veb

Found in:
- `src/reference/enums.rs`
### vec

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/live/client.rs`
### vef

Found in:
- `src/reference/enums.rs`
### venezuala

Found in:
- `src/reference/enums.rs`
### venezuela

Found in:
- `src/reference/enums.rs`
### venue

Found in:
- `CHANGELOG.md`
- `src/historical/metadata.rs`
### venues

Found in:
- `CHANGELOG.md`
### venv

Found in:
- `repo_book_gen.py`
### verbal

Found in:
- `LICENSE`
### verde

Found in:
- `src/reference/enums.rs`
### verification

Found in:
- `CHANGELOG.md`
- `repo_book_gen.py`
### verification_report

Found in:
- `repo_book_gen.py`
### verified

Found in:
- `src/historical/batch.rs`
### verify

Found in:
- `.github/pull_request_template.md`
### verify_hash

Found in:
- `src/historical/batch.rs`
### version

Found in:
- `.github/ISSUE_TEMPLATE/bug_report.md`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `Cargo.toml`
- `LICENSE`
- `README.md`
- `examples/live_smoke_test.rs`
- `scripts/build.sh`
- `scripts/format.sh`
### versions

Found in:
- `CHANGELOG.md`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live.rs`
### versionupgradepolicy

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### ves

Found in:
- `src/reference/enums.rs`
### vgg1466b1452

Found in:
- `src/reference/corporate.rs`
### via

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/reference/corporate.rs`
### vietnam

Found in:
- `src/reference/enums.rs`
### vietnamese

Found in:
- `src/reference/enums.rs`
### viewpoints

Found in:
- `CODE_OF_CONDUCT.md`
### vincent

Found in:
- `src/reference/enums.rs`
### violating

Found in:
- `CODE_OF_CONDUCT.md`
### violation

Found in:
- `CODE_OF_CONDUCT.md`
### virgin

Found in:
- `src/reference/enums.rs`
### visibility

Found in:
- `CHANGELOG.md`
### visible

Found in:
- `CODE_OF_CONDUCT.md`
### vnd

Found in:
- `src/reference/enums.rs`
### volatility

Found in:
- `CHANGELOG.md`
### volume

Found in:
- `src/historical/metadata.rs`
- `src/live/client.rs`
### voluntary

Found in:
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### vote_per_sec

Found in:
- `src/reference/security.rs`
### votes

Found in:
- `src/reference/security.rs`
### voting

Found in:
- `src/reference/enums.rs`
- `src/reference/security.rs`
### vscode

Found in:
- `.gitignore`
### vuv

Found in:
- `src/reference/enums.rs`
### vwxyz

Found in:
- `src/lib.rs`

## W

### WARNING_HEADER

Found in:
- `src/historical/client.rs`
### walk

Found in:
- `repo_book_gen.py`
### walkthrough

Found in:
- `repo_book_gen.py`
### wallis

Found in:
- `src/reference/enums.rs`
### want

Found in:
- `src/live/protocol.rs`
### war

Found in:
- `src/reference/enums.rs`
### warex

Found in:
- `src/reference/enums.rs`
### warn

Found in:
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/live/client.rs`
- `src/live.rs`
### warning

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
- `src/live/protocol.rs`
### warning_header

Found in:
- `src/historical/client.rs`
### warnings

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `scripts/lint.sh`
- `src/historical/client.rs`
### warrant

Found in:
- `src/reference/enums.rs`
### warranties

Found in:
- `LICENSE`
### warrants

Found in:
- `src/reference/enums.rs`
### warranty

Found in:
- `LICENSE`
### ways

Found in:
- `CODE_OF_CONDUCT.md`
### wca

Found in:
- `src/reference/enums.rs`
### week

Found in:
- `src/historical/batch.rs`
### weekly

Found in:
- `src/reference/enums.rs`
### welcome

Found in:
- `CONTRIBUTING.md`
- `repo_book_gen.py`
### welcoming

Found in:
- `CODE_OF_CONDUCT.md`
### well

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
### well_known

Found in:
- `examples/live_smoke_test.rs`
- `src/deserialize.rs`
### went

Found in:
- `src/live/protocol.rs`
### were

Found in:
- `CODE_OF_CONDUCT.md`
- `src/historical/symbology.rs`
### western

Found in:
- `src/reference/enums.rs`
### what

Found in:
- `CODE_OF_CONDUCT.md`
### when

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
- `src/live.rs`
### where

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### wherever

Found in:
- `LICENSE`
### whether

Found in:
- `CHANGELOG.md`
- `LICENSE`
- `src/live/client.rs`
### which

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/live.rs`
### while

Found in:
- `CONTRIBUTING.md`
- `LICENSE`
- `README.md`
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/split_symbols.rs`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/historical/client.rs`
### whole

Found in:
- `LICENSE`
- `src/reference/enums.rs`
### whole_seconds

Found in:
- `src/live/client.rs`
### whom

Found in:
- `LICENSE`
### why

Found in:
- `CODE_OF_CONDUCT.md`
- `src/error.rs`
### width

Found in:
- `CHANGELOG.md`
### wiki

Found in:
- `CODE_OF_CONDUCT.md`
### will

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `repo_book_gen.py`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
### windows

Found in:
- `.github/workflows/build.yaml`
### wiremock

Found in:
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/client.rs`
- `src/historical/metadata.rs`
- `src/historical/symbology.rs`
- `src/historical/timeseries.rs`
- `src/historical.rs`
- `src/lib.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### wis

Found in:
- `src/reference/enums.rs`
### wish

Found in:
- `CHANGELOG.md`
### with

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `.github/workflows/build.yaml`
- `.github/workflows/release.yaml`
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `CONTRIBUTING.md`
- `LICENSE`
- `README.md`
- `examples/split_symbols.rs`
### with_capacity

Found in:
- `src/historical/batch.rs`
### with_compression_level

Found in:
- `CHANGELOG.md`
### with_context

Found in:
- `examples/split_symbols.rs`
### with_max_level

Found in:
- `src/live/client.rs`
### with_path

Found in:
- `src/historical/timeseries.rs`
### with_test_writer

Found in:
- `examples/historical.rs`
- `examples/live.rs`
- `examples/live_smoke_test.rs`
- `examples/reference.rs`
- `examples/split_symbols.rs`
- `src/live/client.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### with_time

Found in:
- `src/historical.rs`
- `src/reference.rs`
### with_upgrade_policy

Found in:
- `src/historical/timeseries.rs`
### with_url

Found in:
- `CHANGELOG.md`
- `src/historical/client.rs`
### with_zstd

Found in:
- `examples/split_symbols.rs`
- `src/historical/timeseries.rs`
### withdrawal

Found in:
- `src/reference/corporate.rs`
### withdrawal_rights_expiry_time

Found in:
- `src/reference/corporate.rs`
### withdrawal_rights_expiry_tz

Found in:
- `src/reference/corporate.rs`
### withdrawal_rights_flag

Found in:
- `src/reference/corporate.rs`
### withdrawal_rights_from_date

Found in:
- `src/reference/corporate.rs`
### withdrawal_rights_to_date

Found in:
- `src/reference/corporate.rs`
### within

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/lib.rs`
- `src/live/client.rs`
- `src/reference/corporate.rs`
### without

Found in:
- `CHANGELOG.md`
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `src/live/client.rs`
- `src/live/protocol.rs`
### withtsout

Found in:
- `src/live/client.rs`
- `src/live.rs`
### wkl

Found in:
- `src/reference/enums.rs`
### won

Found in:
- `src/reference/enums.rs`
### words

Found in:
- `repo_book_gen.py`
### words_estimated

Found in:
- `repo_book_gen.py`
### work

Found in:
- `.github/pull_request_template.md`
- `CHANGELOG.md`
- `LICENSE`
### workaround

Found in:
- `scripts/lint.sh`
### workflow_dispatch

Found in:
- `.github/workflows/release.yaml`
### workflow_run

Found in:
- `.github/workflows/release.yaml`
### workflows

Found in:
- `.github/workflows/release.yaml`
- `README.md`
### working

Found in:
- `src/error.rs`
### works

Found in:
- `.github/pull_request_template.md`
- `LICENSE`
### world

Found in:
- `repo_book_gen.py`
### worldwide

Found in:
- `LICENSE`
### worth

Found in:
- `CHANGELOG.md`
- `README.md`
### would

Found in:
- `.github/pull_request_template.md`
- `repo_book_gen.py`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
### write

Found in:
- `CHANGELOG.md`
- `examples/split_symbols.rs`
- `repo_book_gen.py`
- `src/error.rs`
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/live/client.rs`
- `src/live/protocol.rs`
- `src/reference/corporate.rs`
### write_all

Found in:
- `src/live/client.rs`
- `src/live/protocol.rs`
### write_str

Found in:
- `src/historical/batch.rs`
- `src/lib.rs`
- `src/reference/security.rs`
### write_vectored

Found in:
- `CHANGELOG.md`
### writehalf

Found in:
- `src/live/client.rs`
### writer

Found in:
- `src/live/protocol.rs`
### writing

Found in:
- `LICENSE`
- `src/error.rs`
### written

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `repo_book_gen.py`
### wrong

Found in:
- `src/live/protocol.rs`
### wst

Found in:
- `src/reference/enums.rs`
### www

Found in:
- `CODE_OF_CONDUCT.md`
- `LICENSE`
- `README.md`

## X

### xaf

Found in:
- `src/reference/enums.rs`
### xbey

Found in:
- `src/reference/security.rs`
### xcd

Found in:
- `src/reference/enums.rs`
### xcis

Found in:
- `CHANGELOG.md`
### xdr

Found in:
- `src/reference/enums.rs`
### xeee

Found in:
- `CHANGELOG.md`
### xeer

Found in:
- `CHANGELOG.md`
### xfu

Found in:
- `src/reference/enums.rs`
### xnas

Found in:
- `src/historical/batch.rs`
- `src/historical/metadata.rs`
- `src/historical/timeseries.rs`
- `src/reference/corporate.rs`
### xnasitch

Found in:
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/live/client.rs`
### xncm

Found in:
- `src/reference/corporate.rs`
### xnys

Found in:
- `CHANGELOG.md`
### xof

Found in:
- `src/reference/enums.rs`
### xoff

Found in:
- `CHANGELOG.md`
### xpf

Found in:
- `src/reference/enums.rs`
### xts

Found in:
- `src/reference/enums.rs`
### xxx

Found in:
- `src/reference/enums.rs`

## Y

### yaml

Found in:
- `README.md`
- `repo_book_gen.py`
### year

Found in:
- `CHANGELOG.md`
- `src/deserialize.rs`
- `src/historical.rs`
- `src/reference/corporate.rs`
- `src/reference/enums.rs`
### yemen

Found in:
- `src/reference/enums.rs`
### yen

Found in:
- `src/reference/enums.rs`
### yer

Found in:
- `src/reference/enums.rs`
### yet

Found in:
- `src/historical/metadata.rs`
### yml

Found in:
- `repo_book_gen.py`
### yongqli

Found in:
- `CHANGELOG.md`
### your

Found in:
- `.github/ISSUE_TEMPLATE/feature_request.md`
- `.github/pull_request_template.md`
- `LICENSE`
- `repo_book_gen.py`
### your_api_key

Found in:
- `src/lib.rs`
### yuan

Found in:
- `src/reference/enums.rs`
### yugoslavian

Found in:
- `src/reference/enums.rs`
### yum

Found in:
- `src/reference/enums.rs`

## Z

### zac

Found in:
- `src/reference/enums.rs`
### zaire

Found in:
- `src/reference/enums.rs`
### zambia

Found in:
- `src/reference/enums.rs`
### zambian

Found in:
- `src/reference/enums.rs`
### zar

Found in:
- `src/reference/enums.rs`
### zealand

Found in:
- `src/reference/enums.rs`
### zimbabwe

Found in:
- `src/reference/enums.rs`
### zimbabwean

Found in:
- `src/reference/enums.rs`
### zip

Found in:
- `CHANGELOG.md`
### zloty

Found in:
- `src/reference/enums.rs`
### zmk

Found in:
- `src/reference/enums.rs`
### zmw

Found in:
- `src/reference/enums.rs`
### zone

Found in:
- `src/reference/corporate.rs`
### zrn

Found in:
- `src/reference/enums.rs`
### zst

Found in:
- `src/historical/timeseries.rs`
- `src/lib.rs`
### zst_test_data_path

Found in:
- `src/historical/timeseries.rs`
- `src/lib.rs`
### zstd

Found in:
- `CHANGELOG.md`
- `Cargo.toml`
- `src/historical/batch.rs`
- `src/historical/timeseries.rs`
- `src/reference/adjustment.rs`
- `src/reference/corporate.rs`
- `src/reference/security.rs`
### zstd_decoder

Found in:
- `src/historical/timeseries.rs`
### zstddecoder

Found in:
- `src/historical/client.rs`
- `src/historical/timeseries.rs`
### zstdencoder

Found in:
- `examples/split_symbols.rs`
### zwd

Found in:
- `src/reference/enums.rs`
### zwg

Found in:
- `src/reference/enums.rs`
### zwl

Found in:
- `src/reference/enums.rs`

## _

### __init__

Found in:
- `repo_book_gen.py`
### __main__

Found in:
- `repo_book_gen.py`
### __name__

Found in:
- `repo_book_gen.py`
### __pycache__

Found in:
- `repo_book_gen.py`
### _docs

Found in:
- `repo_book_gen.py`
### _kw

Found in:
- `repo_book_gen.py`
### _reserved3

Found in:
- `CHANGELOG.md`
