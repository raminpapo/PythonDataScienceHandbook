# Keywords: deserialize.rs

## Extracted Keywords

Total keywords extracted: 52


### A

- **assume_utc**: Identifier found in `src/deserialize.rs`

### B

- **borrowedformatitem**: Identifier found in `src/deserialize.rs`

### C

- **collect**: Identifier found in `src/deserialize.rs`
- **collections**: Identifier found in `src/deserialize.rs`
- **const**: Identifier found in `src/deserialize.rs`
- **crate**: Identifier found in `src/deserialize.rs`
- **custom**: Identifier found in `src/deserialize.rs`

### D

- **default**: Identifier found in `src/deserialize.rs`
- **deserialize**: Identifier found in `src/deserialize.rs`
- **deserialize_date_time**: Identifier found in `src/deserialize.rs`
- **deserialize_opt_date_time**: Identifier found in `src/deserialize.rs`
- **deserialize_opt_date_time_hash_map**: Identifier found in `src/deserialize.rs`
- **deserializer**: Identifier found in `src/deserialize.rs`
- **deserializers**: Identifier found in `src/deserialize.rs`
- **digits**: Identifier found in `src/deserialize.rs`
- **dt_str**: Identifier found in `src/deserialize.rs`

### E

- **else**: Identifier found in `src/deserialize.rs`
- **error**: Identifier found in `src/deserialize.rs`

### F

- **format_description**: Identifier found in `src/deserialize.rs`

### H

- **hashmap**: Identifier found in `src/deserialize.rs`
- **hour**: Identifier found in `src/deserialize.rs`

### I

- **into_iter**: Identifier found in `src/deserialize.rs`
- **iso8601**: Identifier found in `src/deserialize.rs`

### L

- **LEGACY_DATE_TIME_FORMAT**: Identifier found in `src/deserialize.rs`
- **legacy_date_time_format**: Identifier found in `src/deserialize.rs`

### M

- **macros**: Identifier found in `src/deserialize.rs`
- **map**: Identifier found in `src/deserialize.rs`
- **map_err**: Identifier found in `src/deserialize.rs`
- **minute**: Identifier found in `src/deserialize.rs`
- **month**: Identifier found in `src/deserialize.rs`

### N

- **none**: Identifier found in `src/deserialize.rs`

### O

- **offset_hour**: Identifier found in `src/deserialize.rs`
- **offset_minute**: Identifier found in `src/deserialize.rs`
- **offsetdatetime**: Identifier found in `src/deserialize.rs`
- **option**: Identifier found in `src/deserialize.rs`
- **optional**: Identifier found in `src/deserialize.rs`
- **or_else**: Identifier found in `src/deserialize.rs`

### P

- **parse**: Identifier found in `src/deserialize.rs`
- **primitivedatetime**: Identifier found in `src/deserialize.rs`
- **pub**: Identifier found in `src/deserialize.rs`

### R

- **result**: Identifier found in `src/deserialize.rs`

### S

- **Some**: Identifier found in `src/deserialize.rs`
- **second**: Identifier found in `src/deserialize.rs`
- **serde**: Identifier found in `src/deserialize.rs`
- **some**: Identifier found in `src/deserialize.rs`
- **static**: Identifier found in `src/deserialize.rs`
- **std**: Identifier found in `src/deserialize.rs`
- **string**: Identifier found in `src/deserialize.rs`
- **subsecond**: Identifier found in `src/deserialize.rs`

### T

- **time**: Identifier found in `src/deserialize.rs`

### W

- **well_known**: Identifier found in `src/deserialize.rs`

### Y

- **year**: Identifier found in `src/deserialize.rs`
