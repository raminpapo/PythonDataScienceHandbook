# Documentation: src

## Folder Overview

**Path**: `src`
**Files**: 6
**Subdirectories**: 3

## Purpose

This folder is located at `src`.

## Contents Summary

### Subdirectories:
- `historical/`
- `live/`
- `reference/`

### Files:
- `deserialize.rs` (2136 bytes)
- `error.rs` (3300 bytes)
- `historical.rs` (8511 bytes)
- `lib.rs` (9682 bytes)
- `live.rs` (7103 bytes)
- `reference.rs` (8520 bytes)
