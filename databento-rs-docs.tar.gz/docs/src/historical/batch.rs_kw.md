# Keywords: batch.rs

## Extracted Keywords

Total keywords extracted: 505


### A

- **aa89xslbv**: Identifier found in `src/historical/batch.rs`
- **acc**: Identifier found in `src/historical/batch.rs`
- **actual_size**: Identifier found in `src/historical/batch.rs`
- **add_to_form**: Identifier found in `src/historical/batch.rs`
- **addtoform**: Identifier found in `src/historical/batch.rs`
- **after**: Identifier found in `src/historical/batch.rs`
- **algorithm**: Identifier found in `src/historical/batch.rs`
- **already**: Identifier found in `src/historical/batch.rs`
- **also**: Identifier found in `src/historical/batch.rs`
- **any**: Identifier found in `src/historical/batch.rs`
- **api**: Identifier found in `src/historical/batch.rs`
- **api_key**: Identifier found in `src/historical/batch.rs`
- **api_version**: Identifier found in `src/historical/batch.rs`
- **append**: Identifier found in `src/historical/batch.rs`
- **as_mut**: Identifier found in `src/historical/batch.rs`
- **as_ref**: Identifier found in `src/historical/batch.rs`
- **as_str**: Identifier found in `src/historical/batch.rs`
- **as_u16**: Identifier found in `src/historical/batch.rs`
- **assert**: Identifier found in `src/historical/batch.rs`
- **assert_eq**: Identifier found in `src/historical/batch.rs`
- **associated**: Identifier found in `src/historical/batch.rs`
- **async**: Identifier found in `src/historical/batch.rs`
- **available**: Identifier found in `src/historical/batch.rs`
- **await**: Identifier found in `src/historical/batch.rs`

### B

- **BatchClient**: Identifier found in `src/historical/batch.rs`
- **BatchFileDesc**: Identifier found in `src/historical/batch.rs`
- **BatchJob**: Identifier found in `src/historical/batch.rs`
- **bad_arg**: Identifier found in `src/historical/batch.rs`
- **basic_auth**: Identifier found in `src/historical/batch.rs`
- **batch**: Identifier found in `src/historical/batch.rs`
- **batchclient**: Identifier found in `src/historical/batch.rs`
- **batchdownload**: Identifier found in `src/historical/batch.rs`
- **batched**: Identifier found in `src/historical/batch.rs`
- **batchfiledesc**: Identifier found in `src/historical/batch.rs`
- **batchjob**: Identifier found in `src/historical/batch.rs`
- **been**: Identifier found in `src/historical/batch.rs`
- **before**: Identifier found in `src/historical/batch.rs`
- **began**: Identifier found in `src/historical/batch.rs`
- **begun**: Identifier found in `src/historical/batch.rs`
- **being**: Identifier found in `src/historical/batch.rs`
- **between**: Identifier found in `src/historical/batch.rs`
- **billed_size**: Identifier found in `src/historical/batch.rs`
- **billing**: Identifier found in `src/historical/batch.rs`
- **binary**: Identifier found in `src/historical/batch.rs`
- **body_contains**: Identifier found in `src/historical/batch.rs`
- **bool**: Identifier found in `src/historical/batch.rs`
- **both**: Identifier found in `src/historical/batch.rs`
- **bufwriter**: Identifier found in `src/historical/batch.rs`
- **build**: Identifier found in `src/historical/batch.rs`
- **builder**: Identifier found in `src/historical/batch.rs`
- **bytes**: Identifier found in `src/historical/batch.rs`
- **bytes_stream**: Identifier found in `src/historical/batch.rs`

### C

- **calling**: Identifier found in `src/historical/batch.rs`
- **cannot**: Identifier found in `src/historical/batch.rs`
- **center**: Identifier found in `src/historical/batch.rs`
- **cfg**: Identifier found in `src/historical/batch.rs`
- **check_http_error**: Identifier found in `src/historical/batch.rs`
- **check_if_exists**: Identifier found in `src/historical/batch.rs`
- **checksum**: Identifier found in `src/historical/batch.rs`
- **chunk**: Identifier found in `src/historical/batch.rs`
- **class**: Identifier found in `src/historical/batch.rs`
- **client**: Identifier found in `src/historical/batch.rs`
- **clone**: Identifier found in `src/historical/batch.rs`
- **cmp**: Identifier found in `src/historical/batch.rs`
- **code**: Identifier found in `src/historical/batch.rs`
- **collect**: Identifier found in `src/historical/batch.rs`
- **collections**: Identifier found in `src/historical/batch.rs`
- **communicate**: Identifier found in `src/historical/batch.rs`
- **completed**: Identifier found in `src/historical/batch.rs`
- **compression**: Identifier found in `src/historical/batch.rs`
- **const**: Identifier found in `src/historical/batch.rs`
- **continue**: Identifier found in `src/historical/batch.rs`
- **converts**: Identifier found in `src/historical/batch.rs`
- **copy**: Identifier found in `src/historical/batch.rs`
- **correct**: Identifier found in `src/historical/batch.rs`
- **correspond**: Identifier found in `src/historical/batch.rs`
- **cost**: Identifier found in `src/historical/batch.rs`
- **cost_usd**: Identifier found in `src/historical/batch.rs`
- **crate**: Identifier found in `src/historical/batch.rs`
- **create**: Identifier found in `src/historical/batch.rs`
- **create_dir_all**: Identifier found in `src/historical/batch.rs`
- **csv**: Identifier found in `src/historical/batch.rs`
- **current**: Identifier found in `src/historical/batch.rs`
- **custom**: Identifier found in `src/historical/batch.rs`

### D

- **Delivery**: Identifier found in `src/historical/batch.rs`
- **DownloadParams**: Identifier found in `src/historical/batch.rs`
- **data**: Identifier found in `src/historical/batch.rs`
- **databento**: Identifier found in `src/historical/batch.rs`
- **dataset**: Identifier found in `src/historical/batch.rs`
- **date_time_range**: Identifier found in `src/historical/batch.rs`
- **datetime**: Identifier found in `src/historical/batch.rs`
- **datetimerange**: Identifier found in `src/historical/batch.rs`
- **dbn**: Identifier found in `src/historical/batch.rs`
- **debug**: Identifier found in `src/historical/batch.rs`
- **default**: Identifier found in `src/historical/batch.rs`
- **defaults**: Identifier found in `src/historical/batch.rs`
- **delivered**: Identifier found in `src/historical/batch.rs`
- **delivery**: Identifier found in `src/historical/batch.rs`
- **derive**: Identifier found in `src/historical/batch.rs`
- **description**: Identifier found in `src/historical/batch.rs`
- **deserialize**: Identifier found in `src/historical/batch.rs`
- **deserialize_compression**: Identifier found in `src/historical/batch.rs`
- **deserialize_date_time**: Identifier found in `src/historical/batch.rs`
- **deserialize_opt_date_time**: Identifier found in `src/historical/batch.rs`
- **deserialize_with**: Identifier found in `src/historical/batch.rs`
- **deserializer**: Identifier found in `src/historical/batch.rs`
- **details**: Identifier found in `src/historical/batch.rs`
- **digest**: Identifier found in `src/historical/batch.rs`
- **directory**: Identifier found in `src/historical/batch.rs`
- **display**: Identifier found in `src/historical/batch.rs`
- **div**: Identifier found in `src/historical/batch.rs`
- **does**: Identifier found in `src/historical/batch.rs`
- **dollars**: Identifier found in `src/historical/batch.rs`
- **done**: Identifier found in `src/historical/batch.rs`
- **download**: Identifier found in `src/historical/batch.rs`
- **download_file**: Identifier found in `src/historical/batch.rs`
- **downloaded**: Identifier found in `src/historical/batch.rs`
- **downloading**: Identifier found in `src/historical/batch.rs`
- **downloadparams**: Identifier found in `src/historical/batch.rs`
- **downloads**: Identifier found in `src/historical/batch.rs`
- **duration**: Identifier found in `src/historical/batch.rs`

### E

- **END**: Identifier found in `src/historical/batch.rs`
- **each**: Identifier found in `src/historical/batch.rs`
- **else**: Identifier found in `src/historical/batch.rs`
- **encode_hex**: Identifier found in `src/historical/batch.rs`
- **encoded**: Identifier found in `src/historical/batch.rs`
- **encoding**: Identifier found in `src/historical/batch.rs`
- **encounters**: Identifier found in `src/historical/batch.rs`
- **end**: Identifier found in `src/historical/batch.rs`
- **endpoints**: Identifier found in `src/historical/batch.rs`
- **enum**: Identifier found in `src/historical/batch.rs`
- **enums**: Identifier found in `src/historical/batch.rs`
- **equal**: Identifier found in `src/historical/batch.rs`
- **err**: Identifier found in `src/historical/batch.rs`
- **error**: Identifier found in `src/historical/batch.rs`
- **errors**: Identifier found in `src/historical/batch.rs`
- **except**: Identifier found in `src/historical/batch.rs`
- **exclusive**: Identifier found in `src/historical/batch.rs`
- **existing**: Identifier found in `src/historical/batch.rs`
- **exists**: Identifier found in `src/historical/batch.rs`
- **exp_hash_hex**: Identifier found in `src/historical/batch.rs`
- **exp_size**: Identifier found in `src/historical/batch.rs`
- **expected**: Identifier found in `src/historical/batch.rs`
- **expire**: Identifier found in `src/historical/batch.rs`
- **expired**: Identifier found in `src/historical/batch.rs`

### F

- **f64**: Identifier found in `src/historical/batch.rs`
- **failed**: Identifier found in `src/historical/batch.rs`
- **fails**: Identifier found in `src/historical/batch.rs`
- **false**: Identifier found in `src/historical/batch.rs`
- **field**: Identifier found in `src/historical/batch.rs`
- **file**: Identifier found in `src/historical/batch.rs`
- **file_desc**: Identifier found in `src/historical/batch.rs`
- **file_name**: Identifier found in `src/historical/batch.rs`
- **filename**: Identifier found in `src/historical/batch.rs`
- **filename_to_download**: Identifier found in `src/historical/batch.rs`
- **files**: Identifier found in `src/historical/batch.rs`
- **filter**: Identifier found in `src/historical/batch.rs`
- **filtering**: Identifier found in `src/historical/batch.rs`
- **filters**: Identifier found in `src/historical/batch.rs`
- **finalize**: Identifier found in `src/historical/batch.rs`
- **find**: Identifier found in `src/historical/batch.rs`
- **finished**: Identifier found in `src/historical/batch.rs`
- **fixed**: Identifier found in `src/historical/batch.rs`
- **fmt**: Identifier found in `src/historical/batch.rs`
- **fold**: Identifier found in `src/historical/batch.rs`
- **form**: Identifier found in `src/historical/batch.rs`
- **format**: Identifier found in `src/historical/batch.rs`
- **formats**: Identifier found in `src/historical/batch.rs`
- **formatted**: Identifier found in `src/historical/batch.rs`
- **formatter**: Identifier found in `src/historical/batch.rs`
- **found**: Identifier found in `src/historical/batch.rs`
- **from**: Identifier found in `src/historical/batch.rs`
- **from_str**: Identifier found in `src/historical/batch.rs`
- **fromstr**: Identifier found in `src/historical/batch.rs`
- **function**: Identifier found in `src/historical/batch.rs`
- **futures**: Identifier found in `src/historical/batch.rs`

### G

- **get_with_path**: Identifier found in `src/historical/batch.rs`
- **given**: Identifier found in `src/historical/batch.rs`
- **greater**: Identifier found in `src/historical/batch.rs`
- **group**: Identifier found in `src/historical/batch.rs`

### H

- **Header**: Identifier found in `src/historical/batch.rs`
- **handle_response**: Identifier found in `src/historical/batch.rs`
- **handles**: Identifier found in `src/historical/batch.rs`
- **hash**: Identifier found in `src/historical/batch.rs`
- **hash_algo**: Identifier found in `src/historical/batch.rs`
- **hash_hex**: Identifier found in `src/historical/batch.rs`
- **hasher**: Identifier found in `src/historical/batch.rs`
- **hashmap**: Identifier found in `src/historical/batch.rs`
- **header**: Identifier found in `src/historical/batch.rs`
- **hex**: Identifier found in `src/historical/batch.rs`
- **historical**: Identifier found in `src/historical/batch.rs`
- **https**: Identifier found in `src/historical/batch.rs`
- **https_url**: Identifier found in `src/historical/batch.rs`

### I

- **identifier**: Identifier found in `src/historical/batch.rs`
- **identifiers**: Identifier found in `src/historical/batch.rs`
- **impl**: Identifier found in `src/historical/batch.rs`
- **include**: Identifier found in `src/historical/batch.rs`
- **included**: Identifier found in `src/historical/batch.rs`
- **including**: Identifier found in `src/historical/batch.rs`
- **inclusive**: Identifier found in `src/historical/batch.rs`
- **incur**: Identifier found in `src/historical/batch.rs`
- **indicates**: Identifier found in `src/historical/batch.rs`
- **individual**: Identifier found in `src/historical/batch.rs`
- **info**: Identifier found in `src/historical/batch.rs`
- **info_span**: Identifier found in `src/historical/batch.rs`
- **inner**: Identifier found in `src/historical/batch.rs`
- **input**: Identifier found in `src/historical/batch.rs`
- **instrument**: Identifier found in `src/historical/batch.rs`
- **instrument_id**: Identifier found in `src/historical/batch.rs`
- **instrumentid**: Identifier found in `src/historical/batch.rs`
- **integer**: Identifier found in `src/historical/batch.rs`
- **internal**: Identifier found in `src/historical/batch.rs`
- **interval**: Identifier found in `src/historical/batch.rs`
- **into**: Identifier found in `src/historical/batch.rs`
- **into_iter**: Identifier found in `src/historical/batch.rs`
- **is_dir**: Identifier found in `src/historical/batch.rs`
- **is_empty**: Identifier found in `src/historical/batch.rs`
- **iso**: Identifier found in `src/historical/batch.rs`
- **issue**: Identifier found in `src/historical/batch.rs`
- **itch**: Identifier found in `src/historical/batch.rs`
- **iter**: Identifier found in `src/historical/batch.rs`

### J

- **JSON**: Identifier found in `src/historical/batch.rs`
- **JobState**: Identifier found in `src/historical/batch.rs`
- **job**: Identifier found in `src/historical/batch.rs`
- **job_desc**: Identifier found in `src/historical/batch.rs`
- **job_descs**: Identifier found in `src/historical/batch.rs`
- **job_dir**: Identifier found in `src/historical/batch.rs`
- **job_files**: Identifier found in `src/historical/batch.rs`
- **job_id**: Identifier found in `src/historical/batch.rs`
- **jobs**: Identifier found in `src/historical/batch.rs`
- **jobstate**: Identifier found in `src/historical/batch.rs`
- **join**: Identifier found in `src/historical/batch.rs`
- **json**: Identifier found in `src/historical/batch.rs`

### K

- **key**: Identifier found in `src/historical/batch.rs`

### L

- **ListJobsParams**: Identifier found in `src/historical/batch.rs`
- **larger**: Identifier found in `src/historical/batch.rs`
- **len**: Identifier found in `src/historical/batch.rs`
- **less**: Identifier found in `src/historical/batch.rs`
- **limit**: Identifier found in `src/historical/batch.rs`
- **list**: Identifier found in `src/historical/batch.rs`
- **list_files**: Identifier found in `src/historical/batch.rs`
- **list_jobs**: Identifier found in `src/historical/batch.rs`
- **listjobsparams**: Identifier found in `src/historical/batch.rs`
- **lists**: Identifier found in `src/historical/batch.rs`
- **longer**: Identifier found in `src/historical/batch.rs`
- **look**: Identifier found in `src/historical/batch.rs`
- **loop**: Identifier found in `src/historical/batch.rs`

### M

- **MAX_RETRIES**: Identifier found in `src/historical/batch.rs`
- **macros**: Identifier found in `src/historical/batch.rs`
- **map**: Identifier found in `src/historical/batch.rs`
- **map_err**: Identifier found in `src/historical/batch.rs`
- **map_symbols**: Identifier found in `src/historical/batch.rs`
- **match**: Identifier found in `src/historical/batch.rs`
- **matchers**: Identifier found in `src/historical/batch.rs`
- **matches**: Identifier found in `src/historical/batch.rs`
- **max_retries**: Identifier found in `src/historical/batch.rs`
- **maximum**: Identifier found in `src/historical/batch.rs`
- **means**: Identifier found in `src/historical/batch.rs`
- **mechanism**: Identifier found in `src/historical/batch.rs`
- **metadata**: Identifier found in `src/historical/batch.rs`
- **method**: Identifier found in `src/historical/batch.rs`
- **missing**: Identifier found in `src/historical/batch.rs`
- **mock**: Identifier found in `src/historical/batch.rs`
- **mock_server**: Identifier found in `src/historical/batch.rs`
- **mockserver**: Identifier found in `src/historical/batch.rs`
- **mod**: Identifier found in `src/historical/batch.rs`
- **mode**: Identifier found in `src/historical/batch.rs`
- **month**: Identifier found in `src/historical/batch.rs`
- **mount**: Identifier found in `src/historical/batch.rs`
- **move**: Identifier found in `src/historical/batch.rs`
- **msft**: Identifier found in `src/historical/batch.rs`
- **multiple**: Identifier found in `src/historical/batch.rs`
- **must**: Identifier found in `src/historical/batch.rs`
- **mut**: Identifier found in `src/historical/batch.rs`

### N

- **name**: Identifier found in `src/historical/batch.rs`
- **need**: Identifier found in `src/historical/batch.rs`
- **next**: Identifier found in `src/historical/batch.rs`
- **none**: Identifier found in `src/historical/batch.rs`
- **nonzerou64**: Identifier found in `src/historical/batch.rs`
- **null**: Identifier found in `src/historical/batch.rs`
- **num**: Identifier found in `src/historical/batch.rs`
- **number**: Identifier found in `src/historical/batch.rs`

### O

- **offsetdatetime**: Identifier found in `src/historical/batch.rs`
- **ok_or_else**: Identifier found in `src/historical/batch.rs`
- **once**: Identifier found in `src/historical/batch.rs`
- **only**: Identifier found in `src/historical/batch.rs`
- **open**: Identifier found in `src/historical/batch.rs`
- **openoptions**: Identifier found in `src/historical/batch.rs`
- **opt**: Identifier found in `src/historical/batch.rs`
- **option**: Identifier found in `src/historical/batch.rs`
- **optional**: Identifier found in `src/historical/batch.rs`
- **ordering**: Identifier found in `src/historical/batch.rs`
- **other**: Identifier found in `src/historical/batch.rs`
- **otherwise**: Identifier found in `src/historical/batch.rs`
- **output**: Identifier found in `src/historical/batch.rs`
- **output_dir**: Identifier found in `src/historical/batch.rs`
- **output_path**: Identifier found in `src/historical/batch.rs`

### P

- **PATH_PREFIX**: Identifier found in `src/historical/batch.rs`
- **package_size**: Identifier found in `src/historical/batch.rs`
- **packaging**: Identifier found in `src/historical/batch.rs`
- **parameters**: Identifier found in `src/historical/batch.rs`
- **params**: Identifier found in `src/historical/batch.rs`
- **parse**: Identifier found in `src/historical/batch.rs`
- **partialeq**: Identifier found in `src/historical/batch.rs`
- **path**: Identifier found in `src/historical/batch.rs`
- **path_prefix**: Identifier found in `src/historical/batch.rs`
- **pathbuf**: Identifier found in `src/historical/batch.rs`
- **paths**: Identifier found in `src/historical/batch.rs`
- **per**: Identifier found in `src/historical/batch.rs`
- **portal**: Identifier found in `src/historical/batch.rs`
- **post**: Identifier found in `src/historical/batch.rs`
- **precision**: Identifier found in `src/historical/batch.rs`
- **preset**: Identifier found in `src/historical/batch.rs`
- **pretty_px**: Identifier found in `src/historical/batch.rs`
- **pretty_ts**: Identifier found in `src/historical/batch.rs`
- **prev_downloaded_bytes**: Identifier found in `src/historical/batch.rs`
- **previous**: Identifier found in `src/historical/batch.rs`
- **prices**: Identifier found in `src/historical/batch.rs`
- **prior**: Identifier found in `src/historical/batch.rs`
- **process**: Identifier found in `src/historical/batch.rs`
- **processed**: Identifier found in `src/historical/batch.rs`
- **processing**: Identifier found in `src/historical/batch.rs`
- **progress**: Identifier found in `src/historical/batch.rs`
- **protocol**: Identifier found in `src/historical/batch.rs`
- **pub**: Identifier found in `src/historical/batch.rs`
- **purposes**: Identifier found in `src/historical/batch.rs`
- **push**: Identifier found in `src/historical/batch.rs`

### Q

- **query**: Identifier found in `src/historical/batch.rs`
- **query_param_is_missing**: Identifier found in `src/historical/batch.rs`
- **queued**: Identifier found in `src/historical/batch.rs`

### R

- **range**: Identifier found in `src/historical/batch.rs`
- **raw**: Identifier found in `src/historical/batch.rs`
- **raw_symbol**: Identifier found in `src/historical/batch.rs`
- **rawsymbol**: Identifier found in `src/historical/batch.rs`
- **ready**: Identifier found in `src/historical/batch.rs`
- **received**: Identifier found in `src/historical/batch.rs`
- **record**: Identifier found in `src/historical/batch.rs`
- **record_count**: Identifier found in `src/historical/batch.rs`
- **records**: Identifier found in `src/historical/batch.rs`
- **reducing**: Identifier found in `src/historical/batch.rs`
- **ref**: Identifier found in `src/historical/batch.rs`
- **representation**: Identifier found in `src/historical/batch.rs`
- **req**: Identifier found in `src/historical/batch.rs`
- **request**: Identifier found in `src/historical/batch.rs`
- **requestbuilder**: Identifier found in `src/historical/batch.rs`
- **requested**: Identifier found in `src/historical/batch.rs`
- **reqwest**: Identifier found in `src/historical/batch.rs`
- **reqwestform**: Identifier found in `src/historical/batch.rs`
- **res**: Identifier found in `src/historical/batch.rs`
- **resp**: Identifier found in `src/historical/batch.rs`
- **respond_with**: Identifier found in `src/historical/batch.rs`
- **responsetemplate**: Identifier found in `src/historical/batch.rs`
- **result**: Identifier found in `src/historical/batch.rs`
- **resumed**: Identifier found in `src/historical/batch.rs`
- **resuming**: Identifier found in `src/historical/batch.rs`
- **retries**: Identifier found in `src/historical/batch.rs`
- **retry**: Identifier found in `src/historical/batch.rs`
- **retrying**: Identifier found in `src/historical/batch.rs`
- **return**: Identifier found in `src/historical/batch.rs`
- **returns**: Identifier found in `src/historical/batch.rs`

### S

- **SCHEMA**: Identifier found in `src/historical/batch.rs`
- **START**: Identifier found in `src/historical/batch.rs`
- **Some**: Identifier found in `src/historical/batch.rs`
- **SplitDuration**: Identifier found in `src/historical/batch.rs`
- **SplitSize**: Identifier found in `src/historical/batch.rs`
- **SubmitJobParams**: Identifier found in `src/historical/batch.rs`
- **scalar**: Identifier found in `src/historical/batch.rs`
- **scale**: Identifier found in `src/historical/batch.rs`
- **schema**: Identifier found in `src/historical/batch.rs`
- **self**: Identifier found in `src/historical/batch.rs`
- **send**: Identifier found in `src/historical/batch.rs`
- **serde**: Identifier found in `src/historical/batch.rs`
- **serde_json**: Identifier found in `src/historical/batch.rs`
- **serialized**: Identifier found in `src/historical/batch.rs`
- **set_body_json**: Identifier found in `src/historical/batch.rs`
- **setter**: Identifier found in `src/historical/batch.rs`
- **sha2**: Identifier found in `src/historical/batch.rs`
- **sha256**: Identifier found in `src/historical/batch.rs`
- **since**: Identifier found in `src/historical/batch.rs`
- **size**: Identifier found in `src/historical/batch.rs`
- **skip**: Identifier found in `src/historical/batch.rs`
- **skipping**: Identifier found in `src/historical/batch.rs`
- **slug**: Identifier found in `src/historical/batch.rs`
- **some**: Identifier found in `src/historical/batch.rs`
- **span**: Identifier found in `src/historical/batch.rs`
- **specified**: Identifier found in `src/historical/batch.rs`
- **split**: Identifier found in `src/historical/batch.rs`
- **split_duration**: Identifier found in `src/historical/batch.rs`
- **split_once**: Identifier found in `src/historical/batch.rs`
- **split_size**: Identifier found in `src/historical/batch.rs`
- **split_symbols**: Identifier found in `src/historical/batch.rs`
- **splitduration**: Identifier found in `src/historical/batch.rs`
- **splitsize**: Identifier found in `src/historical/batch.rs`
- **splitting**: Identifier found in `src/historical/batch.rs`
- **start**: Identifier found in `src/historical/batch.rs`
- **starts**: Identifier found in `src/historical/batch.rs`
- **state**: Identifier found in `src/historical/batch.rs`
- **states**: Identifier found in `src/historical/batch.rs`
- **states_str**: Identifier found in `src/historical/batch.rs`
- **static**: Identifier found in `src/historical/batch.rs`
- **status**: Identifier found in `src/historical/batch.rs`
- **statuscode**: Identifier found in `src/historical/batch.rs`
- **std**: Identifier found in `src/historical/batch.rs`
- **str**: Identifier found in `src/historical/batch.rs`
- **stream**: Identifier found in `src/historical/batch.rs`
- **streamext**: Identifier found in `src/historical/batch.rs`
- **string**: Identifier found in `src/historical/batch.rs`
- **strings**: Identifier found in `src/historical/batch.rs`
- **strip_option**: Identifier found in `src/historical/batch.rs`
- **struct**: Identifier found in `src/historical/batch.rs`
- **stype**: Identifier found in `src/historical/batch.rs`
- **stype_in**: Identifier found in `src/historical/batch.rs`
- **stype_out**: Identifier found in `src/historical/batch.rs`
- **submit_job**: Identifier found in `src/historical/batch.rs`
- **submitjobparams**: Identifier found in `src/historical/batch.rs`
- **submits**: Identifier found in `src/historical/batch.rs`
- **submitted**: Identifier found in `src/historical/batch.rs`
- **successfully**: Identifier found in `src/historical/batch.rs`
- **sunday**: Identifier found in `src/historical/batch.rs`
- **super**: Identifier found in `src/historical/batch.rs`
- **supported**: Identifier found in `src/historical/batch.rs`
- **symbol**: Identifier found in `src/historical/batch.rs`
- **symbology**: Identifier found in `src/historical/batch.rs`
- **symbols**: Identifier found in `src/historical/batch.rs`

### T

- **Test**: Identifier found in `src/historical/batch.rs`
- **target**: Identifier found in `src/historical/batch.rs`
- **test**: Identifier found in `src/historical/batch.rs`
- **test_deserialize_compression**: Identifier found in `src/historical/batch.rs`
- **test_infra**: Identifier found in `src/historical/batch.rs`
- **test_list_jobs**: Identifier found in `src/historical/batch.rs`
- **test_submit_job**: Identifier found in `src/historical/batch.rs`
- **test_user**: Identifier found in `src/historical/batch.rs`
- **tests**: Identifier found in `src/historical/batch.rs`
- **text**: Identifier found in `src/historical/batch.rs`
- **than**: Identifier found in `src/historical/batch.rs`
- **there**: Identifier found in `src/historical/batch.rs`
- **this**: Identifier found in `src/historical/batch.rs`
- **time**: Identifier found in `src/historical/batch.rs`
- **timestamp**: Identifier found in `src/historical/batch.rs`
- **timestamps**: Identifier found in `src/historical/batch.rs`
- **to_api_string**: Identifier found in `src/historical/batch.rs`
- **to_owned**: Identifier found in `src/historical/batch.rs`
- **to_string**: Identifier found in `src/historical/batch.rs`
- **tohex**: Identifier found in `src/historical/batch.rs`
- **tokio**: Identifier found in `src/historical/batch.rs`
- **tostring**: Identifier found in `src/historical/batch.rs`
- **total**: Identifier found in `src/historical/batch.rs`
- **total_bytes**: Identifier found in `src/historical/batch.rs`
- **tracing**: Identifier found in `src/historical/batch.rs`
- **trades**: Identifier found in `src/historical/batch.rs`
- **transform**: Identifier found in `src/historical/batch.rs`
- **true**: Identifier found in `src/historical/batch.rs`
- **ts_event**: Identifier found in `src/historical/batch.rs`
- **ts_expiration**: Identifier found in `src/historical/batch.rs`
- **ts_process_done**: Identifier found in `src/historical/batch.rs`
- **ts_process_start**: Identifier found in `src/historical/batch.rs`
- **ts_queued**: Identifier found in `src/historical/batch.rs`
- **ts_received**: Identifier found in `src/historical/batch.rs`
- **ts_recv**: Identifier found in `src/historical/batch.rs`
- **tsla**: Identifier found in `src/historical/batch.rs`
- **type**: Identifier found in `src/historical/batch.rs`
- **type_name**: Identifier found in `src/historical/batch.rs`
- **typed_builder**: Identifier found in `src/historical/batch.rs`
- **typedbuilder**: Identifier found in `src/historical/batch.rs`

### U

- **u64**: Identifier found in `src/historical/batch.rs`
- **unable**: Identifier found in `src/historical/batch.rs`
- **unexpected**: Identifier found in `src/historical/batch.rs`
- **unique**: Identifier found in `src/historical/batch.rs`
- **unix_timestamp_nanos**: Identifier found in `src/historical/batch.rs`
- **unsupported**: Identifier found in `src/historical/batch.rs`
- **until**: Identifier found in `src/historical/batch.rs`
- **unwrap**: Identifier found in `src/historical/batch.rs`
- **unwrap_or**: Identifier found in `src/historical/batch.rs`
- **update**: Identifier found in `src/historical/batch.rs`
- **url**: Identifier found in `src/historical/batch.rs`
- **urls**: Identifier found in `src/historical/batch.rs`
- **used**: Identifier found in `src/historical/batch.rs`
- **user**: Identifier found in `src/historical/batch.rs`
- **user_id**: Identifier found in `src/historical/batch.rs`
- **using**: Identifier found in `src/historical/batch.rs`
- **usize**: Identifier found in `src/historical/batch.rs`
- **utc**: Identifier found in `src/historical/batch.rs`

### V

- **val**: Identifier found in `src/historical/batch.rs`
- **valid**: Identifier found in `src/historical/batch.rs`
- **validation**: Identifier found in `src/historical/batch.rs`
- **variant**: Identifier found in `src/historical/batch.rs`
- **vec**: Identifier found in `src/historical/batch.rs`
- **verified**: Identifier found in `src/historical/batch.rs`
- **verify_hash**: Identifier found in `src/historical/batch.rs`
- **via**: Identifier found in `src/historical/batch.rs`

### W

- **warn**: Identifier found in `src/historical/batch.rs`
- **warning**: Identifier found in `src/historical/batch.rs`
- **week**: Identifier found in `src/historical/batch.rs`
- **when**: Identifier found in `src/historical/batch.rs`
- **which**: Identifier found in `src/historical/batch.rs`
- **while**: Identifier found in `src/historical/batch.rs`
- **will**: Identifier found in `src/historical/batch.rs`
- **wiremock**: Identifier found in `src/historical/batch.rs`
- **with**: Identifier found in `src/historical/batch.rs`
- **with_capacity**: Identifier found in `src/historical/batch.rs`
- **write**: Identifier found in `src/historical/batch.rs`
- **write_str**: Identifier found in `src/historical/batch.rs`

### X

- **xnas**: Identifier found in `src/historical/batch.rs`
- **xnasitch**: Identifier found in `src/historical/batch.rs`

### Z

- **zstd**: Identifier found in `src/historical/batch.rs`
