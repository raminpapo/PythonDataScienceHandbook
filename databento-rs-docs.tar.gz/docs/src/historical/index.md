# Index: src/historical

## Contents


### Files

- [batch.rs](./batch.rs_docs.md)
- [client.rs](./client.rs_docs.md)
- [metadata.rs](./metadata.rs_docs.md)
- [symbology.rs](./symbology.rs_docs.md)
- [timeseries.rs](./timeseries.rs_docs.md)
