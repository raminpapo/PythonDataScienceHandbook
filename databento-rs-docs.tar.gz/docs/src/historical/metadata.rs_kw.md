# Keywords: metadata.rs

## Extracted Keywords

Total keywords extracted: 336


### A

- **about**: Identifier found in `src/historical/metadata.rs`
- **add_to_form**: Identifier found in `src/historical/metadata.rs`
- **add_to_query**: Identifier found in `src/historical/metadata.rs`
- **addtoform**: Identifier found in `src/historical/metadata.rs`
- **addtoquery**: Identifier found in `src/historical/metadata.rs`
- **any**: Identifier found in `src/historical/metadata.rs`
- **api**: Identifier found in `src/historical/metadata.rs`
- **api_key**: Identifier found in `src/historical/metadata.rs`
- **api_version**: Identifier found in `src/historical/metadata.rs`
- **as_ref**: Identifier found in `src/historical/metadata.rs`
- **as_str**: Identifier found in `src/historical/metadata.rs`
- **as_u16**: Identifier found in `src/historical/metadata.rs`
- **asref**: Identifier found in `src/historical/metadata.rs`
- **assert_eq**: Identifier found in `src/historical/metadata.rs`
- **assigned**: Identifier found in `src/historical/metadata.rs`
- **async**: Identifier found in `src/historical/metadata.rs`
- **availability**: Identifier found in `src/historical/metadata.rs`
- **available**: Identifier found in `src/historical/metadata.rs`
- **await**: Identifier found in `src/historical/metadata.rs`

### B

- **basic_auth**: Identifier found in `src/historical/metadata.rs`
- **batch**: Identifier found in `src/historical/metadata.rs`
- **batched**: Identifier found in `src/historical/metadata.rs`
- **bbo**: Identifier found in `src/historical/metadata.rs`
- **billable**: Identifier found in `src/historical/metadata.rs`
- **binary**: Identifier found in `src/historical/metadata.rs`
- **build**: Identifier found in `src/historical/metadata.rs`
- **builder**: Identifier found in `src/historical/metadata.rs`

### C

- **cfg**: Identifier found in `src/historical/metadata.rs`
- **client**: Identifier found in `src/historical/metadata.rs`
- **clone**: Identifier found in `src/historical/metadata.rs`
- **close**: Identifier found in `src/historical/metadata.rs`
- **code**: Identifier found in `src/historical/metadata.rs`
- **codes**: Identifier found in `src/historical/metadata.rs`
- **collections**: Identifier found in `src/historical/metadata.rs`
- **communicate**: Identifier found in `src/historical/metadata.rs`
- **condition**: Identifier found in `src/historical/metadata.rs`
- **const**: Identifier found in `src/historical/metadata.rs`
- **convert**: Identifier found in `src/historical/metadata.rs`
- **converts**: Identifier found in `src/historical/metadata.rs`
- **copy**: Identifier found in `src/historical/metadata.rs`
- **correctness**: Identifier found in `src/historical/metadata.rs`
- **cost**: Identifier found in `src/historical/metadata.rs`
- **count**: Identifier found in `src/historical/metadata.rs`
- **crate**: Identifier found in `src/historical/metadata.rs`
- **csv**: Identifier found in `src/historical/metadata.rs`
- **custom**: Identifier found in `src/historical/metadata.rs`

### D

- **DATASET**: Identifier found in `src/historical/metadata.rs`
- **Databento**: Identifier found in `src/historical/metadata.rs`
- **DatasetCondition**: Identifier found in `src/historical/metadata.rs`
- **DatasetConditionDetail**: Identifier found in `src/historical/metadata.rs`
- **DatasetRange**: Identifier found in `src/historical/metadata.rs`
- **data**: Identifier found in `src/historical/metadata.rs`
- **databento**: Identifier found in `src/historical/metadata.rs`
- **dataset**: Identifier found in `src/historical/metadata.rs`
- **datasetcondition**: Identifier found in `src/historical/metadata.rs`
- **datasetconditiondetail**: Identifier found in `src/historical/metadata.rs`
- **datasetrange**: Identifier found in `src/historical/metadata.rs`
- **date**: Identifier found in `src/historical/metadata.rs`
- **date_format**: Identifier found in `src/historical/metadata.rs`
- **date_range**: Identifier found in `src/historical/metadata.rs`
- **date_str**: Identifier found in `src/historical/metadata.rs`
- **date_time_range**: Identifier found in `src/historical/metadata.rs`
- **daterange**: Identifier found in `src/historical/metadata.rs`
- **dates**: Identifier found in `src/historical/metadata.rs`
- **datetime**: Identifier found in `src/historical/metadata.rs`
- **datetimerange**: Identifier found in `src/historical/metadata.rs`
- **days**: Identifier found in `src/historical/metadata.rs`
- **dbn**: Identifier found in `src/historical/metadata.rs`
- **debug**: Identifier found in `src/historical/metadata.rs`
- **default**: Identifier found in `src/historical/metadata.rs`
- **defaults**: Identifier found in `src/historical/metadata.rs`
- **degraded**: Identifier found in `src/historical/metadata.rs`
- **denotes**: Identifier found in `src/historical/metadata.rs`
- **derive**: Identifier found in `src/historical/metadata.rs`
- **described**: Identifier found in `src/historical/metadata.rs`
- **describing**: Identifier found in `src/historical/metadata.rs`
- **description**: Identifier found in `src/historical/metadata.rs`
- **deserialize**: Identifier found in `src/historical/metadata.rs`
- **deserialize_date**: Identifier found in `src/historical/metadata.rs`
- **deserialize_date_time**: Identifier found in `src/historical/metadata.rs`
- **deserialize_opt_date**: Identifier found in `src/historical/metadata.rs`
- **deserialize_with**: Identifier found in `src/historical/metadata.rs`
- **deserializer**: Identifier found in `src/historical/metadata.rs`
- **details**: Identifier found in `src/historical/metadata.rs`
- **discounts**: Identifier found in `src/historical/metadata.rs`
- **discover**: Identifier found in `src/historical/metadata.rs`
- **dollars**: Identifier found in `src/historical/metadata.rs`
- **download**: Identifier found in `src/historical/metadata.rs`
- **duration**: Identifier found in `src/historical/metadata.rs`

### E

- **ENC**: Identifier found in `src/historical/metadata.rs`
- **each**: Identifier found in `src/historical/metadata.rs`
- **enc**: Identifier found in `src/historical/metadata.rs`
- **encoding**: Identifier found in `src/historical/metadata.rs`
- **end**: Identifier found in `src/historical/metadata.rs`
- **end_date**: Identifier found in `src/historical/metadata.rs`
- **endpoints**: Identifier found in `src/historical/metadata.rs`
- **entitlements**: Identifier found in `src/historical/metadata.rs`
- **enum**: Identifier found in `src/historical/metadata.rs`
- **enums**: Identifier found in `src/historical/metadata.rs`
- **err**: Identifier found in `src/historical/metadata.rs`
- **error**: Identifier found in `src/historical/metadata.rs`
- **errors**: Identifier found in `src/historical/metadata.rs`
- **exclusive**: Identifier found in `src/historical/metadata.rs`
- **exp**: Identifier found in `src/historical/metadata.rs`

### F

- **FeedMode**: Identifier found in `src/historical/metadata.rs`
- **FieldDetail**: Identifier found in `src/historical/metadata.rs`
- **f64**: Identifier found in `src/historical/metadata.rs`
- **fails**: Identifier found in `src/historical/metadata.rs`
- **feed**: Identifier found in `src/historical/metadata.rs`
- **feedmode**: Identifier found in `src/historical/metadata.rs`
- **field**: Identifier found in `src/historical/metadata.rs`
- **fielddetail**: Identifier found in `src/historical/metadata.rs`
- **fields**: Identifier found in `src/historical/metadata.rs`
- **files**: Identifier found in `src/historical/metadata.rs`
- **filter**: Identifier found in `src/historical/metadata.rs`
- **flat**: Identifier found in `src/historical/metadata.rs`
- **form**: Identifier found in `src/historical/metadata.rs`
- **format**: Identifier found in `src/historical/metadata.rs`
- **format_args**: Identifier found in `src/historical/metadata.rs`
- **from**: Identifier found in `src/historical/metadata.rs`
- **from_str**: Identifier found in `src/historical/metadata.rs`
- **fromstr**: Identifier found in `src/historical/metadata.rs`
- **function**: Identifier found in `src/historical/metadata.rs`

### G

- **GetDatasetConditionParams**: Identifier found in `src/historical/metadata.rs`
- **GetQueryParams**: Identifier found in `src/historical/metadata.rs`
- **generated**: Identifier found in `src/historical/metadata.rs`
- **get_billable_size**: Identifier found in `src/historical/metadata.rs`
- **get_cost**: Identifier found in `src/historical/metadata.rs`
- **get_dataset_condition**: Identifier found in `src/historical/metadata.rs`
- **get_dataset_range**: Identifier found in `src/historical/metadata.rs`
- **get_record_count**: Identifier found in `src/historical/metadata.rs`
- **getbillablesizeparams**: Identifier found in `src/historical/metadata.rs`
- **getcostparams**: Identifier found in `src/historical/metadata.rs`
- **getdatasetconditionparams**: Identifier found in `src/historical/metadata.rs`
- **getqueryparams**: Identifier found in `src/historical/metadata.rs`
- **getrecordcountparams**: Identifier found in `src/historical/metadata.rs`
- **gets**: Identifier found in `src/historical/metadata.rs`
- **gigabyte**: Identifier found in `src/historical/metadata.rs`
- **given**: Identifier found in `src/historical/metadata.rs`
- **glbx**: Identifier found in `src/historical/metadata.rs`
- **group**: Identifier found in `src/historical/metadata.rs`

### H

- **handle_response**: Identifier found in `src/historical/metadata.rs`
- **hash**: Identifier found in `src/historical/metadata.rs`
- **hashmap**: Identifier found in `src/historical/metadata.rs`
- **high**: Identifier found in `src/historical/metadata.rs`
- **historical**: Identifier found in `src/historical/metadata.rs`
- **historicalstreaming**: Identifier found in `src/historical/metadata.rs`

### I

- **impl**: Identifier found in `src/historical/metadata.rs`
- **inclusive**: Identifier found in `src/historical/metadata.rs`
- **indicates**: Identifier found in `src/historical/metadata.rs`
- **inner**: Identifier found in `src/historical/metadata.rs`
- **input**: Identifier found in `src/historical/metadata.rs`
- **int64_t**: Identifier found in `src/historical/metadata.rs`
- **internal**: Identifier found in `src/historical/metadata.rs`
- **into**: Identifier found in `src/historical/metadata.rs`
- **intraday**: Identifier found in `src/historical/metadata.rs`
- **issue**: Identifier found in `src/historical/metadata.rs`
- **issues**: Identifier found in `src/historical/metadata.rs`
- **itch**: Identifier found in `src/historical/metadata.rs`

### J

- **json**: Identifier found in `src/historical/metadata.rs`

### K

- **known**: Identifier found in `src/historical/metadata.rs`

### L

- **ListFieldsParams**: Identifier found in `src/historical/metadata.rs`
- **last**: Identifier found in `src/historical/metadata.rs`
- **last_modified_date**: Identifier found in `src/historical/metadata.rs`
- **len**: Identifier found in `src/historical/metadata.rs`
- **limit**: Identifier found in `src/historical/metadata.rs`
- **list_datasets**: Identifier found in `src/historical/metadata.rs`
- **list_fields**: Identifier found in `src/historical/metadata.rs`
- **list_publishers**: Identifier found in `src/historical/metadata.rs`
- **list_schemas**: Identifier found in `src/historical/metadata.rs`
- **list_unit_prices**: Identifier found in `src/historical/metadata.rs`
- **listfieldsparams**: Identifier found in `src/historical/metadata.rs`
- **lists**: Identifier found in `src/historical/metadata.rs`
- **live**: Identifier found in `src/historical/metadata.rs`
- **low**: Identifier found in `src/historical/metadata.rs`

### M

- **MetadataClient**: Identifier found in `src/historical/metadata.rs`
- **macros**: Identifier found in `src/historical/metadata.rs`
- **map_err**: Identifier found in `src/historical/metadata.rs`
- **match**: Identifier found in `src/historical/metadata.rs`
- **matchers**: Identifier found in `src/historical/metadata.rs`
- **maximum**: Identifier found in `src/historical/metadata.rs`
- **may**: Identifier found in `src/historical/metadata.rs`
- **mdp3**: Identifier found in `src/historical/metadata.rs`
- **metadata**: Identifier found in `src/historical/metadata.rs`
- **metadataclient**: Identifier found in `src/historical/metadata.rs`
- **method**: Identifier found in `src/historical/metadata.rs`
- **missing**: Identifier found in `src/historical/metadata.rs`
- **mock**: Identifier found in `src/historical/metadata.rs`
- **mock_server**: Identifier found in `src/historical/metadata.rs`
- **mockserver**: Identifier found in `src/historical/metadata.rs`
- **mod**: Identifier found in `src/historical/metadata.rs`
- **mode**: Identifier found in `src/historical/metadata.rs`
- **modified**: Identifier found in `src/historical/metadata.rs`
- **mount**: Identifier found in `src/historical/metadata.rs`
- **mut**: Identifier found in `src/historical/metadata.rs`

### N

- **name**: Identifier found in `src/historical/metadata.rs`
- **none**: Identifier found in `src/historical/metadata.rs`
- **nonzerou64**: Identifier found in `src/historical/metadata.rs`
- **null**: Identifier found in `src/historical/metadata.rs`
- **num**: Identifier found in `src/historical/metadata.rs`
- **number**: Identifier found in `src/historical/metadata.rs`

### O

- **offsetdatetime**: Identifier found in `src/historical/metadata.rs`
- **ohlcv**: Identifier found in `src/historical/metadata.rs`
- **ohlcv1s**: Identifier found in `src/historical/metadata.rs`
- **open**: Identifier found in `src/historical/metadata.rs`
- **opt_date_str**: Identifier found in `src/historical/metadata.rs`
- **option**: Identifier found in `src/historical/metadata.rs`
- **optional**: Identifier found in `src/historical/metadata.rs`
- **other**: Identifier found in `src/historical/metadata.rs`

### P

- **PublisherDetail**: Identifier found in `src/historical/metadata.rs`
- **param**: Identifier found in `src/historical/metadata.rs`
- **parameters**: Identifier found in `src/historical/metadata.rs`
- **params**: Identifier found in `src/historical/metadata.rs`
- **parse**: Identifier found in `src/historical/metadata.rs`
- **partialeq**: Identifier found in `src/historical/metadata.rs`
- **particular**: Identifier found in `src/historical/metadata.rs`
- **path**: Identifier found in `src/historical/metadata.rs`
- **pending**: Identifier found in `src/historical/metadata.rs`
- **per**: Identifier found in `src/historical/metadata.rs`
- **plans**: Identifier found in `src/historical/metadata.rs`
- **post**: Identifier found in `src/historical/metadata.rs`
- **preset**: Identifier found in `src/historical/metadata.rs`
- **prices**: Identifier found in `src/historical/metadata.rs`
- **provided**: Identifier found in `src/historical/metadata.rs`
- **pub**: Identifier found in `src/historical/metadata.rs`
- **publisher**: Identifier found in `src/historical/metadata.rs`
- **publisher_id**: Identifier found in `src/historical/metadata.rs`
- **publisherdetail**: Identifier found in `src/historical/metadata.rs`
- **publishers**: Identifier found in `src/historical/metadata.rs`
- **push**: Identifier found in `src/historical/metadata.rs`

### Q

- **quality**: Identifier found in `src/historical/metadata.rs`
- **query**: Identifier found in `src/historical/metadata.rs`
- **query_param**: Identifier found in `src/historical/metadata.rs`

### R

- **range**: Identifier found in `src/historical/metadata.rs`
- **range_by_schema**: Identifier found in `src/historical/metadata.rs`
- **ranges**: Identifier found in `src/historical/metadata.rs`
- **rate**: Identifier found in `src/historical/metadata.rs`
- **raw**: Identifier found in `src/historical/metadata.rs`
- **rawsymbol**: Identifier found in `src/historical/metadata.rs`
- **real**: Identifier found in `src/historical/metadata.rs`
- **record**: Identifier found in `src/historical/metadata.rs`
- **records**: Identifier found in `src/historical/metadata.rs`
- **ref**: Identifier found in `src/historical/metadata.rs`
- **rename**: Identifier found in `src/historical/metadata.rs`
- **representation**: Identifier found in `src/historical/metadata.rs`
- **request**: Identifier found in `src/historical/metadata.rs`
- **requestbuilder**: Identifier found in `src/historical/metadata.rs`
- **requests**: Identifier found in `src/historical/metadata.rs`
- **reqwest**: Identifier found in `src/historical/metadata.rs`
- **reqwestform**: Identifier found in `src/historical/metadata.rs`
- **resp**: Identifier found in `src/historical/metadata.rs`
- **respects**: Identifier found in `src/historical/metadata.rs`
- **respond_with**: Identifier found in `src/historical/metadata.rs`
- **responsetemplate**: Identifier found in `src/historical/metadata.rs`
- **result**: Identifier found in `src/historical/metadata.rs`
- **return**: Identifier found in `src/historical/metadata.rs`
- **returns**: Identifier found in `src/historical/metadata.rs`
- **rtype**: Identifier found in `src/historical/metadata.rs`

### S

- **SCHEMA**: Identifier found in `src/historical/metadata.rs`
- **Some**: Identifier found in `src/historical/metadata.rs`
- **schema**: Identifier found in `src/historical/metadata.rs`
- **schemas**: Identifier found in `src/historical/metadata.rs`
- **self**: Identifier found in `src/historical/metadata.rs`
- **send**: Identifier found in `src/historical/metadata.rs`
- **serde**: Identifier found in `src/historical/metadata.rs`
- **serde_json**: Identifier found in `src/historical/metadata.rs`
- **series**: Identifier found in `src/historical/metadata.rs`
- **set_body_json**: Identifier found in `src/historical/metadata.rs`
- **setter**: Identifier found in `src/historical/metadata.rs`
- **several**: Identifier found in `src/historical/metadata.rs`
- **size**: Identifier found in `src/historical/metadata.rs`
- **slug**: Identifier found in `src/historical/metadata.rs`
- **some**: Identifier found in `src/historical/metadata.rs`
- **soon**: Identifier found in `src/historical/metadata.rs`
- **start**: Identifier found in `src/historical/metadata.rs`
- **start_date**: Identifier found in `src/historical/metadata.rs`
- **static**: Identifier found in `src/historical/metadata.rs`
- **statuscode**: Identifier found in `src/historical/metadata.rs`
- **std**: Identifier found in `src/historical/metadata.rs`
- **str**: Identifier found in `src/historical/metadata.rs`
- **streaming**: Identifier found in `src/historical/metadata.rs`
- **string**: Identifier found in `src/historical/metadata.rs`
- **struct**: Identifier found in `src/historical/metadata.rs`
- **stype**: Identifier found in `src/historical/metadata.rs`
- **stype_in**: Identifier found in `src/historical/metadata.rs`
- **super**: Identifier found in `src/historical/metadata.rs`
- **symbology**: Identifier found in `src/historical/metadata.rs`
- **symbols**: Identifier found in `src/historical/metadata.rs`

### T

- **target**: Identifier found in `src/historical/metadata.rs`
- **tbbo**: Identifier found in `src/historical/metadata.rs`
- **test**: Identifier found in `src/historical/metadata.rs`
- **test_get_dataset_condition**: Identifier found in `src/historical/metadata.rs`
- **test_get_dataset_range**: Identifier found in `src/historical/metadata.rs`
- **test_infra**: Identifier found in `src/historical/metadata.rs`
- **test_list_fields**: Identifier found in `src/historical/metadata.rs`
- **test_list_unit_prices**: Identifier found in `src/historical/metadata.rs`
- **tests**: Identifier found in `src/historical/metadata.rs`
- **then**: Identifier found in `src/historical/metadata.rs`
- **there**: Identifier found in `src/historical/metadata.rs`
- **this**: Identifier found in `src/historical/metadata.rs`
- **time**: Identifier found in `src/historical/metadata.rs`
- **timestamp**: Identifier found in `src/historical/metadata.rs`
- **to_api_string**: Identifier found in `src/historical/metadata.rs`
- **to_owned**: Identifier found in `src/historical/metadata.rs`
- **to_string**: Identifier found in `src/historical/metadata.rs`
- **tokio**: Identifier found in `src/historical/metadata.rs`
- **tostring**: Identifier found in `src/historical/metadata.rs`
- **transform**: Identifier found in `src/historical/metadata.rs`
- **ts_event**: Identifier found in `src/historical/metadata.rs`
- **type**: Identifier found in `src/historical/metadata.rs`
- **type_name**: Identifier found in `src/historical/metadata.rs`
- **typed_builder**: Identifier found in `src/historical/metadata.rs`
- **typedbuilder**: Identifier found in `src/historical/metadata.rs`

### U

- **UnitPricesForMode**: Identifier found in `src/historical/metadata.rs`
- **u16**: Identifier found in `src/historical/metadata.rs`
- **u64**: Identifier found in `src/historical/metadata.rs`
- **uint64_t**: Identifier found in `src/historical/metadata.rs`
- **uint8_t**: Identifier found in `src/historical/metadata.rs`
- **unable**: Identifier found in `src/historical/metadata.rs`
- **uncompressed**: Identifier found in `src/historical/metadata.rs`
- **unit**: Identifier found in `src/historical/metadata.rs`
- **unit_prices**: Identifier found in `src/historical/metadata.rs`
- **unitpricesformode**: Identifier found in `src/historical/metadata.rs`
- **unwrap**: Identifier found in `src/historical/metadata.rs`
- **user**: Identifier found in `src/historical/metadata.rs`
- **utc**: Identifier found in `src/historical/metadata.rs`

### V

- **vec**: Identifier found in `src/historical/metadata.rs`
- **venue**: Identifier found in `src/historical/metadata.rs`
- **volume**: Identifier found in `src/historical/metadata.rs`

### W

- **when**: Identifier found in `src/historical/metadata.rs`
- **which**: Identifier found in `src/historical/metadata.rs`
- **will**: Identifier found in `src/historical/metadata.rs`
- **wiremock**: Identifier found in `src/historical/metadata.rs`
- **with**: Identifier found in `src/historical/metadata.rs`

### X

- **xnas**: Identifier found in `src/historical/metadata.rs`

### Y

- **yet**: Identifier found in `src/historical/metadata.rs`
