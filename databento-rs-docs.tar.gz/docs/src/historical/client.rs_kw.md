# Keywords: client.rs

## Extracted Keywords

Total keywords extracted: 270


### A

- **ApiErrorResponse**: Identifier found in `src/historical/client.rs`
- **accept**: Identifier found in `src/historical/client.rs`
- **accessed**: Identifier found in `src/historical/client.rs`
- **advanced**: Identifier found in `src/historical/client.rs`
- **agent**: Identifier found in `src/historical/client.rs`
- **allow**: Identifier found in `src/historical/client.rs`
- **and_then**: Identifier found in `src/historical/client.rs`
- **api**: Identifier found in `src/historical/client.rs`
- **api_err**: Identifier found in `src/historical/client.rs`
- **api_version**: Identifier found in `src/historical/client.rs`
- **apierror**: Identifier found in `src/historical/client.rs`
- **apierrorresponse**: Identifier found in `src/historical/client.rs`
- **apikey**: Identifier found in `src/historical/client.rs`
- **application**: Identifier found in `src/historical/client.rs`
- **as_bytes**: Identifier found in `src/historical/client.rs`
- **as_u16**: Identifier found in `src/historical/client.rs`
- **as_url**: Identifier found in `src/historical/client.rs`
- **assert**: Identifier found in `src/historical/client.rs`
- **async**: Identifier found in `src/historical/client.rs`
- **async_compression**: Identifier found in `src/historical/client.rs`
- **asyncbufreadext**: Identifier found in `src/historical/client.rs`
- **authors**: Identifier found in `src/historical/client.rs`
- **await**: Identifier found in `src/historical/client.rs`

### B

- **BODY**: Identifier found in `src/historical/client.rs`
- **BusinessErrorDetails**: Identifier found in `src/historical/client.rs`
- **bad**: Identifier found in `src/historical/client.rs`
- **bad_arg**: Identifier found in `src/historical/client.rs`
- **bad_gateway**: Identifier found in `src/historical/client.rs`
- **base**: Identifier found in `src/historical/client.rs`
- **base_url**: Identifier found in `src/historical/client.rs`
- **basic_auth**: Identifier found in `src/historical/client.rs`
- **batch**: Identifier found in `src/historical/client.rs`
- **batchclient**: Identifier found in `src/historical/client.rs`
- **before**: Identifier found in `src/historical/client.rs`
- **body**: Identifier found in `src/historical/client.rs`
- **bufread**: Identifier found in `src/historical/client.rs`
- **bufreader**: Identifier found in `src/historical/client.rs`
- **build**: Identifier found in `src/historical/client.rs`
- **builder**: Identifier found in `src/historical/client.rs`
- **business**: Identifier found in `src/historical/client.rs`
- **businesserrordetails**: Identifier found in `src/historical/client.rs`
- **bytes**: Identifier found in `src/historical/client.rs`
- **bytes_stream**: Identifier found in `src/historical/client.rs`

### C

- **Client**: Identifier found in `src/historical/client.rs`
- **ClientBuilder**: Identifier found in `src/historical/client.rs`
- **call**: Identifier found in `src/historical/client.rs`
- **cfg**: Identifier found in `src/historical/client.rs`
- **check_http_error**: Identifier found in `src/historical/client.rs`
- **check_http_error_non_json**: Identifier found in `src/historical/client.rs`
- **check_warnings**: Identifier found in `src/historical/client.rs`
- **client**: Identifier found in `src/historical/client.rs`
- **clientbuilder**: Identifier found in `src/historical/client.rs`
- **clone**: Identifier found in `src/historical/client.rs`
- **configured**: Identifier found in `src/historical/client.rs`
- **const**: Identifier found in `src/historical/client.rs`
- **copy**: Identifier found in `src/historical/client.rs`
- **crate**: Identifier found in `src/historical/client.rs`
- **created**: Identifier found in `src/historical/client.rs`
- **creates**: Identifier found in `src/historical/client.rs`

### D

- **data**: Identifier found in `src/historical/client.rs`
- **databento_api_key**: Identifier found in `src/historical/client.rs`
- **dbn**: Identifier found in `src/historical/client.rs`
- **debug**: Identifier found in `src/historical/client.rs`
- **decode**: Identifier found in `src/historical/client.rs`
- **default**: Identifier found in `src/historical/client.rs`
- **default_headers**: Identifier found in `src/historical/client.rs`
- **deprecated**: Identifier found in `src/historical/client.rs`
- **derive**: Identifier found in `src/historical/client.rs`
- **derived**: Identifier found in `src/historical/client.rs`
- **deserialize**: Identifier found in `src/historical/client.rs`
- **deserialize_json**: Identifier found in `src/historical/client.rs`
- **deserializeowned**: Identifier found in `src/historical/client.rs`
- **detail**: Identifier found in `src/historical/client.rs`
- **doc**: Identifier found in `src/historical/client.rs`
- **docs**: Identifier found in `src/historical/client.rs`
- **docs_url**: Identifier found in `src/historical/client.rs`
- **downloads**: Identifier found in `src/historical/client.rs`

### E

- **else**: Identifier found in `src/historical/client.rs`
- **enum**: Identifier found in `src/historical/client.rs`
- **environment**: Identifier found in `src/historical/client.rs`
- **err**: Identifier found in `src/historical/client.rs`
- **error**: Identifier found in `src/historical/client.rs`
- **errors**: Identifier found in `src/historical/client.rs`
- **expected**: Identifier found in `src/historical/client.rs`
- **ext**: Identifier found in `src/historical/client.rs`
- **extends**: Identifier found in `src/historical/client.rs`
- **extension**: Identifier found in `src/historical/client.rs`

### F

- **failed**: Identifier found in `src/historical/client.rs`
- **fails**: Identifier found in `src/historical/client.rs`
- **field**: Identifier found in `src/historical/client.rs`
- **format**: Identifier found in `src/historical/client.rs`
- **four**: Identifier found in `src/historical/client.rs`
- **from**: Identifier found in `src/historical/client.rs`
- **from_slice**: Identifier found in `src/historical/client.rs`
- **from_str**: Identifier found in `src/historical/client.rs`
- **from_utf8**: Identifier found in `src/historical/client.rs`
- **function**: Identifier found in `src/historical/client.rs`
- **futures**: Identifier found in `src/historical/client.rs`

### G

- **gateway**: Identifier found in `src/historical/client.rs`
- **get_with_path**: Identifier found in `src/historical/client.rs`
- **given**: Identifier found in `src/historical/client.rs`

### H

- **HTTP**: Identifier found in `src/historical/client.rs`
- **handle_response**: Identifier found in `src/historical/client.rs`
- **handle_zstd_jsonl_response**: Identifier found in `src/historical/client.rs`
- **header**: Identifier found in `src/historical/client.rs`
- **headermap**: Identifier found in `src/historical/client.rs`
- **headers**: Identifier found in `src/historical/client.rs`
- **hidden**: Identifier found in `src/historical/client.rs`
- **historical**: Identifier found in `src/historical/client.rs`
- **historicalclient**: Identifier found in `src/historical/client.rs`
- **historicalgateway**: Identifier found in `src/historical/client.rs`
- **hours**: Identifier found in `src/historical/client.rs`
- **html**: Identifier found in `src/historical/client.rs`
- **http**: Identifier found in `src/historical/client.rs`

### I

- **impl**: Identifier found in `src/historical/client.rs`
- **incomplete**: Identifier found in `src/historical/client.rs`
- **individual**: Identifier found in `src/historical/client.rs`
- **initializes**: Identifier found in `src/historical/client.rs`
- **initializing**: Identifier found in `src/historical/client.rs`
- **inner**: Identifier found in `src/historical/client.rs`
- **insert**: Identifier found in `src/historical/client.rs`
- **instance**: Identifier found in `src/historical/client.rs`
- **instead**: Identifier found in `src/historical/client.rs`
- **intended**: Identifier found in `src/historical/client.rs`
- **internal**: Identifier found in `src/historical/client.rs`
- **into_url**: Identifier found in `src/historical/client.rs`
- **intourl**: Identifier found in `src/historical/client.rs`
- **invalid**: Identifier found in `src/historical/client.rs`
- **is_none**: Identifier found in `src/historical/client.rs`
- **is_success**: Identifier found in `src/historical/client.rs`

### J

- **join**: Identifier found in `src/historical/client.rs`
- **json**: Identifier found in `src/historical/client.rs`

### K

- **key**: Identifier found in `src/historical/client.rs`
- **key_from_env**: Identifier found in `src/historical/client.rs`

### L

- **library**: Identifier found in `src/historical/client.rs`
- **line**: Identifier found in `src/historical/client.rs`
- **lines**: Identifier found in `src/historical/client.rs`
- **lines_decoder**: Identifier found in `src/historical/client.rs`

### M

- **map**: Identifier found in `src/historical/client.rs`
- **map_err**: Identifier found in `src/historical/client.rs`
- **match**: Identifier found in `src/historical/client.rs`
- **matchers**: Identifier found in `src/historical/client.rs`
- **matches**: Identifier found in `src/historical/client.rs`
- **message**: Identifier found in `src/historical/client.rs`
- **metadata**: Identifier found in `src/historical/client.rs`
- **metadataclient**: Identifier found in `src/historical/client.rs`
- **method**: Identifier found in `src/historical/client.rs`
- **methods**: Identifier found in `src/historical/client.rs`
- **mock**: Identifier found in `src/historical/client.rs`
- **mock_server**: Identifier found in `src/historical/client.rs`
- **mockserver**: Identifier found in `src/historical/client.rs`
- **mod**: Identifier found in `src/historical/client.rs`
- **mount**: Identifier found in `src/historical/client.rs`
- **mut**: Identifier found in `src/historical/client.rs`

### N

- **next_line**: Identifier found in `src/historical/client.rs`
- **none**: Identifier found in `src/historical/client.rs`
- **normally**: Identifier found in `src/historical/client.rs`
- **note**: Identifier found in `src/historical/client.rs`

### O

- **older**: Identifier found in `src/historical/client.rs`
- **option**: Identifier found in `src/historical/client.rs`
- **other**: Identifier found in `src/historical/client.rs`
- **overrides**: Identifier found in `src/historical/client.rs`

### P

- **parameters**: Identifier found in `src/historical/client.rs`
- **parse**: Identifier found in `src/historical/client.rs`
- **path**: Identifier found in `src/historical/client.rs`
- **policy**: Identifier found in `src/historical/client.rs`
- **post**: Identifier found in `src/historical/client.rs`
- **pub**: Identifier found in `src/historical/client.rs`
- **push**: Identifier found in `src/historical/client.rs`

### R

- **REQUEST_ID_HEADER**: Identifier found in `src/historical/client.rs`
- **reading**: Identifier found in `src/historical/client.rs`
- **request**: Identifier found in `src/historical/client.rs`
- **request_id**: Identifier found in `src/historical/client.rs`
- **request_id_header**: Identifier found in `src/historical/client.rs`
- **requestbuilder**: Identifier found in `src/historical/client.rs`
- **requests**: Identifier found in `src/historical/client.rs`
- **required**: Identifier found in `src/historical/client.rs`
- **reqwest**: Identifier found in `src/historical/client.rs`
- **res**: Identifier found in `src/historical/client.rs`
- **resolutions**: Identifier found in `src/historical/client.rs`
- **resp**: Identifier found in `src/historical/client.rs`
- **respond_with**: Identifier found in `src/historical/client.rs`
- **response**: Identifier found in `src/historical/client.rs`
- **responsetemplate**: Identifier found in `src/historical/client.rs`
- **result**: Identifier found in `src/historical/client.rs`
- **returned**: Identifier found in `src/historical/client.rs`
- **returns**: Identifier found in `src/historical/client.rs`

### S

- **Some**: Identifier found in `src/historical/client.rs`
- **safe**: Identifier found in `src/historical/client.rs`
- **self**: Identifier found in `src/historical/client.rs`
- **serde**: Identifier found in `src/historical/client.rs`
- **serde_json**: Identifier found in `src/historical/client.rs`
- **server**: Identifier found in `src/historical/client.rs`
- **set**: Identifier found in `src/historical/client.rs`
- **set_body_string**: Identifier found in `src/historical/client.rs`
- **sets**: Identifier found in `src/historical/client.rs`
- **setting**: Identifier found in `src/historical/client.rs`
- **should**: Identifier found in `src/historical/client.rs`
- **simple**: Identifier found in `src/historical/client.rs`
- **since**: Identifier found in `src/historical/client.rs`
- **slug**: Identifier found in `src/historical/client.rs`
- **some**: Identifier found in `src/historical/client.rs`
- **specific**: Identifier found in `src/historical/client.rs`
- **start**: Identifier found in `src/historical/client.rs`
- **status**: Identifier found in `src/historical/client.rs`
- **status_code**: Identifier found in `src/historical/client.rs`
- **statuscode**: Identifier found in `src/historical/client.rs`
- **std**: Identifier found in `src/historical/client.rs`
- **str**: Identifier found in `src/historical/client.rs`
- **stream**: Identifier found in `src/historical/client.rs`
- **stream_reader**: Identifier found in `src/historical/client.rs`
- **streamreader**: Identifier found in `src/historical/client.rs`
- **string**: Identifier found in `src/historical/client.rs`
- **struct**: Identifier found in `src/historical/client.rs`
- **subclient**: Identifier found in `src/historical/client.rs`
- **subclients**: Identifier found in `src/historical/client.rs`
- **submitting**: Identifier found in `src/historical/client.rs`
- **super**: Identifier found in `src/historical/client.rs`
- **symbology**: Identifier found in `src/historical/client.rs`
- **symbologyclient**: Identifier found in `src/historical/client.rs`

### T

- **test**: Identifier found in `src/historical/client.rs`
- **tests**: Identifier found in `src/historical/client.rs`
- **text**: Identifier found in `src/historical/client.rs`
- **than**: Identifier found in `src/historical/client.rs`
- **this**: Identifier found in `src/historical/client.rs`
- **through**: Identifier found in `src/historical/client.rs`
- **timeseries**: Identifier found in `src/historical/client.rs`
- **timeseriesclient**: Identifier found in `src/historical/client.rs`
- **to_owned**: Identifier found in `src/historical/client.rs`
- **to_str**: Identifier found in `src/historical/client.rs`
- **to_string**: Identifier found in `src/historical/client.rs`
- **tokio**: Identifier found in `src/historical/client.rs`
- **tokio_util**: Identifier found in `src/historical/client.rs`
- **toowned**: Identifier found in `src/historical/client.rs`
- **tostring**: Identifier found in `src/historical/client.rs`
- **tracing**: Identifier found in `src/historical/client.rs`
- **trystreamext**: Identifier found in `src/historical/client.rs`
- **type**: Identifier found in `src/historical/client.rs`

### U

- **Unset**: Identifier found in `src/historical/client.rs`
- **unset**: Identifier found in `src/historical/client.rs`
- **untagged**: Identifier found in `src/historical/client.rs`
- **unwrap**: Identifier found in `src/historical/client.rs`
- **unwrap_err**: Identifier found in `src/historical/client.rs`
- **unwrap_or_default**: Identifier found in `src/historical/client.rs`
- **unwrap_or_else**: Identifier found in `src/historical/client.rs`
- **upgrade**: Identifier found in `src/historical/client.rs`
- **upgrade_policy**: Identifier found in `src/historical/client.rs`
- **uri**: Identifier found in `src/historical/client.rs`
- **url**: Identifier found in `src/historical/client.rs`
- **used**: Identifier found in `src/historical/client.rs`
- **user**: Identifier found in `src/historical/client.rs`
- **user_agent**: Identifier found in `src/historical/client.rs`
- **user_agent_ext**: Identifier found in `src/historical/client.rs`
- **user_agent_extension**: Identifier found in `src/historical/client.rs`

### V

- **variable**: Identifier found in `src/historical/client.rs`
- **vec**: Identifier found in `src/historical/client.rs`
- **version**: Identifier found in `src/historical/client.rs`
- **versionupgradepolicy**: Identifier found in `src/historical/client.rs`

### W

- **WARNING_HEADER**: Identifier found in `src/historical/client.rs`
- **warn**: Identifier found in `src/historical/client.rs`
- **warning**: Identifier found in `src/historical/client.rs`
- **warning_header**: Identifier found in `src/historical/client.rs`
- **warnings**: Identifier found in `src/historical/client.rs`
- **when**: Identifier found in `src/historical/client.rs`
- **while**: Identifier found in `src/historical/client.rs`
- **will**: Identifier found in `src/historical/client.rs`
- **wiremock**: Identifier found in `src/historical/client.rs`
- **with**: Identifier found in `src/historical/client.rs`
- **with_url**: Identifier found in `src/historical/client.rs`

### Z

- **zstddecoder**: Identifier found in `src/historical/client.rs`
