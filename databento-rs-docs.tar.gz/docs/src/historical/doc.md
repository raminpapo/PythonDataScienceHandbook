# Documentation: src/historical

## Folder Overview

**Path**: `src/historical`
**Files**: 5
**Subdirectories**: 0

## Purpose

This folder is located at `src/historical`.

## Contents Summary


### Files:
- `batch.rs` (33809 bytes)
- `client.rs` (12307 bytes)
- `metadata.rs` (24389 bytes)
- `symbology.rs` (9887 bytes)
- `timeseries.rs` (16070 bytes)
