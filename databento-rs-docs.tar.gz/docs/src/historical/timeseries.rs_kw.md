# Keywords: timeseries.rs

## Extracted Keywords

Total keywords extracted: 308


### A

- **aapl**: Identifier found in `src/historical/timeseries.rs`
- **accept**: Identifier found in `src/historical/timeseries.rs`
- **add_to_form**: Identifier found in `src/historical/timeseries.rs`
- **addtoform**: Identifier found in `src/historical/timeseries.rs`
- **allow**: Identifier found in `src/historical/timeseries.rs`
- **almost**: Identifier found in `src/historical/timeseries.rs`
- **also**: Identifier found in `src/historical/timeseries.rs`
- **api**: Identifier found in `src/historical/timeseries.rs`
- **api_key**: Identifier found in `src/historical/timeseries.rs`
- **api_version**: Identifier found in `src/historical/timeseries.rs`
- **application**: Identifier found in `src/historical/timeseries.rs`
- **applied**: Identifier found in `src/historical/timeseries.rs`
- **as_str**: Identifier found in `src/historical/timeseries.rs`
- **as_u16**: Identifier found in `src/historical/timeseries.rs`
- **asis**: Identifier found in `src/historical/timeseries.rs`
- **assert**: Identifier found in `src/historical/timeseries.rs`
- **assert_eq**: Identifier found in `src/historical/timeseries.rs`
- **async**: Identifier found in `src/historical/timeseries.rs`
- **async_compression**: Identifier found in `src/historical/timeseries.rs`
- **asyncbufreadext**: Identifier found in `src/historical/timeseries.rs`
- **asyncdbndecoder**: Identifier found in `src/historical/timeseries.rs`
- **asyncdbnencoder**: Identifier found in `src/historical/timeseries.rs`
- **asyncencoderecordref**: Identifier found in `src/historical/timeseries.rs`
- **asyncreadext**: Identifier found in `src/historical/timeseries.rs`
- **asyncwriteext**: Identifier found in `src/historical/timeseries.rs`
- **await**: Identifier found in `src/historical/timeseries.rs`

### B

- **base_url**: Identifier found in `src/historical/timeseries.rs`
- **basic_auth**: Identifier found in `src/historical/timeseries.rs`
- **batch**: Identifier found in `src/historical/timeseries.rs`
- **batchclient**: Identifier found in `src/historical/timeseries.rs`
- **because**: Identifier found in `src/historical/timeseries.rs`
- **body_contains**: Identifier found in `src/historical/timeseries.rs`
- **brn**: Identifier found in `src/historical/timeseries.rs`
- **bufread**: Identifier found in `src/historical/timeseries.rs`
- **bufreader**: Identifier found in `src/historical/timeseries.rs`
- **bufwriter**: Identifier found in `src/historical/timeseries.rs`
- **build**: Identifier found in `src/historical/timeseries.rs`
- **builder**: Identifier found in `src/historical/timeseries.rs`
- **bytes**: Identifier found in `src/historical/timeseries.rs`
- **bytes_stream**: Identifier found in `src/historical/timeseries.rs`

### C

- **calling**: Identifier found in `src/historical/timeseries.rs`
- **case**: Identifier found in `src/historical/timeseries.rs`
- **cfg**: Identifier found in `src/historical/timeseries.rs`
- **check_http_error**: Identifier found in `src/historical/timeseries.rs`
- **check_warnings**: Identifier found in `src/historical/timeseries.rs`
- **class**: Identifier found in `src/historical/timeseries.rs`
- **client**: Identifier found in `src/historical/timeseries.rs`
- **clippy**: Identifier found in `src/historical/timeseries.rs`
- **clone**: Identifier found in `src/historical/timeseries.rs`
- **code**: Identifier found in `src/historical/timeseries.rs`
- **communicate**: Identifier found in `src/historical/timeseries.rs`
- **compression**: Identifier found in `src/historical/timeseries.rs`
- **configuration**: Identifier found in `src/historical/timeseries.rs`
- **conjunction**: Identifier found in `src/historical/timeseries.rs`
- **consider**: Identifier found in `src/historical/timeseries.rs`
- **const**: Identifier found in `src/historical/timeseries.rs`
- **converts**: Identifier found in `src/historical/timeseries.rs`
- **cost**: Identifier found in `src/historical/timeseries.rs`
- **crate**: Identifier found in `src/historical/timeseries.rs`
- **create**: Identifier found in `src/historical/timeseries.rs`

### D

- **DATASET**: Identifier found in `src/historical/timeseries.rs`
- **Databento**: Identifier found in `src/historical/timeseries.rs`
- **data**: Identifier found in `src/historical/timeseries.rs`
- **databento**: Identifier found in `src/historical/timeseries.rs`
- **dataset**: Identifier found in `src/historical/timeseries.rs`
- **date_time_range**: Identifier found in `src/historical/timeseries.rs`
- **datetime**: Identifier found in `src/historical/timeseries.rs`
- **datetimerange**: Identifier found in `src/historical/timeseries.rs`
- **dbn**: Identifier found in `src/historical/timeseries.rs`
- **dbnmetadata**: Identifier found in `src/historical/timeseries.rs`
- **debug**: Identifier found in `src/historical/timeseries.rs`
- **decode**: Identifier found in `src/historical/timeseries.rs`
- **decode_record**: Identifier found in `src/historical/timeseries.rs`
- **decode_record_ref**: Identifier found in `src/historical/timeseries.rs`
- **decoder**: Identifier found in `src/historical/timeseries.rs`
- **decoding**: Identifier found in `src/historical/timeseries.rs`
- **default**: Identifier found in `src/historical/timeseries.rs`
- **defaults**: Identifier found in `src/historical/timeseries.rs`
- **deprecated**: Identifier found in `src/historical/timeseries.rs`
- **derive**: Identifier found in `src/historical/timeseries.rs`
- **div**: Identifier found in `src/historical/timeseries.rs`
- **during**: Identifier found in `src/historical/timeseries.rs`

### E

- **END**: Identifier found in `src/historical/timeseries.rs`
- **enable**: Identifier found in `src/historical/timeseries.rs`
- **encode**: Identifier found in `src/historical/timeseries.rs`
- **encode_record_ref**: Identifier found in `src/historical/timeseries.rs`
- **encoder**: Identifier found in `src/historical/timeseries.rs`
- **encoding**: Identifier found in `src/historical/timeseries.rs`
- **end**: Identifier found in `src/historical/timeseries.rs`
- **endpoints**: Identifier found in `src/historical/timeseries.rs`
- **enums**: Identifier found in `src/historical/timeseries.rs`
- **error**: Identifier found in `src/historical/timeseries.rs`
- **error_for_status**: Identifier found in `src/historical/timeseries.rs`
- **errors**: Identifier found in `src/historical/timeseries.rs`
- **every**: Identifier found in `src/historical/timeseries.rs`
- **exclusive**: Identifier found in `src/historical/timeseries.rs`
- **exists**: Identifier found in `src/historical/timeseries.rs`
- **exp_version**: Identifier found in `src/historical/timeseries.rs`
- **expect**: Identifier found in `src/historical/timeseries.rs`
- **explicitly**: Identifier found in `src/historical/timeseries.rs`
- **export**: Identifier found in `src/historical/timeseries.rs`

### F

- **fails**: Identifier found in `src/historical/timeseries.rs`
- **file**: Identifier found in `src/historical/timeseries.rs`
- **filter**: Identifier found in `src/historical/timeseries.rs`
- **filters**: Identifier found in `src/historical/timeseries.rs`
- **form**: Identifier found in `src/historical/timeseries.rs`
- **format**: Identifier found in `src/historical/timeseries.rs`
- **frames**: Identifier found in `src/historical/timeseries.rs`
- **from**: Identifier found in `src/historical/timeseries.rs`
- **function**: Identifier found in `src/historical/timeseries.rs`
- **fut**: Identifier found in `src/historical/timeseries.rs`
- **futures**: Identifier found in `src/historical/timeseries.rs`

### G

- **GetRangeParams**: Identifier found in `src/historical/timeseries.rs`
- **GetRangeToFileParams**: Identifier found in `src/historical/timeseries.rs`
- **get_mut**: Identifier found in `src/historical/timeseries.rs`
- **get_range**: Identifier found in `src/historical/timeseries.rs`
- **get_range_impl**: Identifier found in `src/historical/timeseries.rs`
- **get_range_to_file**: Identifier found in `src/historical/timeseries.rs`
- **getrangeparams**: Identifier found in `src/historical/timeseries.rs`
- **getrangetofileparams**: Identifier found in `src/historical/timeseries.rs`
- **given**: Identifier found in `src/historical/timeseries.rs`
- **group**: Identifier found in `src/historical/timeseries.rs`

### H

- **header**: Identifier found in `src/historical/timeseries.rs`
- **historical**: Identifier found in `src/historical/timeseries.rs`
- **historicalclient**: Identifier found in `src/historical/timeseries.rs`
- **http_decoder**: Identifier found in `src/historical/timeseries.rs`

### I

- **ifeuimpact**: Identifier found in `src/historical/timeseries.rs`
- **impl**: Identifier found in `src/historical/timeseries.rs`
- **inclusive**: Identifier found in `src/historical/timeseries.rs`
- **incur**: Identifier found in `src/historical/timeseries.rs`
- **indicates**: Identifier found in `src/historical/timeseries.rs`
- **initial**: Identifier found in `src/historical/timeseries.rs`
- **inner**: Identifier found in `src/historical/timeseries.rs`
- **input**: Identifier found in `src/historical/timeseries.rs`
- **instrument_id**: Identifier found in `src/historical/timeseries.rs`
- **instrumentid**: Identifier found in `src/historical/timeseries.rs`
- **into**: Identifier found in `src/historical/timeseries.rs`
- **is_none**: Identifier found in `src/historical/timeseries.rs`
- **issue**: Identifier found in `src/historical/timeseries.rs`
- **itch**: Identifier found in `src/historical/timeseries.rs`
- **item**: Identifier found in `src/historical/timeseries.rs`

### J

- **join**: Identifier found in `src/historical/timeseries.rs`
- **json**: Identifier found in `src/historical/timeseries.rs`

### K

- **key**: Identifier found in `src/historical/timeseries.rs`

### L

- **larger**: Identifier found in `src/historical/timeseries.rs`
- **latest**: Identifier found in `src/historical/timeseries.rs`
- **limit**: Identifier found in `src/historical/timeseries.rs`

### M

- **macros**: Identifier found in `src/historical/timeseries.rs`
- **makes**: Identifier found in `src/historical/timeseries.rs`
- **map_err**: Identifier found in `src/historical/timeseries.rs`
- **matchers**: Identifier found in `src/historical/timeseries.rs`
- **maximum**: Identifier found in `src/historical/timeseries.rs`
- **metadata**: Identifier found in `src/historical/timeseries.rs`
- **method**: Identifier found in `src/historical/timeseries.rs`
- **mock**: Identifier found in `src/historical/timeseries.rs`
- **mock_server**: Identifier found in `src/historical/timeseries.rs`
- **mockserver**: Identifier found in `src/historical/timeseries.rs`
- **mod**: Identifier found in `src/historical/timeseries.rs`
- **mount**: Identifier found in `src/historical/timeseries.rs`
- **multiple**: Identifier found in `src/historical/timeseries.rs`
- **multiple_members**: Identifier found in `src/historical/timeseries.rs`
- **mut**: Identifier found in `src/historical/timeseries.rs`

### N

- **nonzerou64**: Identifier found in `src/historical/timeseries.rs`
- **note**: Identifier found in `src/historical/timeseries.rs`
- **num**: Identifier found in `src/historical/timeseries.rs`
- **number**: Identifier found in `src/historical/timeseries.rs`

### O

- **octet**: Identifier found in `src/historical/timeseries.rs`
- **offsetdatetime**: Identifier found in `src/historical/timeseries.rs`
- **open**: Identifier found in `src/historical/timeseries.rs`
- **option**: Identifier found in `src/historical/timeseries.rs`
- **optional**: Identifier found in `src/historical/timeseries.rs`
- **other**: Identifier found in `src/historical/timeseries.rs`
- **otherwise**: Identifier found in `src/historical/timeseries.rs`
- **output**: Identifier found in `src/historical/timeseries.rs`

### P

- **parameters**: Identifier found in `src/historical/timeseries.rs`
- **params**: Identifier found in `src/historical/timeseries.rs`
- **parent**: Identifier found in `src/historical/timeseries.rs`
- **parse**: Identifier found in `src/historical/timeseries.rs`
- **partialeq**: Identifier found in `src/historical/timeseries.rs`
- **path**: Identifier found in `src/historical/timeseries.rs`
- **pathbuf**: Identifier found in `src/historical/timeseries.rs`
- **persist**: Identifier found in `src/historical/timeseries.rs`
- **persisted**: Identifier found in `src/historical/timeseries.rs`
- **policy**: Identifier found in `src/historical/timeseries.rs`
- **post**: Identifier found in `src/historical/timeseries.rs`
- **preset**: Identifier found in `src/historical/timeseries.rs`
- **prior**: Identifier found in `src/historical/timeseries.rs`
- **private**: Identifier found in `src/historical/timeseries.rs`
- **pub**: Identifier found in `src/historical/timeseries.rs`

### R

- **range**: Identifier found in `src/historical/timeseries.rs`
- **raw_symbol**: Identifier found in `src/historical/timeseries.rs`
- **rawsymbol**: Identifier found in `src/historical/timeseries.rs`
- **read**: Identifier found in `src/historical/timeseries.rs`
- **reader**: Identifier found in `src/historical/timeseries.rs`
- **rec_ref**: Identifier found in `src/historical/timeseries.rs`
- **record**: Identifier found in `src/historical/timeseries.rs`
- **records**: Identifier found in `src/historical/timeseries.rs`
- **request**: Identifier found in `src/historical/timeseries.rs`
- **requestbuilder**: Identifier found in `src/historical/timeseries.rs`
- **requests**: Identifier found in `src/historical/timeseries.rs`
- **reqwest**: Identifier found in `src/historical/timeseries.rs`
- **resp**: Identifier found in `src/historical/timeseries.rs`
- **respond_with**: Identifier found in `src/historical/timeseries.rs`
- **responsetemplate**: Identifier found in `src/historical/timeseries.rs`
- **result**: Identifier found in `src/historical/timeseries.rs`
- **return**: Identifier found in `src/historical/timeseries.rs`
- **returned**: Identifier found in `src/historical/timeseries.rs`
- **returns**: Identifier found in `src/historical/timeseries.rs`
- **rstest**: Identifier found in `src/historical/timeseries.rs`

### S

- **SCHEMA**: Identifier found in `src/historical/timeseries.rs`
- **START**: Identifier found in `src/historical/timeseries.rs`
- **Some**: Identifier found in `src/historical/timeseries.rs`
- **schema**: Identifier found in `src/historical/timeseries.rs`
- **self**: Identifier found in `src/historical/timeseries.rs`
- **send**: Identifier found in `src/historical/timeseries.rs`
- **set_body_bytes**: Identifier found in `src/historical/timeseries.rs`
- **setter**: Identifier found in `src/historical/timeseries.rs`
- **shutdown**: Identifier found in `src/historical/timeseries.rs`
- **since**: Identifier found in `src/historical/timeseries.rs`
- **slug**: Identifier found in `src/historical/timeseries.rs`
- **some**: Identifier found in `src/historical/timeseries.rs`
- **spot**: Identifier found in `src/historical/timeseries.rs`
- **start**: Identifier found in `src/historical/timeseries.rs`
- **statuscode**: Identifier found in `src/historical/timeseries.rs`
- **std**: Identifier found in `src/historical/timeseries.rs`
- **str**: Identifier found in `src/historical/timeseries.rs`
- **stream**: Identifier found in `src/historical/timeseries.rs`
- **streaming**: Identifier found in `src/historical/timeseries.rs`
- **streamreader**: Identifier found in `src/historical/timeseries.rs`
- **string**: Identifier found in `src/historical/timeseries.rs`
- **strip_option**: Identifier found in `src/historical/timeseries.rs`
- **struct**: Identifier found in `src/historical/timeseries.rs`
- **stype**: Identifier found in `src/historical/timeseries.rs`
- **stype_in**: Identifier found in `src/historical/timeseries.rs`
- **stype_out**: Identifier found in `src/historical/timeseries.rs`
- **submit_job**: Identifier found in `src/historical/timeseries.rs`
- **super**: Identifier found in `src/historical/timeseries.rs`
- **symbology**: Identifier found in `src/historical/timeseries.rs`
- **symbols**: Identifier found in `src/historical/timeseries.rs`

### T

- **TimeseriesClient**: Identifier found in `src/historical/timeseries.rs`
- **target**: Identifier found in `src/historical/timeseries.rs`
- **temp_dir**: Identifier found in `src/historical/timeseries.rs`
- **tempdir**: Identifier found in `src/historical/timeseries.rs`
- **tempfile**: Identifier found in `src/historical/timeseries.rs`
- **test**: Identifier found in `src/historical/timeseries.rs`
- **test_get_range**: Identifier found in `src/historical/timeseries.rs`
- **test_get_range_to_file**: Identifier found in `src/historical/timeseries.rs`
- **test_infra**: Identifier found in `src/historical/timeseries.rs`
- **tests**: Identifier found in `src/historical/timeseries.rs`
- **that**: Identifier found in `src/historical/timeseries.rs`
- **there**: Identifier found in `src/historical/timeseries.rs`
- **these**: Identifier found in `src/historical/timeseries.rs`
- **this**: Identifier found in `src/historical/timeseries.rs`
- **time**: Identifier found in `src/historical/timeseries.rs`
- **timeseries**: Identifier found in `src/historical/timeseries.rs`
- **timeseriesclient**: Identifier found in `src/historical/timeseries.rs`
- **to_api_string**: Identifier found in `src/historical/timeseries.rs`
- **to_owned**: Identifier found in `src/historical/timeseries.rs`
- **to_string**: Identifier found in `src/historical/timeseries.rs`
- **tokio**: Identifier found in `src/historical/timeseries.rs`
- **tokio_util**: Identifier found in `src/historical/timeseries.rs`
- **too_many_arguments**: Identifier found in `src/historical/timeseries.rs`
- **tostring**: Identifier found in `src/historical/timeseries.rs`
- **trademsg**: Identifier found in `src/historical/timeseries.rs`
- **trades**: Identifier found in `src/historical/timeseries.rs`
- **transform**: Identifier found in `src/historical/timeseries.rs`
- **true**: Identifier found in `src/historical/timeseries.rs`
- **trystreamext**: Identifier found in `src/historical/timeseries.rs`
- **ts_event**: Identifier found in `src/historical/timeseries.rs`
- **ts_recv**: Identifier found in `src/historical/timeseries.rs`
- **type**: Identifier found in `src/historical/timeseries.rs`
- **typed_builder**: Identifier found in `src/historical/timeseries.rs`
- **typedbuilder**: Identifier found in `src/historical/timeseries.rs`

### U

- **unix_timestamp_nanos**: Identifier found in `src/historical/timeseries.rs`
- **unlike**: Identifier found in `src/historical/timeseries.rs`
- **unpin**: Identifier found in `src/historical/timeseries.rs`
- **unwrap**: Identifier found in `src/historical/timeseries.rs`
- **unwrap_or**: Identifier found in `src/historical/timeseries.rs`
- **upgrade**: Identifier found in `src/historical/timeseries.rs`
- **upgrade_policy**: Identifier found in `src/historical/timeseries.rs`
- **upgradetov2**: Identifier found in `src/historical/timeseries.rs`
- **upgradetov3**: Identifier found in `src/historical/timeseries.rs`
- **uri**: Identifier found in `src/historical/timeseries.rs`
- **used**: Identifier found in `src/historical/timeseries.rs`
- **using**: Identifier found in `src/historical/timeseries.rs`
- **utc**: Identifier found in `src/historical/timeseries.rs`

### V

- **value**: Identifier found in `src/historical/timeseries.rs`
- **vec**: Identifier found in `src/historical/timeseries.rs`
- **version**: Identifier found in `src/historical/timeseries.rs`
- **versions**: Identifier found in `src/historical/timeseries.rs`
- **versionupgradepolicy**: Identifier found in `src/historical/timeseries.rs`

### W

- **warning**: Identifier found in `src/historical/timeseries.rs`
- **when**: Identifier found in `src/historical/timeseries.rs`
- **where**: Identifier found in `src/historical/timeseries.rs`
- **while**: Identifier found in `src/historical/timeseries.rs`
- **will**: Identifier found in `src/historical/timeseries.rs`
- **wiremock**: Identifier found in `src/historical/timeseries.rs`
- **with**: Identifier found in `src/historical/timeseries.rs`
- **with_path**: Identifier found in `src/historical/timeseries.rs`
- **with_upgrade_policy**: Identifier found in `src/historical/timeseries.rs`
- **with_zstd**: Identifier found in `src/historical/timeseries.rs`

### X

- **xnas**: Identifier found in `src/historical/timeseries.rs`
- **xnasitch**: Identifier found in `src/historical/timeseries.rs`

### Z

- **zst**: Identifier found in `src/historical/timeseries.rs`
- **zst_test_data_path**: Identifier found in `src/historical/timeseries.rs`
- **zstd**: Identifier found in `src/historical/timeseries.rs`
- **zstd_decoder**: Identifier found in `src/historical/timeseries.rs`
- **zstddecoder**: Identifier found in `src/historical/timeseries.rs`
