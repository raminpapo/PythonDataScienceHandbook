# Keywords: error.rs

## Extracted Keywords

Total keywords extracted: 101


### A

- **ApiError**: Identifier found in `src/error.rs`
- **alias**: Identifier found in `src/error.rs`
- **another**: Identifier found in `src/error.rs`
- **api**: Identifier found in `src/error.rs`
- **apierror**: Identifier found in `src/error.rs`
- **argument**: Identifier found in `src/error.rs`
- **auth**: Identifier found in `src/error.rs`
- **authentication**: Identifier found in `src/error.rs`

### B

- **bad**: Identifier found in `src/error.rs`
- **bad_arg**: Identifier found in `src/error.rs`
- **badargument**: Identifier found in `src/error.rs`

### C

- **cfg**: Identifier found in `src/error.rs`
- **client**: Identifier found in `src/error.rs`
- **clients**: Identifier found in `src/error.rs`
- **code**: Identifier found in `src/error.rs`
- **convert**: Identifier found in `src/error.rs`
- **crate**: Identifier found in `src/error.rs`

### D

- **databento**: Identifier found in `src/error.rs`
- **dbn**: Identifier found in `src/error.rs`
- **dbn_err**: Identifier found in `src/error.rs`
- **debug**: Identifier found in `src/error.rs`
- **decoding**: Identifier found in `src/error.rs`
- **derive**: Identifier found in `src/error.rs`
- **desc**: Identifier found in `src/error.rs`
- **description**: Identifier found in `src/error.rs`
- **display**: Identifier found in `src/error.rs`
- **doc**: Identifier found in `src/error.rs`
- **docs_url**: Identifier found in `src/error.rs`
- **documentation**: Identifier found in `src/error.rs`

### E

- **Error**: Identifier found in `src/error.rs`
- **else**: Identifier found in `src/error.rs`
- **encoding**: Identifier found in `src/error.rs`
- **enum**: Identifier found in `src/error.rs`
- **error**: Identifier found in `src/error.rs`
- **errors**: Identifier found in `src/error.rs`

### F

- **failed**: Identifier found in `src/error.rs`
- **feature**: Identifier found in `src/error.rs`
- **fmt**: Identifier found in `src/error.rs`
- **format**: Identifier found in `src/error.rs`
- **formatter**: Identifier found in `src/error.rs`
- **from**: Identifier found in `src/error.rs`
- **function**: Identifier found in `src/error.rs`

### H

- **historical**: Identifier found in `src/error.rs`
- **http**: Identifier found in `src/error.rs`

### I

- **impl**: Identifier found in `src/error.rs`
- **internal**: Identifier found in `src/error.rs`
- **invalid**: Identifier found in `src/error.rs`

### J

- **json**: Identifier found in `src/error.rs`

### L

- **link**: Identifier found in `src/error.rs`

### M

- **match**: Identifier found in `src/error.rs`
- **message**: Identifier found in `src/error.rs`
- **msg**: Identifier found in `src/error.rs`
- **mut**: Identifier found in `src/error.rs`

### N

- **name**: Identifier found in `src/error.rs`
- **non_exhaustive**: Identifier found in `src/error.rs`

### O

- **occur**: Identifier found in `src/error.rs`
- **occurring**: Identifier found in `src/error.rs`
- **option**: Identifier found in `src/error.rs`
- **own**: Identifier found in `src/error.rs`

### P

- **param_name**: Identifier found in `src/error.rs`
- **parameter**: Identifier found in `src/error.rs`
- **passed**: Identifier found in `src/error.rs`
- **pub**: Identifier found in `src/error.rs`

### R

- **reading**: Identifier found in `src/error.rs`
- **received**: Identifier found in `src/error.rs`
- **ref**: Identifier found in `src/error.rs`
- **related**: Identifier found in `src/error.rs`
- **request**: Identifier found in `src/error.rs`
- **request_id**: Identifier found in `src/error.rs`
- **reqwest**: Identifier found in `src/error.rs`
- **response**: Identifier found in `src/error.rs`
- **result**: Identifier found in `src/error.rs`

### S

- **Some**: Identifier found in `src/error.rs`
- **self**: Identifier found in `src/error.rs`
- **serde_json**: Identifier found in `src/error.rs`
- **some**: Identifier found in `src/error.rs`
- **source**: Identifier found in `src/error.rs`
- **status**: Identifier found in `src/error.rs`
- **status_code**: Identifier found in `src/error.rs`
- **statuscode**: Identifier found in `src/error.rs`
- **std**: Identifier found in `src/error.rs`
- **str**: Identifier found in `src/error.rs`
- **string**: Identifier found in `src/error.rs`
- **struct**: Identifier found in `src/error.rs`

### T

- **that**: Identifier found in `src/error.rs`
- **thiserror**: Identifier found in `src/error.rs`
- **to_string**: Identifier found in `src/error.rs`
- **tostring**: Identifier found in `src/error.rs`
- **type**: Identifier found in `src/error.rs`
- **types**: Identifier found in `src/error.rs`

### U

- **utf**: Identifier found in `src/error.rs`
- **utf8**: Identifier found in `src/error.rs`
- **utf8error**: Identifier found in `src/error.rs`

### W

- **when**: Identifier found in `src/error.rs`
- **which**: Identifier found in `src/error.rs`
- **while**: Identifier found in `src/error.rs`
- **why**: Identifier found in `src/error.rs`
- **with**: Identifier found in `src/error.rs`
- **working**: Identifier found in `src/error.rs`
- **write**: Identifier found in `src/error.rs`
- **writing**: Identifier found in `src/error.rs`
