# Keywords: client.rs

## Extracted Keywords

Total keywords extracted: 482


### A

- **accept**: Identifier found in `src/live/client.rs`
- **action**: Identifier found in `src/live/client.rs`
- **add**: Identifier found in `src/live/client.rs`
- **addr**: Identifier found in `src/live/client.rs`
- **advanced**: Identifier found in `src/live/client.rs`
- **after**: Identifier found in `src/live/client.rs`
- **already**: Identifier found in `src/live/client.rs`
- **also**: Identifier found in `src/live/client.rs`
- **another**: Identifier found in `src/live/client.rs`
- **any**: Identifier found in `src/live/client.rs`
- **api**: Identifier found in `src/live/client.rs`
- **apikey**: Identifier found in `src/live/client.rs`
- **as_bytes**: Identifier found in `src/live/client.rs`
- **as_deref**: Identifier found in `src/live/client.rs`
- **as_mut**: Identifier found in `src/live/client.rs`
- **as_ref**: Identifier found in `src/live/client.rs`
- **as_slice**: Identifier found in `src/live/client.rs`
- **as_str**: Identifier found in `src/live/client.rs`
- **asref**: Identifier found in `src/live/client.rs`
- **assert**: Identifier found in `src/live/client.rs`
- **assert_eq**: Identifier found in `src/live/client.rs`
- **associated**: Identifier found in `src/live/client.rs`
- **async**: Identifier found in `src/live/client.rs`
- **async_decode_metadata_with_fsm**: Identifier found in `src/live/client.rs`
- **async_decode_record_ref_with_fsm**: Identifier found in `src/live/client.rs`
- **asyncbufreadext**: Identifier found in `src/live/client.rs`
- **asyncdbnmetadataencoder**: Identifier found in `src/live/client.rs`
- **asyncwriteext**: Identifier found in `src/live/client.rs`
- **attempts**: Identifier found in `src/live/client.rs`
- **auth**: Identifier found in `src/live/client.rs`
- **auth_end**: Identifier found in `src/live/client.rs`
- **auth_line**: Identifier found in `src/live/client.rs`
- **auth_start**: Identifier found in `src/live/client.rs`
- **authenticate**: Identifier found in `src/live/client.rs`
- **authenticates**: Identifier found in `src/live/client.rs`
- **authentication**: Identifier found in `src/live/client.rs`
- **await**: Identifier found in `src/live/client.rs`

### B

- **badargument**: Identifier found in `src/live/client.rs`
- **been**: Identifier found in `src/live/client.rs`
- **before**: Identifier found in `src/live/client.rs`
- **bind**: Identifier found in `src/live/client.rs`
- **bool**: Identifier found in `src/live/client.rs`
- **box**: Identifier found in `src/live/client.rs`
- **branch**: Identifier found in `src/live/client.rs`
- **break**: Identifier found in `src/live/client.rs`
- **bucket**: Identifier found in `src/live/client.rs`
- **buf_size**: Identifier found in `src/live/client.rs`
- **buffer_size**: Identifier found in `src/live/client.rs`
- **bufreader**: Identifier found in `src/live/client.rs`
- **bugs**: Identifier found in `src/live/client.rs`
- **build**: Identifier found in `src/live/client.rs`
- **builder**: Identifier found in `src/live/client.rs`
- **bytes**: Identifier found in `src/live/client.rs`

### C

- **Client**: Identifier found in `src/live/client.rs`
- **c_char**: Identifier found in `src/live/client.rs`
- **call**: Identifier found in `src/live/client.rs`
- **called**: Identifier found in `src/live/client.rs`
- **cancel**: Identifier found in `src/live/client.rs`
- **cancellation**: Identifier found in `src/live/client.rs`
- **cannot**: Identifier found in `src/live/client.rs`
- **cases**: Identifier found in `src/live/client.rs`
- **cfg**: Identifier found in `src/live/client.rs`
- **character**: Identifier found in `src/live/client.rs`
- **characters**: Identifier found in `src/live/client.rs`
- **chars**: Identifier found in `src/live/client.rs`
- **chunk_size**: Identifier found in `src/live/client.rs`
- **client**: Identifier found in `src/live/client.rs`
- **client_task**: Identifier found in `src/live/client.rs`
- **clientbuilder**: Identifier found in `src/live/client.rs`
- **clone**: Identifier found in `src/live/client.rs`
- **close**: Identifier found in `src/live/client.rs`
- **closed**: Identifier found in `src/live/client.rs`
- **closes**: Identifier found in `src/live/client.rs`
- **closing**: Identifier found in `src/live/client.rs`
- **communicate**: Identifier found in `src/live/client.rs`
- **completes**: Identifier found in `src/live/client.rs`
- **composed**: Identifier found in `src/live/client.rs`
- **configured**: Identifier found in `src/live/client.rs`
- **connect**: Identifier found in `src/live/client.rs`
- **connect_with_addr**: Identifier found in `src/live/client.rs`
- **connected**: Identifier found in `src/live/client.rs`
- **connection**: Identifier found in `src/live/client.rs`
- **const**: Identifier found in `src/live/client.rs`
- **contains**: Identifier found in `src/live/client.rs`
- **corrupting**: Identifier found in `src/live/client.rs`
- **cram**: Identifier found in `src/live/client.rs`
- **crate**: Identifier found in `src/live/client.rs`
- **creates**: Identifier found in `src/live/client.rs`
- **current**: Identifier found in `src/live/client.rs`

### D

- **DATASET**: Identifier found in `src/live/client.rs`
- **data**: Identifier found in `src/live/client.rs`
- **dataset**: Identifier found in `src/live/client.rs`
- **dbg**: Identifier found in `src/live/client.rs`
- **dbn**: Identifier found in `src/live/client.rs`
- **dbn_version**: Identifier found in `src/live/client.rs`
- **dbnfsm**: Identifier found in `src/live/client.rs`
- **debug**: Identifier found in `src/live/client.rs`
- **debug_struct**: Identifier found in `src/live/client.rs`
- **decode**: Identifier found in `src/live/client.rs`
- **decoding**: Identifier found in `src/live/client.rs`
- **default**: Identifier found in `src/live/client.rs`
- **default_buf_size**: Identifier found in `src/live/client.rs`
- **deprecated**: Identifier found in `src/live/client.rs`
- **depth**: Identifier found in `src/live/client.rs`
- **desc**: Identifier found in `src/live/client.rs`
- **determine_gateway**: Identifier found in `src/live/client.rs`
- **disconnect**: Identifier found in `src/live/client.rs`
- **does**: Identifier found in `src/live/client.rs`
- **don**: Identifier found in `src/live/client.rs`
- **duration**: Identifier found in `src/live/client.rs`
- **dyn**: Identifier found in `src/live/client.rs`

### E

- **Err**: Identifier found in `src/live/client.rs`
- **Event**: Identifier found in `src/live/client.rs`
- **each**: Identifier found in `src/live/client.rs`
- **else**: Identifier found in `src/live/client.rs`
- **encode**: Identifier found in `src/live/client.rs`
- **encoder**: Identifier found in `src/live/client.rs`
- **encoding**: Identifier found in `src/live/client.rs`
- **ending**: Identifier found in `src/live/client.rs`
- **enum**: Identifier found in `src/live/client.rs`
- **enums**: Identifier found in `src/live/client.rs`
- **equsmini**: Identifier found in `src/live/client.rs`
- **err**: Identifier found in `src/live/client.rs`
- **error**: Identifier found in `src/live/client.rs`
- **errors**: Identifier found in `src/live/client.rs`
- **event**: Identifier found in `src/live/client.rs`
- **except**: Identifier found in `src/live/client.rs`
- **exhausted**: Identifier found in `src/live/client.rs`
- **exit**: Identifier found in `src/live/client.rs`
- **expect_subscribe**: Identifier found in `src/live/client.rs`
- **expected**: Identifier found in `src/live/client.rs`

### F

- **Fixture**: Identifier found in `src/live/client.rs`
- **failed**: Identifier found in `src/live/client.rs`
- **fails**: Identifier found in `src/live/client.rs`
- **failure**: Identifier found in `src/live/client.rs`
- **false**: Identifier found in `src/live/client.rs`
- **fetches**: Identifier found in `src/live/client.rs`
- **ffi**: Identifier found in `src/live/client.rs`
- **field**: Identifier found in `src/live/client.rs`
- **file**: Identifier found in `src/live/client.rs`
- **filler**: Identifier found in `src/live/client.rs`
- **find**: Identifier found in `src/live/client.rs`
- **finish_non_exhaustive**: Identifier found in `src/live/client.rs`
- **first**: Identifier found in `src/live/client.rs`
- **fixture**: Identifier found in `src/live/client.rs`
- **fixture_task**: Identifier found in `src/live/client.rs`
- **flags**: Identifier found in `src/live/client.rs`
- **flagset**: Identifier found in `src/live/client.rs`
- **flush**: Identifier found in `src/live/client.rs`
- **fmt**: Identifier found in `src/live/client.rs`
- **fmtsubscriber**: Identifier found in `src/live/client.rs`
- **format**: Identifier found in `src/live/client.rs`
- **formatter**: Identifier found in `src/live/client.rs`
- **from**: Identifier found in `src/live/client.rs`
- **from_millis**: Identifier found in `src/live/client.rs`
- **fsm**: Identifier found in `src/live/client.rs`
- **function**: Identifier found in `src/live/client.rs`

### G

- **gateway**: Identifier found in `src/live/client.rs`
- **generally**: Identifier found in `src/live/client.rs`
- **given**: Identifier found in `src/live/client.rs`
- **glbxmdp3**: Identifier found in `src/live/client.rs`

### H

- **half**: Identifier found in `src/live/client.rs`
- **has_decoded_metadata**: Identifier found in `src/live/client.rs`
- **hasn**: Identifier found in `src/live/client.rs`
- **hasrtype**: Identifier found in `src/live/client.rs`
- **have**: Identifier found in `src/live/client.rs`
- **hb_int**: Identifier found in `src/live/client.rs`
- **header**: Identifier found in `src/live/client.rs`
- **heartbeat**: Identifier found in `src/live/client.rs`
- **heartbeat_interval**: Identifier found in `src/live/client.rs`
- **heartbeat_interval_s**: Identifier found in `src/live/client.rs`
- **hex**: Identifier found in `src/live/client.rs`
- **high**: Identifier found in `src/live/client.rs`
- **historical**: Identifier found in `src/live/client.rs`

### I

- **identifier**: Identifier found in `src/live/client.rs`
- **ids**: Identifier found in `src/live/client.rs`
- **ignored**: Identifier found in `src/live/client.rs`
- **iller**: Identifier found in `src/live/client.rs`
- **immutable**: Identifier found in `src/live/client.rs`
- **impl**: Identifier found in `src/live/client.rs`
- **indicate**: Identifier found in `src/live/client.rs`
- **infallible**: Identifier found in `src/live/client.rs`
- **info**: Identifier found in `src/live/client.rs`
- **info_span**: Identifier found in `src/live/client.rs`
- **initializing**: Identifier found in `src/live/client.rs`
- **input**: Identifier found in `src/live/client.rs`
- **instance**: Identifier found in `src/live/client.rs`
- **instead**: Identifier found in `src/live/client.rs`
- **instructs**: Identifier found in `src/live/client.rs`
- **instrument**: Identifier found in `src/live/client.rs`
- **instrumentid**: Identifier found in `src/live/client.rs`
- **int_1**: Identifier found in `src/live/client.rs`
- **int_2**: Identifier found in `src/live/client.rs`
- **int_3**: Identifier found in `src/live/client.rs`
- **int_4**: Identifier found in `src/live/client.rs`
- **int_5**: Identifier found in `src/live/client.rs`
- **int_6**: Identifier found in `src/live/client.rs`
- **intermediate**: Identifier found in `src/live/client.rs`
- **interval**: Identifier found in `src/live/client.rs`
- **into_inner**: Identifier found in `src/live/client.rs`
- **intraday**: Identifier found in `src/live/client.rs`
- **invalid**: Identifier found in `src/live/client.rs`
- **is_ascii_hexdigit**: Identifier found in `src/live/client.rs`
- **is_last**: Identifier found in `src/live/client.rs`
- **is_none**: Identifier found in `src/live/client.rs`
- **iter_mut**: Identifier found in `src/live/client.rs`

### J

- **join**: Identifier found in `src/live/client.rs`
- **joinhandle**: Identifier found in `src/live/client.rs`

### K

- **key**: Identifier found in `src/live/client.rs`

### L

- **later**: Identifier found in `src/live/client.rs`
- **len**: Identifier found in `src/live/client.rs`
- **level**: Identifier found in `src/live/client.rs`
- **level_filters**: Identifier found in `src/live/client.rs`
- **levelfilter**: Identifier found in `src/live/client.rs`
- **listener**: Identifier found in `src/live/client.rs`
- **live**: Identifier found in `src/live/client.rs`
- **liveclient**: Identifier found in `src/live/client.rs`
- **local_addr**: Identifier found in `src/live/client.rs`
- **longer**: Identifier found in `src/live/client.rs`
- **loop**: Identifier found in `src/live/client.rs`
- **lots**: Identifier found in `src/live/client.rs`
- **low**: Identifier found in `src/live/client.rs`
- **lsg**: Identifier found in `src/live/client.rs`

### M

- **MockGateway**: Identifier found in `src/live/client.rs`
- **made**: Identifier found in `src/live/client.rs`
- **map**: Identifier found in `src/live/client.rs`
- **market**: Identifier found in `src/live/client.rs`
- **match**: Identifier found in `src/live/client.rs`
- **matches**: Identifier found in `src/live/client.rs`
- **max**: Identifier found in `src/live/client.rs`
- **may**: Identifier found in `src/live/client.rs`
- **mbp10msg**: Identifier found in `src/live/client.rs`
- **mbp_0**: Identifier found in `src/live/client.rs`
- **means**: Identifier found in `src/live/client.rs`
- **message**: Identifier found in `src/live/client.rs`
- **metadata**: Identifier found in `src/live/client.rs`
- **metadatabuilder**: Identifier found in `src/live/client.rs`
- **method**: Identifier found in `src/live/client.rs`
- **min**: Identifier found in `src/live/client.rs`
- **minute**: Identifier found in `src/live/client.rs`
- **minutes**: Identifier found in `src/live/client.rs`
- **mock**: Identifier found in `src/live/client.rs`
- **mockgateway**: Identifier found in `src/live/client.rs`
- **mod**: Identifier found in `src/live/client.rs`
- **more**: Identifier found in `src/live/client.rs`
- **move**: Identifier found in `src/live/client.rs`
- **mpsc**: Identifier found in `src/live/client.rs`
- **msft**: Identifier found in `src/live/client.rs`
- **msg**: Identifier found in `src/live/client.rs`
- **mut**: Identifier found in `src/live/client.rs`
- **mutable**: Identifier found in `src/live/client.rs`

### N

- **necessarily**: Identifier found in `src/live/client.rs`
- **net**: Identifier found in `src/live/client.rs`
- **next**: Identifier found in `src/live/client.rs`
- **next_record**: Identifier found in `src/live/client.rs`
- **none**: Identifier found in `src/live/client.rs`
- **note**: Identifier found in `src/live/client.rs`
- **now_utc**: Identifier found in `src/live/client.rs`

### O

- **offsetdatetime**: Identifier found in `src/live/client.rs`
- **ohlcv1m**: Identifier found in `src/live/client.rs`
- **ohlcv_1m**: Identifier found in `src/live/client.rs`
- **ohlcvmsg**: Identifier found in `src/live/client.rs`
- **once**: Identifier found in `src/live/client.rs`
- **only**: Identifier found in `src/live/client.rs`
- **open**: Identifier found in `src/live/client.rs`
- **oprapillar**: Identifier found in `src/live/client.rs`
- **option**: Identifier found in `src/live/client.rs`
- **original**: Identifier found in `src/live/client.rs`
- **otherwise**: Identifier found in `src/live/client.rs`
- **override**: Identifier found in `src/live/client.rs`

### P

- **param_name**: Identifier found in `src/live/client.rs`
- **parameters**: Identifier found in `src/live/client.rs`
- **parent**: Identifier found in `src/live/client.rs`
- **partial**: Identifier found in `src/live/client.rs`
- **partially**: Identifier found in `src/live/client.rs`
- **peer_addr**: Identifier found in `src/live/client.rs`
- **performed**: Identifier found in `src/live/client.rs`
- **policy**: Identifier found in `src/live/client.rs`
- **port**: Identifier found in `src/live/client.rs`
- **potential**: Identifier found in `src/live/client.rs`
- **previous**: Identifier found in `src/live/client.rs`
- **price**: Identifier found in `src/live/client.rs`
- **primarily**: Identifier found in `src/live/client.rs`
- **proceeding**: Identifier found in `src/live/client.rs`
- **protocol**: Identifier found in `src/live/client.rs`
- **pub**: Identifier found in `src/live/client.rs`
- **publishers**: Identifier found in `src/live/client.rs`
- **push**: Identifier found in `src/live/client.rs`

### Q

- **qqq**: Identifier found in `src/live/client.rs`

### R

- **REC**: Identifier found in `src/live/client.rs`
- **rawsymbol**: Identifier found in `src/live/client.rs`
- **read**: Identifier found in `src/live/client.rs`
- **read_line**: Identifier found in `src/live/client.rs`
- **reader**: Identifier found in `src/live/client.rs`
- **readhalf**: Identifier found in `src/live/client.rs`
- **real**: Identifier found in `src/live/client.rs`
- **reattempted**: Identifier found in `src/live/client.rs`
- **rec**: Identifier found in `src/live/client.rs`
- **receive**: Identifier found in `src/live/client.rs`
- **receives**: Identifier found in `src/live/client.rs`
- **reconnect**: Identifier found in `src/live/client.rs`
- **reconnecting**: Identifier found in `src/live/client.rs`
- **record**: Identifier found in `src/live/client.rs`
- **recordheader**: Identifier found in `src/live/client.rs`
- **recordref**: Identifier found in `src/live/client.rs`
- **records**: Identifier found in `src/live/client.rs`
- **recv**: Identifier found in `src/live/client.rs`
- **recver**: Identifier found in `src/live/client.rs`
- **reference**: Identifier found in `src/live/client.rs`
- **rejecting**: Identifier found in `src/live/client.rs`
- **removing**: Identifier found in `src/live/client.rs`
- **reopens**: Identifier found in `src/live/client.rs`
- **replay**: Identifier found in `src/live/client.rs`
- **request**: Identifier found in `src/live/client.rs`
- **required**: Identifier found in `src/live/client.rs`
- **res**: Identifier found in `src/live/client.rs`
- **reset**: Identifier found in `src/live/client.rs`
- **resub**: Identifier found in `src/live/client.rs`
- **resubscribe**: Identifier found in `src/live/client.rs`
- **resubscribes**: Identifier found in `src/live/client.rs`
- **result**: Identifier found in `src/live/client.rs`
- **resulting**: Identifier found in `src/live/client.rs`
- **return**: Identifier found in `src/live/client.rs`
- **returns**: Identifier found in `src/live/client.rs`
- **rtype**: Identifier found in `src/live/client.rs`

### S

- **SYMBOL**: Identifier found in `src/live/client.rs`
- **SYMBOL_COUNT**: Identifier found in `src/live/client.rs`
- **Some**: Identifier found in `src/live/client.rs`
- **safe**: Identifier found in `src/live/client.rs`
- **safety**: Identifier found in `src/live/client.rs`
- **saving**: Identifier found in `src/live/client.rs`
- **schema**: Identifier found in `src/live/client.rs`
- **seconds**: Identifier found in `src/live/client.rs`
- **select**: Identifier found in `src/live/client.rs`
- **self**: Identifier found in `src/live/client.rs`
- **send**: Identifier found in `src/live/client.rs`
- **send_record**: Identifier found in `src/live/client.rs`
- **send_ts_out**: Identifier found in `src/live/client.rs`
- **sender**: Identifier found in `src/live/client.rs`
- **sending**: Identifier found in `src/live/client.rs`
- **sendrecord**: Identifier found in `src/live/client.rs`
- **sent**: Identifier found in `src/live/client.rs`
- **sequence**: Identifier found in `src/live/client.rs`
- **session**: Identifier found in `src/live/client.rs`
- **session_id**: Identifier found in `src/live/client.rs`
- **set_nodelay**: Identifier found in `src/live/client.rs`
- **setting**: Identifier found in `src/live/client.rs`
- **setup**: Identifier found in `src/live/client.rs`
- **should**: Identifier found in `src/live/client.rs`
- **shutdown**: Identifier found in `src/live/client.rs`
- **side**: Identifier found in `src/live/client.rs`
- **since**: Identifier found in `src/live/client.rs`
- **size**: Identifier found in `src/live/client.rs`
- **skip_all**: Identifier found in `src/live/client.rs`
- **snapshot**: Identifier found in `src/live/client.rs`
- **socketaddr**: Identifier found in `src/live/client.rs`
- **some**: Identifier found in `src/live/client.rs`
- **span**: Identifier found in `src/live/client.rs`
- **spawn**: Identifier found in `src/live/client.rs`
- **split**: Identifier found in `src/live/client.rs`
- **split_once**: Identifier found in `src/live/client.rs`
- **spy**: Identifier found in `src/live/client.rs`
- **start**: Identifier found in `src/live/client.rs`
- **start_line**: Identifier found in `src/live/client.rs`
- **start_session**: Identifier found in `src/live/client.rs`
- **started**: Identifier found in `src/live/client.rs`
- **starting**: Identifier found in `src/live/client.rs`
- **state**: Identifier found in `src/live/client.rs`
- **statement**: Identifier found in `src/live/client.rs`
- **static**: Identifier found in `src/live/client.rs`
- **std**: Identifier found in `src/live/client.rs`
- **stop**: Identifier found in `src/live/client.rs`
- **str**: Identifier found in `src/live/client.rs`
- **stream**: Identifier found in `src/live/client.rs`
- **string**: Identifier found in `src/live/client.rs`
- **struct**: Identifier found in `src/live/client.rs`
- **stype**: Identifier found in `src/live/client.rs`
- **stype_in**: Identifier found in `src/live/client.rs`
- **stype_out**: Identifier found in `src/live/client.rs`
- **sub**: Identifier found in `src/live/client.rs`
- **sub_base**: Identifier found in `src/live/client.rs`
- **sub_counter**: Identifier found in `src/live/client.rs`
- **sub_line**: Identifier found in `src/live/client.rs`
- **subscribe**: Identifier found in `src/live/client.rs`
- **subscribing**: Identifier found in `src/live/client.rs`
- **subscription**: Identifier found in `src/live/client.rs`
- **subscriptions**: Identifier found in `src/live/client.rs`
- **subscriptions_mut**: Identifier found in `src/live/client.rs`
- **succeeded**: Identifier found in `src/live/client.rs`
- **success**: Identifier found in `src/live/client.rs`
- **super**: Identifier found in `src/live/client.rs`
- **symbol**: Identifier found in `src/live/client.rs`
- **symbol_count**: Identifier found in `src/live/client.rs`
- **symbols**: Identifier found in `src/live/client.rs`
- **sync**: Identifier found in `src/live/client.rs`

### T

- **t7knhwj4xqr0qyjzfktbeg2ec2pxj4fk**: Identifier found in `src/live/client.rs`
- **target**: Identifier found in `src/live/client.rs`
- **task**: Identifier found in `src/live/client.rs`
- **tcp**: Identifier found in `src/live/client.rs`
- **tcplistener**: Identifier found in `src/live/client.rs`
- **tcpstream**: Identifier found in `src/live/client.rs`
- **test**: Identifier found in `src/live/client.rs`
- **test_cancellation_safety**: Identifier found in `src/live/client.rs`
- **test_close**: Identifier found in `src/live/client.rs`
- **test_error_without_success**: Identifier found in `src/live/client.rs`
- **test_next_record**: Identifier found in `src/live/client.rs`
- **test_next_record_with_ts_out**: Identifier found in `src/live/client.rs`
- **test_reconnect**: Identifier found in `src/live/client.rs`
- **test_subscribe**: Identifier found in `src/live/client.rs`
- **test_subscribe_snapshot**: Identifier found in `src/live/client.rs`
- **test_subscribe_snapshot_failed**: Identifier found in `src/live/client.rs`
- **test_subscription_chunking**: Identifier found in `src/live/client.rs`
- **tests**: Identifier found in `src/live/client.rs`
- **that**: Identifier found in `src/live/client.rs`
- **then**: Identifier found in `src/live/client.rs`
- **there**: Identifier found in `src/live/client.rs`
- **this**: Identifier found in `src/live/client.rs`
- **tick**: Identifier found in `src/live/client.rs`
- **time**: Identifier found in `src/live/client.rs`
- **to_api_string**: Identifier found in `src/live/client.rs`
- **to_owned**: Identifier found in `src/live/client.rs`
- **to_string**: Identifier found in `src/live/client.rs`
- **tokio**: Identifier found in `src/live/client.rs`
- **tosocketaddrs**: Identifier found in `src/live/client.rs`
- **tracing**: Identifier found in `src/live/client.rs`
- **tracing_subscriber**: Identifier found in `src/live/client.rs`
- **trade**: Identifier found in `src/live/client.rs`
- **trademsg**: Identifier found in `src/live/client.rs`
- **trades**: Identifier found in `src/live/client.rs`
- **true**: Identifier found in `src/live/client.rs`
- **try_init**: Identifier found in `src/live/client.rs`
- **ts_in_delta**: Identifier found in `src/live/client.rs`
- **ts_out**: Identifier found in `src/live/client.rs`
- **ts_recv**: Identifier found in `src/live/client.rs`
- **tsla**: Identifier found in `src/live/client.rs`
- **type**: Identifier found in `src/live/client.rs`

### U

- **u16**: Identifier found in `src/live/client.rs`
- **u32**: Identifier found in `src/live/client.rs`
- **u64**: Identifier found in `src/live/client.rs`
- **unable**: Identifier found in `src/live/client.rs`
- **unbounded_channel**: Identifier found in `src/live/client.rs`
- **unboundedsender**: Identifier found in `src/live/client.rs`
- **unix_epoch**: Identifier found in `src/live/client.rs`
- **unix_timestamp_nanos**: Identifier found in `src/live/client.rs`
- **unknown**: Identifier found in `src/live/client.rs`
- **unset**: Identifier found in `src/live/client.rs`
- **unsuccessful**: Identifier found in `src/live/client.rs`
- **unwrap**: Identifier found in `src/live/client.rs`
- **unwrap_err**: Identifier found in `src/live/client.rs`
- **unwrap_or**: Identifier found in `src/live/client.rs`
- **upgrade**: Identifier found in `src/live/client.rs`
- **upgrade_policy**: Identifier found in `src/live/client.rs`
- **usable**: Identifier found in `src/live/client.rs`
- **use_snapshot**: Identifier found in `src/live/client.rs`
- **used**: Identifier found in `src/live/client.rs`
- **useful**: Identifier found in `src/live/client.rs`
- **user_agent**: Identifier found in `src/live/client.rs`
- **user_agent_ext**: Identifier found in `src/live/client.rs`
- **usize**: Identifier found in `src/live/client.rs`
- **usually**: Identifier found in `src/live/client.rs`

### V

- **vec**: Identifier found in `src/live/client.rs`
- **version**: Identifier found in `src/live/client.rs`
- **versions**: Identifier found in `src/live/client.rs`
- **versionupgradepolicy**: Identifier found in `src/live/client.rs`
- **volume**: Identifier found in `src/live/client.rs`

### W

- **warn**: Identifier found in `src/live/client.rs`
- **when**: Identifier found in `src/live/client.rs`
- **where**: Identifier found in `src/live/client.rs`
- **whether**: Identifier found in `src/live/client.rs`
- **while**: Identifier found in `src/live/client.rs`
- **whole_seconds**: Identifier found in `src/live/client.rs`
- **will**: Identifier found in `src/live/client.rs`
- **with**: Identifier found in `src/live/client.rs`
- **with_max_level**: Identifier found in `src/live/client.rs`
- **with_test_writer**: Identifier found in `src/live/client.rs`
- **within**: Identifier found in `src/live/client.rs`
- **without**: Identifier found in `src/live/client.rs`
- **withtsout**: Identifier found in `src/live/client.rs`
- **write**: Identifier found in `src/live/client.rs`
- **write_all**: Identifier found in `src/live/client.rs`
- **writehalf**: Identifier found in `src/live/client.rs`

### X

- **xnasitch**: Identifier found in `src/live/client.rs`
