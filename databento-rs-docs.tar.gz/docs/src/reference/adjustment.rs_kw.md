# Keywords: adjustment.rs

## Extracted Keywords

Total keywords extracted: 313


### A

- **AdjustmentFactor**: Identifier found in `src/reference/adjustment.rs`
- **AdjustmentFactorsClient**: Identifier found in `src/reference/adjustment.rs`
- **action**: Identifier found in `src/reference/adjustment.rs`
- **actions**: Identifier found in `src/reference/adjustment.rs`
- **add_to_form**: Identifier found in `src/reference/adjustment.rs`
- **added**: Identifier found in `src/reference/adjustment.rs`
- **addtoform**: Identifier found in `src/reference/adjustment.rs`
- **adjustment**: Identifier found in `src/reference/adjustment.rs`
- **adjustment_factors**: Identifier found in `src/reference/adjustment.rs`
- **adjustmentfactor**: Identifier found in `src/reference/adjustment.rs`
- **adjustmentfactorsclient**: Identifier found in `src/reference/adjustment.rs`
- **adjustmentstatus**: Identifier found in `src/reference/adjustment.rs`
- **after**: Identifier found in `src/reference/adjustment.rs`
- **alpha**: Identifier found in `src/reference/adjustment.rs`
- **also**: Identifier found in `src/reference/adjustment.rs`
- **amount**: Identifier found in `src/reference/adjustment.rs`
- **any**: Identifier found in `src/reference/adjustment.rs`
- **api**: Identifier found in `src/reference/adjustment.rs`
- **api_key**: Identifier found in `src/reference/adjustment.rs`
- **api_version**: Identifier found in `src/reference/adjustment.rs`
- **applicable**: Identifier found in `src/reference/adjustment.rs`
- **apply**: Identifier found in `src/reference/adjustment.rs`
- **as_u16**: Identifier found in `src/reference/adjustment.rs`
- **assert_eq**: Identifier found in `src/reference/adjustment.rs`
- **associated**: Identifier found in `src/reference/adjustment.rs`
- **async**: Identifier found in `src/reference/adjustment.rs`
- **available**: Identifier found in `src/reference/adjustment.rs`
- **await**: Identifier found in `src/reference/adjustment.rs`

### B

- **basic_auth**: Identifier found in `src/reference/adjustment.rs`
- **bats**: Identifier found in `src/reference/adjustment.rs`
- **before**: Identifier found in `src/reference/adjustment.rs`
- **benefit**: Identifier found in `src/reference/adjustment.rs`
- **between**: Identifier found in `src/reference/adjustment.rs`
- **body_contains**: Identifier found in `src/reference/adjustment.rs`
- **build**: Identifier found in `src/reference/adjustment.rs`
- **builder**: Identifier found in `src/reference/adjustment.rs`
- **bytes**: Identifier found in `src/reference/adjustment.rs`

### C

- **calculation**: Identifier found in `src/reference/adjustment.rs`
- **cash**: Identifier found in `src/reference/adjustment.rs`
- **cfg**: Identifier found in `src/reference/adjustment.rs`
- **change**: Identifier found in `src/reference/adjustment.rs`
- **choice**: Identifier found in `src/reference/adjustment.rs`
- **client**: Identifier found in `src/reference/adjustment.rs`
- **clone**: Identifier found in `src/reference/adjustment.rs`
- **close**: Identifier found in `src/reference/adjustment.rs`
- **closing**: Identifier found in `src/reference/adjustment.rs`
- **code**: Identifier found in `src/reference/adjustment.rs`
- **codes**: Identifier found in `src/reference/adjustment.rs`
- **communicate**: Identifier found in `src/reference/adjustment.rs`
- **company**: Identifier found in `src/reference/adjustment.rs`
- **compression**: Identifier found in `src/reference/adjustment.rs`
- **concat**: Identifier found in `src/reference/adjustment.rs`
- **convention**: Identifier found in `src/reference/adjustment.rs`
- **corporate**: Identifier found in `src/reference/adjustment.rs`
- **correct**: Identifier found in `src/reference/adjustment.rs`
- **countries**: Identifier found in `src/reference/adjustment.rs`
- **country**: Identifier found in `src/reference/adjustment.rs`
- **crate**: Identifier found in `src/reference/adjustment.rs`
- **currency**: Identifier found in `src/reference/adjustment.rs`
- **cursor**: Identifier found in `src/reference/adjustment.rs`
- **cusip**: Identifier found in `src/reference/adjustment.rs`

### D

- **Databento**: Identifier found in `src/reference/adjustment.rs`
- **data**: Identifier found in `src/reference/adjustment.rs`
- **databento**: Identifier found in `src/reference/adjustment.rs`
- **date**: Identifier found in `src/reference/adjustment.rs`
- **datetime**: Identifier found in `src/reference/adjustment.rs`
- **datetimelike**: Identifier found in `src/reference/adjustment.rs`
- **dbn**: Identifier found in `src/reference/adjustment.rs`
- **debug**: Identifier found in `src/reference/adjustment.rs`
- **declared**: Identifier found in `src/reference/adjustment.rs`
- **deducted**: Identifier found in `src/reference/adjustment.rs`
- **default**: Identifier found in `src/reference/adjustment.rs`
- **defaults**: Identifier found in `src/reference/adjustment.rs`
- **derive**: Identifier found in `src/reference/adjustment.rs`
- **description**: Identifier found in `src/reference/adjustment.rs`
- **deserialize**: Identifier found in `src/reference/adjustment.rs`
- **deserialize_date_time**: Identifier found in `src/reference/adjustment.rs`
- **deserialize_with**: Identifier found in `src/reference/adjustment.rs`
- **detail**: Identifier found in `src/reference/adjustment.rs`
- **different**: Identifier found in `src/reference/adjustment.rs`
- **distinguish**: Identifier found in `src/reference/adjustment.rs`
- **div**: Identifier found in `src/reference/adjustment.rs`
- **divided**: Identifier found in `src/reference/adjustment.rs`
- **dividend**: Identifier found in `src/reference/adjustment.rs`
- **dividend_currency**: Identifier found in `src/reference/adjustment.rs`
- **domestic**: Identifier found in `src/reference/adjustment.rs`

### E

- **effective**: Identifier found in `src/reference/adjustment.rs`
- **either**: Identifier found in `src/reference/adjustment.rs`
- **encode_all**: Identifier found in `src/reference/adjustment.rs`
- **end**: Identifier found in `src/reference/adjustment.rs`
- **endpoints**: Identifier found in `src/reference/adjustment.rs`
- **eqs**: Identifier found in `src/reference/adjustment.rs`
- **equivalent**: Identifier found in `src/reference/adjustment.rs`
- **error**: Identifier found in `src/reference/adjustment.rs`
- **errors**: Identifier found in `src/reference/adjustment.rs`
- **etf**: Identifier found in `src/reference/adjustment.rs`
- **event**: Identifier found in `src/reference/adjustment.rs`
- **event_id**: Identifier found in `src/reference/adjustment.rs`
- **ex_date**: Identifier found in `src/reference/adjustment.rs`
- **exceptions**: Identifier found in `src/reference/adjustment.rs`
- **exchange**: Identifier found in `src/reference/adjustment.rs`
- **exclusive**: Identifier found in `src/reference/adjustment.rs`

### F

- **f64**: Identifier found in `src/reference/adjustment.rs`
- **factor**: Identifier found in `src/reference/adjustment.rs`
- **factors**: Identifier found in `src/reference/adjustment.rs`
- **fails**: Identifier found in `src/reference/adjustment.rs`
- **fashion**: Identifier found in `src/reference/adjustment.rs`
- **fees**: Identifier found in `src/reference/adjustment.rs`
- **filter**: Identifier found in `src/reference/adjustment.rs`
- **filters**: Identifier found in `src/reference/adjustment.rs`
- **fmtsubscriber**: Identifier found in `src/reference/adjustment.rs`
- **form**: Identifier found in `src/reference/adjustment.rs`
- **format**: Identifier found in `src/reference/adjustment.rs`
- **frequency**: Identifier found in `src/reference/adjustment.rs`
- **from**: Identifier found in `src/reference/adjustment.rs`
- **function**: Identifier found in `src/reference/adjustment.rs`

### G

- **GetRangeParams**: Identifier found in `src/reference/adjustment.rs`
- **get_range**: Identifier found in `src/reference/adjustment.rs`
- **getrangeparams**: Identifier found in `src/reference/adjustment.rs`
- **given**: Identifier found in `src/reference/adjustment.rs`
- **global**: Identifier found in `src/reference/adjustment.rs`
- **gross_dividend**: Identifier found in `src/reference/adjustment.rs`
- **group**: Identifier found in `src/reference/adjustment.rs`

### H

- **handle_zstd_jsonl_response**: Identifier found in `src/reference/adjustment.rs`
- **historical**: Identifier found in `src/reference/adjustment.rs`
- **human**: Identifier found in `src/reference/adjustment.rs`
- **hyd**: Identifier found in `src/reference/adjustment.rs`

### I

- **identifier**: Identifier found in `src/reference/adjustment.rs`
- **identifiers**: Identifier found in `src/reference/adjustment.rs`
- **impl**: Identifier found in `src/reference/adjustment.rs`
- **included**: Identifier found in `src/reference/adjustment.rs`
- **inclusive**: Identifier found in `src/reference/adjustment.rs`
- **index**: Identifier found in `src/reference/adjustment.rs`
- **indicates**: Identifier found in `src/reference/adjustment.rs`
- **inner**: Identifier found in `src/reference/adjustment.rs`
- **input**: Identifier found in `src/reference/adjustment.rs`
- **int**: Identifier found in `src/reference/adjustment.rs`
- **integrated**: Identifier found in `src/reference/adjustment.rs`
- **into**: Identifier found in `src/reference/adjustment.rs`
- **isin**: Identifier found in `src/reference/adjustment.rs`
- **isin_resulting**: Identifier found in `src/reference/adjustment.rs`
- **iso**: Identifier found in `src/reference/adjustment.rs`
- **issue**: Identifier found in `src/reference/adjustment.rs`
- **issuer**: Identifier found in `src/reference/adjustment.rs`
- **issuer_name**: Identifier found in `src/reference/adjustment.rs`

### K

- **known**: Identifier found in `src/reference/adjustment.rs`

### L

- **len**: Identifier found in `src/reference/adjustment.rs`
- **level**: Identifier found in `src/reference/adjustment.rs`
- **like**: Identifier found in `src/reference/adjustment.rs`
- **link**: Identifier found in `src/reference/adjustment.rs`
- **links**: Identifier found in `src/reference/adjustment.rs`
- **list**: Identifier found in `src/reference/adjustment.rs`
- **listing**: Identifier found in `src/reference/adjustment.rs`
- **listings**: Identifier found in `src/reference/adjustment.rs`
- **local**: Identifier found in `src/reference/adjustment.rs`
- **local_code**: Identifier found in `src/reference/adjustment.rs`
- **local_code_resulting**: Identifier found in `src/reference/adjustment.rs`

### M

- **macros**: Identifier found in `src/reference/adjustment.rs`
- **market**: Identifier found in `src/reference/adjustment.rs`
- **matched**: Identifier found in `src/reference/adjustment.rs`
- **matchers**: Identifier found in `src/reference/adjustment.rs`
- **method**: Identifier found in `src/reference/adjustment.rs`
- **mic**: Identifier found in `src/reference/adjustment.rs`
- **might**: Identifier found in `src/reference/adjustment.rs`
- **mnt**: Identifier found in `src/reference/adjustment.rs`
- **mock**: Identifier found in `src/reference/adjustment.rs`
- **mock_server**: Identifier found in `src/reference/adjustment.rs`
- **mockserver**: Identifier found in `src/reference/adjustment.rs`
- **mod**: Identifier found in `src/reference/adjustment.rs`
- **monthly**: Identifier found in `src/reference/adjustment.rs`
- **more**: Identifier found in `src/reference/adjustment.rs`
- **mount**: Identifier found in `src/reference/adjustment.rs`
- **msft**: Identifier found in `src/reference/adjustment.rs`
- **multiple**: Identifier found in `src/reference/adjustment.rs`
- **mut**: Identifier found in `src/reference/adjustment.rs`

### N

- **name**: Identifier found in `src/reference/adjustment.rs`
- **nasdaq**: Identifier found in `src/reference/adjustment.rs`
- **nasdaq_symbol**: Identifier found in `src/reference/adjustment.rs`
- **none**: Identifier found in `src/reference/adjustment.rs`
- **note**: Identifier found in `src/reference/adjustment.rs`
- **null**: Identifier found in `src/reference/adjustment.rs`
- **number**: Identifier found in `src/reference/adjustment.rs`
- **numerical**: Identifier found in `src/reference/adjustment.rs`

### O

- **offsetdatetime**: Identifier found in `src/reference/adjustment.rs`
- **often**: Identifier found in `src/reference/adjustment.rs`
- **only**: Identifier found in `src/reference/adjustment.rs`
- **open**: Identifier found in `src/reference/adjustment.rs`
- **operating_mic**: Identifier found in `src/reference/adjustment.rs`
- **option**: Identifier found in `src/reference/adjustment.rs`
- **optional**: Identifier found in `src/reference/adjustment.rs`
- **options**: Identifier found in `src/reference/adjustment.rs`
- **other**: Identifier found in `src/reference/adjustment.rs`

### P

- **paid**: Identifier found in `src/reference/adjustment.rs`
- **parameters**: Identifier found in `src/reference/adjustment.rs`
- **params**: Identifier found in `src/reference/adjustment.rs`
- **partialeq**: Identifier found in `src/reference/adjustment.rs`
- **path**: Identifier found in `src/reference/adjustment.rs`
- **platform**: Identifier found in `src/reference/adjustment.rs`
- **post**: Identifier found in `src/reference/adjustment.rs`
- **preset**: Identifier found in `src/reference/adjustment.rs`
- **previous**: Identifier found in `src/reference/adjustment.rs`
- **price**: Identifier found in `src/reference/adjustment.rs`
- **primary**: Identifier found in `src/reference/adjustment.rs`
- **primary_exchange**: Identifier found in `src/reference/adjustment.rs`
- **pub**: Identifier found in `src/reference/adjustment.rs`

### Q

- **query**: Identifier found in `src/reference/adjustment.rs`

### R

- **range**: Identifier found in `src/reference/adjustment.rs`
- **raw_symbol**: Identifier found in `src/reference/adjustment.rs`
- **rawsymbol**: Identifier found in `src/reference/adjustment.rs`
- **reaction**: Identifier found in `src/reference/adjustment.rs`
- **readable**: Identifier found in `src/reference/adjustment.rs`
- **reason**: Identifier found in `src/reference/adjustment.rs`
- **receive**: Identifier found in `src/reference/adjustment.rs`
- **record**: Identifier found in `src/reference/adjustment.rs`
- **reference**: Identifier found in `src/reference/adjustment.rs`
- **remain**: Identifier found in `src/reference/adjustment.rs`
- **represents**: Identifier found in `src/reference/adjustment.rs`
- **request**: Identifier found in `src/reference/adjustment.rs`
- **requests**: Identifier found in `src/reference/adjustment.rs`
- **requires**: Identifier found in `src/reference/adjustment.rs`
- **reqwest**: Identifier found in `src/reference/adjustment.rs`
- **res**: Identifier found in `src/reference/adjustment.rs`
- **resp**: Identifier found in `src/reference/adjustment.rs`
- **respond_with**: Identifier found in `src/reference/adjustment.rs`
- **response**: Identifier found in `src/reference/adjustment.rs`
- **responsetemplate**: Identifier found in `src/reference/adjustment.rs`
- **result**: Identifier found in `src/reference/adjustment.rs`
- **resultant**: Identifier found in `src/reference/adjustment.rs`
- **returns**: Identifier found in `src/reference/adjustment.rs`
- **rule**: Identifier found in `src/reference/adjustment.rs`

### S

- **same**: Identifier found in `src/reference/adjustment.rs`
- **script**: Identifier found in `src/reference/adjustment.rs`
- **security**: Identifier found in `src/reference/adjustment.rs`
- **security_id**: Identifier found in `src/reference/adjustment.rs`
- **security_type**: Identifier found in `src/reference/adjustment.rs`
- **security_types**: Identifier found in `src/reference/adjustment.rs`
- **securitytype**: Identifier found in `src/reference/adjustment.rs`
- **self**: Identifier found in `src/reference/adjustment.rs`
- **send**: Identifier found in `src/reference/adjustment.rs`
- **sentiment**: Identifier found in `src/reference/adjustment.rs`
- **serde**: Identifier found in `src/reference/adjustment.rs`
- **series**: Identifier found in `src/reference/adjustment.rs`
- **set_body_bytes**: Identifier found in `src/reference/adjustment.rs`
- **setter**: Identifier found in `src/reference/adjustment.rs`
- **shareholders**: Identifier found in `src/reference/adjustment.rs`
- **simply**: Identifier found in `src/reference/adjustment.rs`
- **some**: Identifier found in `src/reference/adjustment.rs`
- **sort_by_key**: Identifier found in `src/reference/adjustment.rs`
- **stable**: Identifier found in `src/reference/adjustment.rs`
- **start**: Identifier found in `src/reference/adjustment.rs`
- **status**: Identifier found in `src/reference/adjustment.rs`
- **statuscode**: Identifier found in `src/reference/adjustment.rs`
- **std**: Identifier found in `src/reference/adjustment.rs`
- **string**: Identifier found in `src/reference/adjustment.rs`
- **struct**: Identifier found in `src/reference/adjustment.rs`
- **stype**: Identifier found in `src/reference/adjustment.rs`
- **stype_in**: Identifier found in `src/reference/adjustment.rs`
- **suffix**: Identifier found in `src/reference/adjustment.rs`
- **super**: Identifier found in `src/reference/adjustment.rs`
- **symbol**: Identifier found in `src/reference/adjustment.rs`
- **symbology**: Identifier found in `src/reference/adjustment.rs`
- **symbols**: Identifier found in `src/reference/adjustment.rs`

### T

- **taxes**: Identifier found in `src/reference/adjustment.rs`
- **test**: Identifier found in `src/reference/adjustment.rs`
- **test_get_range**: Identifier found in `src/reference/adjustment.rs`
- **test_infra**: Identifier found in `src/reference/adjustment.rs`
- **tests**: Identifier found in `src/reference/adjustment.rs`
- **that**: Identifier found in `src/reference/adjustment.rs`
- **there**: Identifier found in `src/reference/adjustment.rs`
- **they**: Identifier found in `src/reference/adjustment.rs`
- **this**: Identifier found in `src/reference/adjustment.rs`
- **time**: Identifier found in `src/reference/adjustment.rs`
- **timely**: Identifier found in `src/reference/adjustment.rs`
- **timestamp**: Identifier found in `src/reference/adjustment.rs`
- **to_api_string**: Identifier found in `src/reference/adjustment.rs`
- **to_date_time**: Identifier found in `src/reference/adjustment.rs`
- **to_string**: Identifier found in `src/reference/adjustment.rs`
- **today**: Identifier found in `src/reference/adjustment.rs`
- **together**: Identifier found in `src/reference/adjustment.rs`
- **tokio**: Identifier found in `src/reference/adjustment.rs`
- **total**: Identifier found in `src/reference/adjustment.rs`
- **tracing_subscriber**: Identifier found in `src/reference/adjustment.rs`
- **transform**: Identifier found in `src/reference/adjustment.rs`
- **trust**: Identifier found in `src/reference/adjustment.rs`
- **try_init**: Identifier found in `src/reference/adjustment.rs`
- **ts_created**: Identifier found in `src/reference/adjustment.rs`
- **type**: Identifier found in `src/reference/adjustment.rs`
- **typed_builder**: Identifier found in `src/reference/adjustment.rs`
- **typedbuilder**: Identifier found in `src/reference/adjustment.rs`
- **types**: Identifier found in `src/reference/adjustment.rs`

### U

- **u32**: Identifier found in `src/reference/adjustment.rs`
- **unique**: Identifier found in `src/reference/adjustment.rs`
- **unix_timestamp_nanos**: Identifier found in `src/reference/adjustment.rs`
- **unwrap**: Identifier found in `src/reference/adjustment.rs`
- **us92189h4092**: Identifier found in `src/reference/adjustment.rs`
- **us_code**: Identifier found in `src/reference/adjustment.rs`
- **usbats**: Identifier found in `src/reference/adjustment.rs`
- **usd**: Identifier found in `src/reference/adjustment.rs`
- **usd0**: Identifier found in `src/reference/adjustment.rs`
- **used**: Identifier found in `src/reference/adjustment.rs`
- **usually**: Identifier found in `src/reference/adjustment.rs`
- **utc**: Identifier found in `src/reference/adjustment.rs`

### V

- **value**: Identifier found in `src/reference/adjustment.rs`
- **vaneck**: Identifier found in `src/reference/adjustment.rs`
- **vec**: Identifier found in `src/reference/adjustment.rs`

### W

- **when**: Identifier found in `src/reference/adjustment.rs`
- **which**: Identifier found in `src/reference/adjustment.rs`
- **will**: Identifier found in `src/reference/adjustment.rs`
- **wiremock**: Identifier found in `src/reference/adjustment.rs`
- **with**: Identifier found in `src/reference/adjustment.rs`
- **with_test_writer**: Identifier found in `src/reference/adjustment.rs`
- **would**: Identifier found in `src/reference/adjustment.rs`

### Z

- **zstd**: Identifier found in `src/reference/adjustment.rs`
