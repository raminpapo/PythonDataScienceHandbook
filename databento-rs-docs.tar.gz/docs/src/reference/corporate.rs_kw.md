# Keywords: corporate.rs

## Extracted Keywords

Total keywords extracted: 571


### A

- **accept**: Identifier found in `src/reference/corporate.rs`
- **accepted**: Identifier found in `src/reference/corporate.rs`
- **acquired**: Identifier found in `src/reference/corporate.rs`
- **action**: Identifier found in `src/reference/corporate.rs`
- **actions**: Identifier found in `src/reference/corporate.rs`
- **active**: Identifier found in `src/reference/corporate.rs`
- **activity**: Identifier found in `src/reference/corporate.rs`
- **add_to_form**: Identifier found in `src/reference/corporate.rs`
- **added**: Identifier found in `src/reference/corporate.rs`
- **additional**: Identifier found in `src/reference/corporate.rs`
- **addtoform**: Identifier found in `src/reference/corporate.rs`
- **after**: Identifier found in `src/reference/corporate.rs`
- **allowing**: Identifier found in `src/reference/corporate.rs`
- **alpha**: Identifier found in `src/reference/corporate.rs`
- **amount**: Identifier found in `src/reference/corporate.rs`
- **ands**: Identifier found in `src/reference/corporate.rs`
- **another**: Identifier found in `src/reference/corporate.rs`
- **anticipated**: Identifier found in `src/reference/corporate.rs`
- **api**: Identifier found in `src/reference/corporate.rs`
- **api_key**: Identifier found in `src/reference/corporate.rs`
- **api_version**: Identifier found in `src/reference/corporate.rs`
- **applicable**: Identifier found in `src/reference/corporate.rs`
- **as_u16**: Identifier found in `src/reference/corporate.rs`
- **assert**: Identifier found in `src/reference/corporate.rs`
- **assert_eq**: Identifier found in `src/reference/corporate.rs`
- **asset**: Identifier found in `src/reference/corporate.rs`
- **associated**: Identifier found in `src/reference/corporate.rs`
- **async**: Identifier found in `src/reference/corporate.rs`
- **available**: Identifier found in `src/reference/corporate.rs`
- **await**: Identifier found in `src/reference/corporate.rs`

### B

- **basic_auth**: Identifier found in `src/reference/corporate.rs`
- **bbg00b9rg1j6**: Identifier found in `src/reference/corporate.rs`
- **bbg00b9rg1w1**: Identifier found in `src/reference/corporate.rs`
- **bbg_comp_id**: Identifier found in `src/reference/corporate.rs`
- **bbg_comp_ticker**: Identifier found in `src/reference/corporate.rs`
- **become**: Identifier found in `src/reference/corporate.rs`
- **becomes**: Identifier found in `src/reference/corporate.rs`
- **begins**: Identifier found in `src/reference/corporate.rs`
- **being**: Identifier found in `src/reference/corporate.rs`
- **benefit**: Identifier found in `src/reference/corporate.rs`
- **bids**: Identifier found in `src/reference/corporate.rs`
- **bills**: Identifier found in `src/reference/corporate.rs`
- **binding**: Identifier found in `src/reference/corporate.rs`
- **bloomberg**: Identifier found in `src/reference/corporate.rs`
- **body_contains**: Identifier found in `src/reference/corporate.rs`
- **bool**: Identifier found in `src/reference/corporate.rs`
- **borqs**: Identifier found in `src/reference/corporate.rs`
- **brqs**: Identifier found in `src/reference/corporate.rs`
- **build**: Identifier found in `src/reference/corporate.rs`
- **builder**: Identifier found in `src/reference/corporate.rs`
- **business**: Identifier found in `src/reference/corporate.rs`
- **bytes**: Identifier found in `src/reference/corporate.rs`

### C

- **CorporateAction**: Identifier found in `src/reference/corporate.rs`
- **CorporateActionsClient**: Identifier found in `src/reference/corporate.rs`
- **calculate**: Identifier found in `src/reference/corporate.rs`
- **calculations**: Identifier found in `src/reference/corporate.rs`
- **calendar**: Identifier found in `src/reference/corporate.rs`
- **capital**: Identifier found in `src/reference/corporate.rs`
- **case**: Identifier found in `src/reference/corporate.rs`
- **cash**: Identifier found in `src/reference/corporate.rs`
- **ceases**: Identifier found in `src/reference/corporate.rs`
- **cfg**: Identifier found in `src/reference/corporate.rs`
- **changed**: Identifier found in `src/reference/corporate.rs`
- **changes**: Identifier found in `src/reference/corporate.rs`
- **choose**: Identifier found in `src/reference/corporate.rs`
- **client**: Identifier found in `src/reference/corporate.rs`
- **clone**: Identifier found in `src/reference/corporate.rs`
- **close_date**: Identifier found in `src/reference/corporate.rs`
- **closing**: Identifier found in `src/reference/corporate.rs`
- **code**: Identifier found in `src/reference/corporate.rs`
- **codes**: Identifier found in `src/reference/corporate.rs`
- **collections**: Identifier found in `src/reference/corporate.rs`
- **communicate**: Identifier found in `src/reference/corporate.rs`
- **company**: Identifier found in `src/reference/corporate.rs`
- **completed**: Identifier found in `src/reference/corporate.rs`
- **composite**: Identifier found in `src/reference/corporate.rs`
- **compression**: Identifier found in `src/reference/corporate.rs`
- **concat**: Identifier found in `src/reference/corporate.rs`
- **concatenation**: Identifier found in `src/reference/corporate.rs`
- **consd**: Identifier found in `src/reference/corporate.rs`
- **contains_key**: Identifier found in `src/reference/corporate.rs`
- **convention**: Identifier found in `src/reference/corporate.rs`
- **corporate**: Identifier found in `src/reference/corporate.rs`
- **corporate_actions**: Identifier found in `src/reference/corporate.rs`
- **corporateaction**: Identifier found in `src/reference/corporate.rs`
- **corporateactionsclient**: Identifier found in `src/reference/corporate.rs`
- **correctly**: Identifier found in `src/reference/corporate.rs`
- **countries**: Identifier found in `src/reference/corporate.rs`
- **country**: Identifier found in `src/reference/corporate.rs`
- **crate**: Identifier found in `src/reference/corporate.rs`
- **created**: Identifier found in `src/reference/corporate.rs`
- **currencies**: Identifier found in `src/reference/corporate.rs`
- **currency**: Identifier found in `src/reference/corporate.rs`
- **currently**: Identifier found in `src/reference/corporate.rs`
- **cursor**: Identifier found in `src/reference/corporate.rs`
- **cusip**: Identifier found in `src/reference/corporate.rs`
- **cut**: Identifier found in `src/reference/corporate.rs`

### D

- **Databento**: Identifier found in `src/reference/corporate.rs`
- **data**: Identifier found in `src/reference/corporate.rs`
- **databento**: Identifier found in `src/reference/corporate.rs`
- **date**: Identifier found in `src/reference/corporate.rs`
- **date_info**: Identifier found in `src/reference/corporate.rs`
- **dates**: Identifier found in `src/reference/corporate.rs`
- **datetime**: Identifier found in `src/reference/corporate.rs`
- **datetimelike**: Identifier found in `src/reference/corporate.rs`
- **dbn**: Identifier found in `src/reference/corporate.rs`
- **deadline**: Identifier found in `src/reference/corporate.rs`
- **debug**: Identifier found in `src/reference/corporate.rs`
- **deduplicate**: Identifier found in `src/reference/corporate.rs`
- **default**: Identifier found in `src/reference/corporate.rs`
- **default_option_flag**: Identifier found in `src/reference/corporate.rs`
- **defaults**: Identifier found in `src/reference/corporate.rs`
- **delisting_date**: Identifier found in `src/reference/corporate.rs`
- **denominator**: Identifier found in `src/reference/corporate.rs`
- **derive**: Identifier found in `src/reference/corporate.rs`
- **describes**: Identifier found in `src/reference/corporate.rs`
- **description**: Identifier found in `src/reference/corporate.rs`
- **deserialize**: Identifier found in `src/reference/corporate.rs`
- **deserialize_date_time**: Identifier found in `src/reference/corporate.rs`
- **deserialize_opt_date_time_hash_map**: Identifier found in `src/reference/corporate.rs`
- **deserialize_with**: Identifier found in `src/reference/corporate.rs`
- **determine**: Identifier found in `src/reference/corporate.rs`
- **different**: Identifier found in `src/reference/corporate.rs`
- **direct**: Identifier found in `src/reference/corporate.rs`
- **display**: Identifier found in `src/reference/corporate.rs`
- **distinct**: Identifier found in `src/reference/corporate.rs`
- **dividend**: Identifier found in `src/reference/corporate.rs`
- **dividends**: Identifier found in `src/reference/corporate.rs`
- **domestic**: Identifier found in `src/reference/corporate.rs`
- **due**: Identifier found in `src/reference/corporate.rs`
- **duebills_redemption_date**: Identifier found in `src/reference/corporate.rs`

### E

- **Exchanges**: Identifier found in `src/reference/corporate.rs`
- **earliest**: Identifier found in `src/reference/corporate.rs`
- **effect**: Identifier found in `src/reference/corporate.rs`
- **effective**: Identifier found in `src/reference/corporate.rs`
- **effective_date**: Identifier found in `src/reference/corporate.rs`
- **either**: Identifier found in `src/reference/corporate.rs`
- **elect**: Identifier found in `src/reference/corporate.rs`
- **election**: Identifier found in `src/reference/corporate.rs`
- **eligible**: Identifier found in `src/reference/corporate.rs`
- **encode_all**: Identifier found in `src/reference/corporate.rs`
- **end**: Identifier found in `src/reference/corporate.rs`
- **end_date**: Identifier found in `src/reference/corporate.rs`
- **end_subscription_date**: Identifier found in `src/reference/corporate.rs`
- **endpoints**: Identifier found in `src/reference/corporate.rs`
- **ends**: Identifier found in `src/reference/corporate.rs`
- **entitled**: Identifier found in `src/reference/corporate.rs`
- **enum**: Identifier found in `src/reference/corporate.rs`
- **eqs**: Identifier found in `src/reference/corporate.rs`
- **error**: Identifier found in `src/reference/corporate.rs`
- **errors**: Identifier found in `src/reference/corporate.rs`
- **event**: Identifier found in `src/reference/corporate.rs`
- **event_action**: Identifier found in `src/reference/corporate.rs`
- **event_created_date**: Identifier found in `src/reference/corporate.rs`
- **event_date**: Identifier found in `src/reference/corporate.rs`
- **event_date_label**: Identifier found in `src/reference/corporate.rs`
- **event_id**: Identifier found in `src/reference/corporate.rs`
- **event_info**: Identifier found in `src/reference/corporate.rs`
- **event_subtype**: Identifier found in `src/reference/corporate.rs`
- **event_unique_id**: Identifier found in `src/reference/corporate.rs`
- **eventdate**: Identifier found in `src/reference/corporate.rs`
- **events**: Identifier found in `src/reference/corporate.rs`
- **eventsubtype**: Identifier found in `src/reference/corporate.rs`
- **ex_date**: Identifier found in `src/reference/corporate.rs`
- **exceptions**: Identifier found in `src/reference/corporate.rs`
- **exchange**: Identifier found in `src/reference/corporate.rs`
- **exchanges**: Identifier found in `src/reference/corporate.rs`
- **exclusive**: Identifier found in `src/reference/corporate.rs`
- **exdate**: Identifier found in `src/reference/corporate.rs`
- **executed**: Identifier found in `src/reference/corporate.rs`
- **exercise**: Identifier found in `src/reference/corporate.rs`
- **exercised**: Identifier found in `src/reference/corporate.rs`
- **existing**: Identifier found in `src/reference/corporate.rs`
- **exp_completion_date**: Identifier found in `src/reference/corporate.rs`
- **expected**: Identifier found in `src/reference/corporate.rs`
- **expiry**: Identifier found in `src/reference/corporate.rs`
- **expiry_time**: Identifier found in `src/reference/corporate.rs`
- **expiry_tz**: Identifier found in `src/reference/corporate.rs`

### F

- **f64**: Identifier found in `src/reference/corporate.rs`
- **fails**: Identifier found in `src/reference/corporate.rs`
- **falls**: Identifier found in `src/reference/corporate.rs`
- **false**: Identifier found in `src/reference/corporate.rs`
- **field**: Identifier found in `src/reference/corporate.rs`
- **figi**: Identifier found in `src/reference/corporate.rs`
- **figi_ticker**: Identifier found in `src/reference/corporate.rs`
- **filter**: Identifier found in `src/reference/corporate.rs`
- **filtering**: Identifier found in `src/reference/corporate.rs`
- **filters**: Identifier found in `src/reference/corporate.rs`
- **final**: Identifier found in `src/reference/corporate.rs`
- **financial**: Identifier found in `src/reference/corporate.rs`
- **financial_year_end_date**: Identifier found in `src/reference/corporate.rs`
- **financials**: Identifier found in `src/reference/corporate.rs`
- **flag**: Identifier found in `src/reference/corporate.rs`
- **fmt**: Identifier found in `src/reference/corporate.rs`
- **fmtsubscriber**: Identifier found in `src/reference/corporate.rs`
- **form**: Identifier found in `src/reference/corporate.rs`
- **format**: Identifier found in `src/reference/corporate.rs`
- **formatter**: Identifier found in `src/reference/corporate.rs`
- **fraction**: Identifier found in `src/reference/corporate.rs`
- **fractions**: Identifier found in `src/reference/corporate.rs`
- **from**: Identifier found in `src/reference/corporate.rs`
- **from_date**: Identifier found in `src/reference/corporate.rs`
- **function**: Identifier found in `src/reference/corporate.rs`

### G

- **GetRangeParams**: Identifier found in `src/reference/corporate.rs`
- **g1466b145**: Identifier found in `src/reference/corporate.rs`
- **get_range**: Identifier found in `src/reference/corporate.rs`
- **getrangeparams**: Identifier found in `src/reference/corporate.rs`
- **given**: Identifier found in `src/reference/corporate.rs`
- **global**: Identifier found in `src/reference/corporate.rs`
- **global_status**: Identifier found in `src/reference/corporate.rs`
- **globalstatus**: Identifier found in `src/reference/corporate.rs`
- **group**: Identifier found in `src/reference/corporate.rs`
- **groupings**: Identifier found in `src/reference/corporate.rs`
- **groups**: Identifier found in `src/reference/corporate.rs`

### H

- **handle_zstd_jsonl_response**: Identifier found in `src/reference/corporate.rs`
- **handled**: Identifier found in `src/reference/corporate.rs`
- **hash**: Identifier found in `src/reference/corporate.rs`
- **hashmap**: Identifier found in `src/reference/corporate.rs`
- **held**: Identifier found in `src/reference/corporate.rs`
- **historical**: Identifier found in `src/reference/corporate.rs`
- **holding**: Identifier found in `src/reference/corporate.rs`

### I

- **Index**: Identifier found in `src/reference/corporate.rs`
- **identifier**: Identifier found in `src/reference/corporate.rs`
- **identifiers**: Identifier found in `src/reference/corporate.rs`
- **impl**: Identifier found in `src/reference/corporate.rs`
- **inc**: Identifier found in `src/reference/corporate.rs`
- **included**: Identifier found in `src/reference/corporate.rs`
- **inclusive**: Identifier found in `src/reference/corporate.rs`
- **index**: Identifier found in `src/reference/corporate.rs`
- **indicates**: Identifier found in `src/reference/corporate.rs`
- **indicating**: Identifier found in `src/reference/corporate.rs`
- **information**: Identifier found in `src/reference/corporate.rs`
- **inner**: Identifier found in `src/reference/corporate.rs`
- **input**: Identifier found in `src/reference/corporate.rs`
- **integrated**: Identifier found in `src/reference/corporate.rs`
- **into**: Identifier found in `src/reference/corporate.rs`
- **is_empty**: Identifier found in `src/reference/corporate.rs`
- **isin**: Identifier found in `src/reference/corporate.rs`
- **iso**: Identifier found in `src/reference/corporate.rs`
- **issue**: Identifier found in `src/reference/corporate.rs`
- **issued**: Identifier found in `src/reference/corporate.rs`
- **issuer**: Identifier found in `src/reference/corporate.rs`
- **issuer_id**: Identifier found in `src/reference/corporate.rs`
- **issuer_name**: Identifier found in `src/reference/corporate.rs`

### J

- **join**: Identifier found in `src/reference/corporate.rs`

### L

- **last**: Identifier found in `src/reference/corporate.rs`
- **len**: Identifier found in `src/reference/corporate.rs`
- **level**: Identifier found in `src/reference/corporate.rs`
- **limited**: Identifier found in `src/reference/corporate.rs`
- **link**: Identifier found in `src/reference/corporate.rs`
- **links**: Identifier found in `src/reference/corporate.rs`
- **list**: Identifier found in `src/reference/corporate.rs`
- **listed**: Identifier found in `src/reference/corporate.rs`
- **listing**: Identifier found in `src/reference/corporate.rs`
- **listing_country**: Identifier found in `src/reference/corporate.rs`
- **listing_date**: Identifier found in `src/reference/corporate.rs`
- **listing_group_id**: Identifier found in `src/reference/corporate.rs`
- **listing_id**: Identifier found in `src/reference/corporate.rs`
- **listing_source**: Identifier found in `src/reference/corporate.rs`
- **listing_status**: Identifier found in `src/reference/corporate.rs`
- **listings**: Identifier found in `src/reference/corporate.rs`
- **listingsource**: Identifier found in `src/reference/corporate.rs`
- **listingstatus**: Identifier found in `src/reference/corporate.rs`
- **local**: Identifier found in `src/reference/corporate.rs`
- **local_code**: Identifier found in `src/reference/corporate.rs`
- **lot**: Identifier found in `src/reference/corporate.rs`
- **lot_size**: Identifier found in `src/reference/corporate.rs`

### M

- **macros**: Identifier found in `src/reference/corporate.rs`
- **made**: Identifier found in `src/reference/corporate.rs`
- **main**: Identifier found in `src/reference/corporate.rs`
- **mand_volu_flag**: Identifier found in `src/reference/corporate.rs`
- **mandatory**: Identifier found in `src/reference/corporate.rs`
- **mandvolu**: Identifier found in `src/reference/corporate.rs`
- **market**: Identifier found in `src/reference/corporate.rs`
- **marking**: Identifier found in `src/reference/corporate.rs`
- **match**: Identifier found in `src/reference/corporate.rs`
- **matched**: Identifier found in `src/reference/corporate.rs`
- **matchers**: Identifier found in `src/reference/corporate.rs`
- **max_accept_qty**: Identifier found in `src/reference/corporate.rs`
- **max_offer_qty**: Identifier found in `src/reference/corporate.rs`
- **max_qualify_qty**: Identifier found in `src/reference/corporate.rs`
- **method**: Identifier found in `src/reference/corporate.rs`
- **mic**: Identifier found in `src/reference/corporate.rs`
- **min_accept_qty**: Identifier found in `src/reference/corporate.rs`
- **min_offer_qty**: Identifier found in `src/reference/corporate.rs`
- **min_qualify_qty**: Identifier found in `src/reference/corporate.rs`
- **minimum**: Identifier found in `src/reference/corporate.rs`
- **mock**: Identifier found in `src/reference/corporate.rs`
- **mock_server**: Identifier found in `src/reference/corporate.rs`
- **mockserver**: Identifier found in `src/reference/corporate.rs`
- **mod**: Identifier found in `src/reference/corporate.rs`
- **more**: Identifier found in `src/reference/corporate.rs`
- **mount**: Identifier found in `src/reference/corporate.rs`
- **msft**: Identifier found in `src/reference/corporate.rs`
- **multi_currency**: Identifier found in `src/reference/corporate.rs`
- **multiple**: Identifier found in `src/reference/corporate.rs`
- **must**: Identifier found in `src/reference/corporate.rs`
- **mut**: Identifier found in `src/reference/corporate.rs`

### N

- **name**: Identifier found in `src/reference/corporate.rs`
- **nasdaq**: Identifier found in `src/reference/corporate.rs`
- **nasdaq_symbol**: Identifier found in `src/reference/corporate.rs`
- **ndicates**: Identifier found in `src/reference/corporate.rs`
- **necessary**: Identifier found in `src/reference/corporate.rs`
- **newo**: Identifier found in `src/reference/corporate.rs`
- **none**: Identifier found in `src/reference/corporate.rs`
- **notification**: Identifier found in `src/reference/corporate.rs`
- **notification_date**: Identifier found in `src/reference/corporate.rs`
- **null**: Identifier found in `src/reference/corporate.rs`
- **number**: Identifier found in `src/reference/corporate.rs`
- **numerator**: Identifier found in `src/reference/corporate.rs`
- **numerical**: Identifier found in `src/reference/corporate.rs`

### O

- **occur**: Identifier found in `src/reference/corporate.rs`
- **off**: Identifier found in `src/reference/corporate.rs`
- **offer**: Identifier found in `src/reference/corporate.rs`
- **offered**: Identifier found in `src/reference/corporate.rs`
- **offeror**: Identifier found in `src/reference/corporate.rs`
- **officially**: Identifier found in `src/reference/corporate.rs`
- **offsetdatetime**: Identifier found in `src/reference/corporate.rs`
- **often**: Identifier found in `src/reference/corporate.rs`
- **only**: Identifier found in `src/reference/corporate.rs`
- **open_date**: Identifier found in `src/reference/corporate.rs`
- **opens**: Identifier found in `src/reference/corporate.rs`
- **operating_mic**: Identifier found in `src/reference/corporate.rs`
- **option**: Identifier found in `src/reference/corporate.rs`
- **option_election_date**: Identifier found in `src/reference/corporate.rs`
- **option_expiry_time**: Identifier found in `src/reference/corporate.rs`
- **option_expiry_tz**: Identifier found in `src/reference/corporate.rs`
- **option_id**: Identifier found in `src/reference/corporate.rs`
- **optional**: Identifier found in `src/reference/corporate.rs`
- **options**: Identifier found in `src/reference/corporate.rs`
- **ord**: Identifier found in `src/reference/corporate.rs`
- **order**: Identifier found in `src/reference/corporate.rs`
- **ordinary**: Identifier found in `src/reference/corporate.rs`
- **ors**: Identifier found in `src/reference/corporate.rs`
- **outcomes**: Identifier found in `src/reference/corporate.rs`
- **outturn**: Identifier found in `src/reference/corporate.rs`
- **outturn_bbg_comp_id**: Identifier found in `src/reference/corporate.rs`
- **outturn_bbg_comp_ticker**: Identifier found in `src/reference/corporate.rs`
- **outturn_figi**: Identifier found in `src/reference/corporate.rs`
- **outturn_figi_ticker**: Identifier found in `src/reference/corporate.rs`
- **outturn_isin**: Identifier found in `src/reference/corporate.rs`
- **outturn_local_code**: Identifier found in `src/reference/corporate.rs`
- **outturn_security_id**: Identifier found in `src/reference/corporate.rs`
- **outturn_security_type**: Identifier found in `src/reference/corporate.rs`
- **outturn_style**: Identifier found in `src/reference/corporate.rs`
- **outturn_us_code**: Identifier found in `src/reference/corporate.rs`
- **outturnstyle**: Identifier found in `src/reference/corporate.rs`

### P

- **par**: Identifier found in `src/reference/corporate.rs`
- **par_value**: Identifier found in `src/reference/corporate.rs`
- **par_value_currency**: Identifier found in `src/reference/corporate.rs`
- **par_value_new**: Identifier found in `src/reference/corporate.rs`
- **par_value_old**: Identifier found in `src/reference/corporate.rs`
- **parameters**: Identifier found in `src/reference/corporate.rs`
- **params**: Identifier found in `src/reference/corporate.rs`
- **part**: Identifier found in `src/reference/corporate.rs`
- **partialeq**: Identifier found in `src/reference/corporate.rs`
- **partialord**: Identifier found in `src/reference/corporate.rs`
- **participants**: Identifier found in `src/reference/corporate.rs`
- **participate**: Identifier found in `src/reference/corporate.rs`
- **participation**: Identifier found in `src/reference/corporate.rs`
- **path**: Identifier found in `src/reference/corporate.rs`
- **payment**: Identifier found in `src/reference/corporate.rs`
- **payment_date**: Identifier found in `src/reference/corporate.rs`
- **payment_type**: Identifier found in `src/reference/corporate.rs`
- **payments**: Identifier found in `src/reference/corporate.rs`
- **paymenttype**: Identifier found in `src/reference/corporate.rs`
- **period**: Identifier found in `src/reference/corporate.rs`
- **platform**: Identifier found in `src/reference/corporate.rs`
- **populated**: Identifier found in `src/reference/corporate.rs`
- **post**: Identifier found in `src/reference/corporate.rs`
- **preset**: Identifier found in `src/reference/corporate.rs`
- **price**: Identifier found in `src/reference/corporate.rs`
- **primary**: Identifier found in `src/reference/corporate.rs`
- **primary_exchange**: Identifier found in `src/reference/corporate.rs`
- **priority**: Identifier found in `src/reference/corporate.rs`
- **process**: Identifier found in `src/reference/corporate.rs`
- **pub**: Identifier found in `src/reference/corporate.rs`
- **public**: Identifier found in `src/reference/corporate.rs`
- **push**: Identifier found in `src/reference/corporate.rs`

### Q

- **qualify**: Identifier found in `src/reference/corporate.rs`
- **quantity**: Identifier found in `src/reference/corporate.rs`
- **query**: Identifier found in `src/reference/corporate.rs`

### R

- **range**: Identifier found in `src/reference/corporate.rs`
- **rate_currency**: Identifier found in `src/reference/corporate.rs`
- **rate_info**: Identifier found in `src/reference/corporate.rs`
- **ratio**: Identifier found in `src/reference/corporate.rs`
- **ratio_new**: Identifier found in `src/reference/corporate.rs`
- **ratio_old**: Identifier found in `src/reference/corporate.rs`
- **raw_symbol**: Identifier found in `src/reference/corporate.rs`
- **rawsymbol**: Identifier found in `src/reference/corporate.rs`
- **rd_priority**: Identifier found in `src/reference/corporate.rs`
- **receive**: Identifier found in `src/reference/corporate.rs`
- **recognized**: Identifier found in `src/reference/corporate.rs`
- **record**: Identifier found in `src/reference/corporate.rs`
- **record_date**: Identifier found in `src/reference/corporate.rs`
- **record_date_id**: Identifier found in `src/reference/corporate.rs`
- **recorded**: Identifier found in `src/reference/corporate.rs`
- **records**: Identifier found in `src/reference/corporate.rs`
- **redemption**: Identifier found in `src/reference/corporate.rs`
- **reference**: Identifier found in `src/reference/corporate.rs`
- **register**: Identifier found in `src/reference/corporate.rs`
- **register_country**: Identifier found in `src/reference/corporate.rs`
- **registration**: Identifier found in `src/reference/corporate.rs`
- **registration_date**: Identifier found in `src/reference/corporate.rs`
- **related**: Identifier found in `src/reference/corporate.rs`
- **related_event**: Identifier found in `src/reference/corporate.rs`
- **related_event_id**: Identifier found in `src/reference/corporate.rs`
- **removed**: Identifier found in `src/reference/corporate.rs`
- **request**: Identifier found in `src/reference/corporate.rs`
- **requests**: Identifier found in `src/reference/corporate.rs`
- **requirement**: Identifier found in `src/reference/corporate.rs`
- **reqwest**: Identifier found in `src/reference/corporate.rs`
- **reqwestform**: Identifier found in `src/reference/corporate.rs`
- **res**: Identifier found in `src/reference/corporate.rs`
- **resp**: Identifier found in `src/reference/corporate.rs`
- **respond_with**: Identifier found in `src/reference/corporate.rs`
- **response**: Identifier found in `src/reference/corporate.rs`
- **responsetemplate**: Identifier found in `src/reference/corporate.rs`
- **result**: Identifier found in `src/reference/corporate.rs`
- **resultant**: Identifier found in `src/reference/corporate.rs`
- **retract**: Identifier found in `src/reference/corporate.rs`
- **retracting**: Identifier found in `src/reference/corporate.rs`
- **returns**: Identifier found in `src/reference/corporate.rs`
- **reviews**: Identifier found in `src/reference/corporate.rs`
- **rights**: Identifier found in `src/reference/corporate.rs`
- **rows**: Identifier found in `src/reference/corporate.rs`
- **rsplt**: Identifier found in `src/reference/corporate.rs`
- **rule**: Identifier found in `src/reference/corporate.rs`

### S

- **same**: Identifier found in `src/reference/corporate.rs`
- **scheduled**: Identifier found in `src/reference/corporate.rs`
- **securities**: Identifier found in `src/reference/corporate.rs`
- **security**: Identifier found in `src/reference/corporate.rs`
- **security_description**: Identifier found in `src/reference/corporate.rs`
- **security_id**: Identifier found in `src/reference/corporate.rs`
- **security_type**: Identifier found in `src/reference/corporate.rs`
- **security_types**: Identifier found in `src/reference/corporate.rs`
- **securitytype**: Identifier found in `src/reference/corporate.rs`
- **segment**: Identifier found in `src/reference/corporate.rs`
- **segment_mic**: Identifier found in `src/reference/corporate.rs`
- **segment_mic_name**: Identifier found in `src/reference/corporate.rs`
- **self**: Identifier found in `src/reference/corporate.rs`
- **send**: Identifier found in `src/reference/corporate.rs`
- **sequence**: Identifier found in `src/reference/corporate.rs`
- **serde**: Identifier found in `src/reference/corporate.rs`
- **serial**: Identifier found in `src/reference/corporate.rs`
- **serial_id**: Identifier found in `src/reference/corporate.rs`
- **serials**: Identifier found in `src/reference/corporate.rs`
- **series**: Identifier found in `src/reference/corporate.rs`
- **set_body_bytes**: Identifier found in `src/reference/corporate.rs`
- **setter**: Identifier found in `src/reference/corporate.rs`
- **settlement**: Identifier found in `src/reference/corporate.rs`
- **several**: Identifier found in `src/reference/corporate.rs`
- **share**: Identifier found in `src/reference/corporate.rs`
- **shareholder**: Identifier found in `src/reference/corporate.rs`
- **shareholders**: Identifier found in `src/reference/corporate.rs`
- **shares**: Identifier found in `src/reference/corporate.rs`
- **shoch**: Identifier found in `src/reference/corporate.rs`
- **show**: Identifier found in `src/reference/corporate.rs`
- **signifying**: Identifier found in `src/reference/corporate.rs`
- **size**: Identifier found in `src/reference/corporate.rs`
- **some**: Identifier found in `src/reference/corporate.rs`
- **sort_by_key**: Identifier found in `src/reference/corporate.rs`
- **sorting**: Identifier found in `src/reference/corporate.rs`
- **specific**: Identifier found in `src/reference/corporate.rs`
- **stakeholders**: Identifier found in `src/reference/corporate.rs`
- **start**: Identifier found in `src/reference/corporate.rs`
- **start_date**: Identifier found in `src/reference/corporate.rs`
- **start_subscription_date**: Identifier found in `src/reference/corporate.rs`
- **status**: Identifier found in `src/reference/corporate.rs`
- **statuscode**: Identifier found in `src/reference/corporate.rs`
- **std**: Identifier found in `src/reference/corporate.rs`
- **step**: Identifier found in `src/reference/corporate.rs`
- **stock**: Identifier found in `src/reference/corporate.rs`
- **string**: Identifier found in `src/reference/corporate.rs`
- **struct**: Identifier found in `src/reference/corporate.rs`
- **style**: Identifier found in `src/reference/corporate.rs`
- **stype**: Identifier found in `src/reference/corporate.rs`
- **stype_in**: Identifier found in `src/reference/corporate.rs`
- **sub**: Identifier found in `src/reference/corporate.rs`
- **subscription**: Identifier found in `src/reference/corporate.rs`
- **subtype**: Identifier found in `src/reference/corporate.rs`
- **suffix**: Identifier found in `src/reference/corporate.rs`
- **super**: Identifier found in `src/reference/corporate.rs`
- **supplied**: Identifier found in `src/reference/corporate.rs`
- **symbol**: Identifier found in `src/reference/corporate.rs`
- **symbology**: Identifier found in `src/reference/corporate.rs`
- **symbols**: Identifier found in `src/reference/corporate.rs`
- **system**: Identifier found in `src/reference/corporate.rs`

### T

- **take**: Identifier found in `src/reference/corporate.rs`
- **taking**: Identifier found in `src/reference/corporate.rs`
- **technologies**: Identifier found in `src/reference/corporate.rs`
- **tender**: Identifier found in `src/reference/corporate.rs`
- **tender_price_step**: Identifier found in `src/reference/corporate.rs`
- **tender_strike_price**: Identifier found in `src/reference/corporate.rs`
- **tendering**: Identifier found in `src/reference/corporate.rs`
- **test**: Identifier found in `src/reference/corporate.rs`
- **test_get_range**: Identifier found in `src/reference/corporate.rs`
- **test_infra**: Identifier found in `src/reference/corporate.rs`
- **tests**: Identifier found in `src/reference/corporate.rs`
- **than**: Identifier found in `src/reference/corporate.rs`
- **that**: Identifier found in `src/reference/corporate.rs`
- **their**: Identifier found in `src/reference/corporate.rs`
- **them**: Identifier found in `src/reference/corporate.rs`
- **then**: Identifier found in `src/reference/corporate.rs`
- **there**: Identifier found in `src/reference/corporate.rs`
- **they**: Identifier found in `src/reference/corporate.rs`
- **this**: Identifier found in `src/reference/corporate.rs`
- **ticker**: Identifier found in `src/reference/corporate.rs`
- **time**: Identifier found in `src/reference/corporate.rs`
- **timestamp**: Identifier found in `src/reference/corporate.rs`
- **to_api_string**: Identifier found in `src/reference/corporate.rs`
- **to_date**: Identifier found in `src/reference/corporate.rs`
- **to_date_time**: Identifier found in `src/reference/corporate.rs`
- **to_string**: Identifier found in `src/reference/corporate.rs`
- **together**: Identifier found in `src/reference/corporate.rs`
- **tokio**: Identifier found in `src/reference/corporate.rs`
- **total**: Identifier found in `src/reference/corporate.rs`
- **tracing_subscriber**: Identifier found in `src/reference/corporate.rs`
- **traded**: Identifier found in `src/reference/corporate.rs`
- **trading**: Identifier found in `src/reference/corporate.rs`
- **trading_currency**: Identifier found in `src/reference/corporate.rs`
- **transaction**: Identifier found in `src/reference/corporate.rs`
- **transform**: Identifier found in `src/reference/corporate.rs`
- **true**: Identifier found in `src/reference/corporate.rs`
- **try_init**: Identifier found in `src/reference/corporate.rs`
- **ts_created**: Identifier found in `src/reference/corporate.rs`
- **ts_record**: Identifier found in `src/reference/corporate.rs`
- **tsrecord**: Identifier found in `src/reference/corporate.rs`
- **type**: Identifier found in `src/reference/corporate.rs`
- **typed_builder**: Identifier found in `src/reference/corporate.rs`
- **typedbuilder**: Identifier found in `src/reference/corporate.rs`
- **types**: Identifier found in `src/reference/corporate.rs`

### U

- **u32**: Identifier found in `src/reference/corporate.rs`
- **u64**: Identifier found in `src/reference/corporate.rs`
- **unique**: Identifier found in `src/reference/corporate.rs`
- **unix_timestamp_nanos**: Identifier found in `src/reference/corporate.rs`
- **unwrap**: Identifier found in `src/reference/corporate.rs`
- **updated**: Identifier found in `src/reference/corporate.rs`
- **us_code**: Identifier found in `src/reference/corporate.rs`
- **usd**: Identifier found in `src/reference/corporate.rs`
- **used**: Identifier found in `src/reference/corporate.rs`
- **usnasd**: Identifier found in `src/reference/corporate.rs`
- **usually**: Identifier found in `src/reference/corporate.rs`
- **utc**: Identifier found in `src/reference/corporate.rs`

### V

- **valid**: Identifier found in `src/reference/corporate.rs`
- **value**: Identifier found in `src/reference/corporate.rs`
- **vec**: Identifier found in `src/reference/corporate.rs`
- **vgg1466b1452**: Identifier found in `src/reference/corporate.rs`
- **via**: Identifier found in `src/reference/corporate.rs`
- **voluntary**: Identifier found in `src/reference/corporate.rs`

### W

- **when**: Identifier found in `src/reference/corporate.rs`
- **where**: Identifier found in `src/reference/corporate.rs`
- **which**: Identifier found in `src/reference/corporate.rs`
- **will**: Identifier found in `src/reference/corporate.rs`
- **wiremock**: Identifier found in `src/reference/corporate.rs`
- **with**: Identifier found in `src/reference/corporate.rs`
- **with_test_writer**: Identifier found in `src/reference/corporate.rs`
- **withdrawal**: Identifier found in `src/reference/corporate.rs`
- **withdrawal_rights_expiry_time**: Identifier found in `src/reference/corporate.rs`
- **withdrawal_rights_expiry_tz**: Identifier found in `src/reference/corporate.rs`
- **withdrawal_rights_flag**: Identifier found in `src/reference/corporate.rs`
- **withdrawal_rights_from_date**: Identifier found in `src/reference/corporate.rs`
- **withdrawal_rights_to_date**: Identifier found in `src/reference/corporate.rs`
- **within**: Identifier found in `src/reference/corporate.rs`
- **would**: Identifier found in `src/reference/corporate.rs`
- **write**: Identifier found in `src/reference/corporate.rs`

### X

- **xnas**: Identifier found in `src/reference/corporate.rs`
- **xncm**: Identifier found in `src/reference/corporate.rs`

### Y

- **year**: Identifier found in `src/reference/corporate.rs`

### Z

- **zone**: Identifier found in `src/reference/corporate.rs`
- **zstd**: Identifier found in `src/reference/corporate.rs`
