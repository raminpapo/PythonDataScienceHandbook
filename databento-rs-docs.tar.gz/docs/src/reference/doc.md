# Documentation: src/reference

## Folder Overview

**Path**: `src/reference`
**Files**: 4
**Subdirectories**: 0

## Purpose

This folder is located at `src/reference`.

## Contents Summary


### Files:
- `adjustment.rs` (9968 bytes)
- `corporate.rs` (24662 bytes)
- `enums.rs` (82449 bytes)
- `security.rs` (15649 bytes)
