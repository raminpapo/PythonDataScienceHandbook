# Keywords: historical.rs

## Extracted Keywords

Total keywords extracted: 157


### A

- **API_KEY**: Identifier found in `src/historical.rs`
- **API_VERSION**: Identifier found in `src/historical.rs`
- **AddToForm**: Identifier found in `src/historical.rs`
- **AddToQuery**: Identifier found in `src/historical.rs`
- **add_to_form**: Identifier found in `src/historical.rs`
- **add_to_query**: Identifier found in `src/historical.rs`
- **addtoform**: Identifier found in `src/historical.rs`
- **addtoquery**: Identifier found in `src/historical.rs`
- **api**: Identifier found in `src/historical.rs`
- **api________________________**: Identifier found in `src/historical.rs`
- **api_key**: Identifier found in `src/historical.rs`
- **api_version**: Identifier found in `src/historical.rs`
- **as_url**: Identifier found in `src/historical.rs`
- **assert_eq**: Identifier found in `src/historical.rs`
- **associated**: Identifier found in `src/historical.rs`
- **assume_utc**: Identifier found in `src/historical.rs`

### B

- **bad_arg**: Identifier found in `src/historical.rs`
- **base_url**: Identifier found in `src/historical.rs`
- **batch**: Identifier found in `src/historical.rs`
- **bo1**: Identifier found in `src/historical.rs`
- **borrowedformatitem**: Identifier found in `src/historical.rs`
- **boston**: Identifier found in `src/historical.rs`
- **build**: Identifier found in `src/historical.rs`
- **builder**: Identifier found in `src/historical.rs`

### C

- **cfg**: Identifier found in `src/historical.rs`
- **client**: Identifier found in `src/historical.rs`
- **clone**: Identifier found in `src/historical.rs`
- **closed**: Identifier found in `src/historical.rs`
- **com**: Identifier found in `src/historical.rs`
- **const**: Identifier found in `src/historical.rs`
- **copy**: Identifier found in `src/historical.rs`
- **crate**: Identifier found in `src/historical.rs`
- **current**: Identifier found in `src/historical.rs`

### D

- **DATE_FORMAT**: Identifier found in `src/historical.rs`
- **DateRange**: Identifier found in `src/historical.rs`
- **DateTimeRange**: Identifier found in `src/historical.rs`
- **databento**: Identifier found in `src/historical.rs`
- **date**: Identifier found in `src/historical.rs`
- **date_format**: Identifier found in `src/historical.rs`
- **date_range**: Identifier found in `src/historical.rs`
- **date_range_from_lt_day_duration**: Identifier found in `src/historical.rs`
- **daterange**: Identifier found in `src/historical.rs`
- **datetime**: Identifier found in `src/historical.rs`
- **datetimerange**: Identifier found in `src/historical.rs`
- **debug**: Identifier found in `src/historical.rs`
- **default**: Identifier found in `src/historical.rs`
- **derive**: Identifier found in `src/historical.rs`
- **deserialize**: Identifier found in `src/historical.rs`
- **deserialize_date_time**: Identifier found in `src/historical.rs`
- **deserialize_with**: Identifier found in `src/historical.rs`
- **dt_offset_to_date_range**: Identifier found in `src/historical.rs`
- **dt_range**: Identifier found in `src/historical.rs`
- **duration**: Identifier found in `src/historical.rs`

### E

- **else**: Identifier found in `src/historical.rs`
- **end**: Identifier found in `src/historical.rs`
- **end_date**: Identifier found in `src/historical.rs`
- **enum**: Identifier found in `src/historical.rs`
- **error**: Identifier found in `src/historical.rs`
- **exclusive**: Identifier found in `src/historical.rs`

### F

- **first**: Identifier found in `src/historical.rs`
- **format**: Identifier found in `src/historical.rs`
- **format_description**: Identifier found in `src/historical.rs`
- **from**: Identifier found in `src/historical.rs`
- **from_unix_timestamp_nanos**: Identifier found in `src/historical.rs`

### G

- **gateway**: Identifier found in `src/historical.rs`

### H

- **HistoricalGateway**: Identifier found in `src/historical.rs`
- **half**: Identifier found in `src/historical.rs`
- **hist**: Identifier found in `src/historical.rs`
- **historical**: Identifier found in `src/historical.rs`
- **historicalclient**: Identifier found in `src/historical.rs`
- **historicalgateway**: Identifier found in `src/historical.rs`
- **https**: Identifier found in `src/historical.rs`

### I

- **i128**: Identifier found in `src/historical.rs`
- **impl**: Identifier found in `src/historical.rs`
- **inclusive**: Identifier found in `src/historical.rs`
- **interval**: Identifier found in `src/historical.rs`

### K

- **key**: Identifier found in `src/historical.rs`

### L

- **Limit**: Identifier found in `src/historical.rs`
- **limit**: Identifier found in `src/historical.rs`

### M

- **macros**: Identifier found in `src/historical.rs`
- **map_err**: Identifier found in `src/historical.rs`
- **match**: Identifier found in `src/historical.rs`
- **metadata**: Identifier found in `src/historical.rs`
- **midnight**: Identifier found in `src/historical.rs`
- **mock_server**: Identifier found in `src/historical.rs`
- **mockserver**: Identifier found in `src/historical.rs`
- **mod**: Identifier found in `src/historical.rs`
- **month**: Identifier found in `src/historical.rs`
- **mut**: Identifier found in `src/historical.rs`

### N

- **nanos**: Identifier found in `src/historical.rs`
- **nearest**: Identifier found in `src/historical.rs`
- **next_day**: Identifier found in `src/historical.rs`
- **nonzerou64**: Identifier found in `src/historical.rs`
- **num**: Identifier found in `src/historical.rs`

### O

- **offsetdatetime**: Identifier found in `src/historical.rs`
- **option**: Identifier found in `src/historical.rs`

### P

- **param**: Identifier found in `src/historical.rs`
- **parse**: Identifier found in `src/historical.rs`
- **partialeq**: Identifier found in `src/historical.rs`
- **pub**: Identifier found in `src/historical.rs`
- **push**: Identifier found in `src/historical.rs`

### Q

- **query**: Identifier found in `src/historical.rs`

### R

- **range_equivalency**: Identifier found in `src/historical.rs`
- **related**: Identifier found in `src/historical.rs`
- **requestbuilder**: Identifier found in `src/historical.rs`
- **reqwest**: Identifier found in `src/historical.rs`
- **reqwestform**: Identifier found in `src/historical.rs`
- **result**: Identifier found in `src/historical.rs`
- **returns**: Identifier found in `src/historical.rs`
- **round**: Identifier found in `src/historical.rs`

### S

- **Some**: Identifier found in `src/historical.rs`
- **second**: Identifier found in `src/historical.rs`
- **self**: Identifier found in `src/historical.rs`
- **serde**: Identifier found in `src/historical.rs`
- **single_date_conversion**: Identifier found in `src/historical.rs`
- **some**: Identifier found in `src/historical.rs`
- **start**: Identifier found in `src/historical.rs`
- **start_date**: Identifier found in `src/historical.rs`
- **static**: Identifier found in `src/historical.rs`
- **std**: Identifier found in `src/historical.rs`
- **str**: Identifier found in `src/historical.rs`
- **string**: Identifier found in `src/historical.rs`
- **struct**: Identifier found in `src/historical.rs`
- **super**: Identifier found in `src/historical.rs`
- **symbology**: Identifier found in `src/historical.rs`
- **symbols**: Identifier found in `src/historical.rs`

### T

- **target**: Identifier found in `src/historical.rs`
- **test**: Identifier found in `src/historical.rs`
- **test_infra**: Identifier found in `src/historical.rs`
- **tests**: Identifier found in `src/historical.rs`
- **time**: Identifier found in `src/historical.rs`
- **timeseries**: Identifier found in `src/historical.rs`
- **to_api_string**: Identifier found in `src/historical.rs`
- **to_offset**: Identifier found in `src/historical.rs`
- **to_string**: Identifier found in `src/historical.rs`
- **trait**: Identifier found in `src/historical.rs`
- **try_from**: Identifier found in `src/historical.rs`
- **tryfrom**: Identifier found in `src/historical.rs`
- **type**: Identifier found in `src/historical.rs`
- **types**: Identifier found in `src/historical.rs`

### U

- **u32**: Identifier found in `src/historical.rs`
- **u64**: Identifier found in `src/historical.rs`
- **unix**: Identifier found in `src/historical.rs`
- **unix_timestamp_nanos**: Identifier found in `src/historical.rs`
- **unwrap**: Identifier found in `src/historical.rs`
- **uri**: Identifier found in `src/historical.rs`
- **url**: Identifier found in `src/historical.rs`
- **utc**: Identifier found in `src/historical.rs`
- **utc_end**: Identifier found in `src/historical.rs`
- **utcoffset**: Identifier found in `src/historical.rs`

### V

- **value**: Identifier found in `src/historical.rs`
- **vec**: Identifier found in `src/historical.rs`
- **version**: Identifier found in `src/historical.rs`

### W

- **wiremock**: Identifier found in `src/historical.rs`
- **with**: Identifier found in `src/historical.rs`
- **with_time**: Identifier found in `src/historical.rs`

### Y

- **year**: Identifier found in `src/historical.rs`
