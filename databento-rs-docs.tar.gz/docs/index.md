# Repository Documentation Index

Welcome to the comprehensive documentation for this repository.

## Quick Links

- [Global Keyword Index](./keywords.md)
- [Comprehensive Book](./comprehensive_book.md)
- [Verification Report](./verification_report.md)

## Folder Structure

- [.github/](./.github/index.md)
  - [workflows/](./.github/workflows/index.md)
  - [ISSUE_TEMPLATE/](./.github/ISSUE_TEMPLATE/index.md)
- [tests/](./tests/index.md)
  - [data/](./tests/data/index.md)
- [scripts/](./scripts/index.md)
- [docs/](./docs/index.md)
  - [.github/](./docs/.github/index.md)
    - [workflows/](./docs/.github/workflows/index.md)
    - [ISSUE_TEMPLATE/](./docs/.github/ISSUE_TEMPLATE/index.md)
  - [tests/](./docs/tests/index.md)
    - [data/](./docs/tests/data/index.md)
  - [scripts/](./docs/scripts/index.md)
  - [examples/](./docs/examples/index.md)
  - [src/](./docs/src/index.md)
    - [historical/](./docs/src/historical/index.md)
    - [live/](./docs/src/live/index.md)
    - [reference/](./docs/src/reference/index.md)
- [examples/](./examples/index.md)
- [src/](./src/index.md)
  - [historical/](./src/historical/index.md)
  - [live/](./src/live/index.md)
  - [reference/](./src/reference/index.md)
