# Documentation: scripts

## Folder Overview

**Path**: `scripts`
**Files**: 5
**Subdirectories**: 0

## Purpose

This folder is located at `scripts`.

## Contents Summary


### Files:
- `build.sh` (274 bytes)
- `format.sh` (91 bytes)
- `get_version.sh` (194 bytes)
- `lint.sh` (304 bytes)
- `test.sh` (71 bytes)
