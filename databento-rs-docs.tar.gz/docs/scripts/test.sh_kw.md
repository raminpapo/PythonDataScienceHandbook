# Keywords: test.sh

## Extracted Keywords

Total keywords extracted: 9


### B

- **bash**: Identifier found in `scripts/test.sh`
- **bin**: Identifier found in `scripts/test.sh`

### C

- **cargo**: Identifier found in `scripts/test.sh`

### E

- **env**: Identifier found in `scripts/test.sh`

### F

- **features**: Identifier found in `scripts/test.sh`

### S

- **set**: Identifier found in `scripts/test.sh`

### T

- **test**: Identifier found in `scripts/test.sh`

### U

- **usr**: Identifier found in `scripts/test.sh`

### V

- **version**: Identifier found in `scripts/test.sh`
