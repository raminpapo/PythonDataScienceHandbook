# Index: scripts

## Contents


### Files

- [build.sh](./build.sh_docs.md)
- [format.sh](./format.sh_docs.md)
- [get_version.sh](./get_version.sh_docs.md)
- [lint.sh](./lint.sh_docs.md)
- [test.sh](./test.sh_docs.md)
