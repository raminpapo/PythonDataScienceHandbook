# Keywords: get_version.sh

## Extracted Keywords

Total keywords extracted: 14


### B

- **bash**: Identifier found in `scripts/get_version.sh`
- **bin**: Identifier found in `scripts/get_version.sh`

### C

- **cargo**: Identifier found in `scripts/get_version.sh`
- **cut**: Identifier found in `scripts/get_version.sh`

### D

- **dirname**: Identifier found in `scripts/get_version.sh`

### E

- **env**: Identifier found in `scripts/get_version.sh`
- **exit**: Identifier found in `scripts/get_version.sh`

### G

- **grep**: Identifier found in `scripts/get_version.sh`

### P

- **project_root_dir**: Identifier found in `scripts/get_version.sh`
- **pwd**: Identifier found in `scripts/get_version.sh`

### S

- **scripts_dir**: Identifier found in `scripts/get_version.sh`

### T

- **toml**: Identifier found in `scripts/get_version.sh`

### U

- **usr**: Identifier found in `scripts/get_version.sh`

### V

- **version**: Identifier found in `scripts/get_version.sh`
