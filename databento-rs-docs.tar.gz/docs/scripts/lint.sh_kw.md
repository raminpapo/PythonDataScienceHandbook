# Keywords: lint.sh

## Extracted Keywords

Total keywords extracted: 26


### B

- **bash**: Identifier found in `scripts/lint.sh`
- **bin**: Identifier found in `scripts/lint.sh`

### C

- **cargo**: Identifier found in `scripts/lint.sh`
- **clippy**: Identifier found in `scripts/lint.sh`
- **com**: Identifier found in `scripts/lint.sh`

### D

- **deny**: Identifier found in `scripts/lint.sh`
- **doc**: Identifier found in `scripts/lint.sh`
- **does**: Identifier found in `scripts/lint.sh`

### E

- **env**: Identifier found in `scripts/lint.sh`

### F

- **features**: Identifier found in `scripts/lint.sh`
- **flag**: Identifier found in `scripts/lint.sh`
- **from**: Identifier found in `scripts/lint.sh`

### G

- **github**: Identifier found in `scripts/lint.sh`

### H

- **have**: Identifier found in `scripts/lint.sh`
- **https**: Identifier found in `scripts/lint.sh`

### I

- **issuecomment**: Identifier found in `scripts/lint.sh`
- **issues**: Identifier found in `scripts/lint.sh`

### L

- **lang**: Identifier found in `scripts/lint.sh`
- **like**: Identifier found in `scripts/lint.sh`

### R

- **rust**: Identifier found in `scripts/lint.sh`
- **rustdocflags**: Identifier found in `scripts/lint.sh`

### S

- **set**: Identifier found in `scripts/lint.sh`

### U

- **usr**: Identifier found in `scripts/lint.sh`

### V

- **version**: Identifier found in `scripts/lint.sh`

### W

- **warnings**: Identifier found in `scripts/lint.sh`
- **workaround**: Identifier found in `scripts/lint.sh`
