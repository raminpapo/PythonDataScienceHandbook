# Keywords: format.sh

## Extracted Keywords

Total keywords extracted: 11


### A

- **anything**: Identifier found in `scripts/format.sh`

### B

- **bash**: Identifier found in `scripts/format.sh`
- **bin**: Identifier found in `scripts/format.sh`

### C

- **cargo**: Identifier found in `scripts/format.sh`
- **check**: Identifier found in `scripts/format.sh`

### E

- **env**: Identifier found in `scripts/format.sh`

### F

- **fails**: Identifier found in `scripts/format.sh`
- **fmt**: Identifier found in `scripts/format.sh`

### M

- **misformatted**: Identifier found in `scripts/format.sh`

### U

- **usr**: Identifier found in `scripts/format.sh`

### V

- **version**: Identifier found in `scripts/format.sh`
