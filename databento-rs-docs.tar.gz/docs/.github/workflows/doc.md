# Documentation: .github/workflows

## Folder Overview

**Path**: `.github/workflows`
**Files**: 2
**Subdirectories**: 0

## Purpose

This folder is located at `.github/workflows`.

## Contents Summary


### Files:
- `build.yaml` (960 bytes)
- `release.yaml` (2068 bytes)
