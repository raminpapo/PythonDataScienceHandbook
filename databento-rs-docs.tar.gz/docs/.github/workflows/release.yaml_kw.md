# Keywords: release.yaml

## Extracted Keywords

Total keywords extracted: 89


### A

- **action**: Identifier found in `.github/workflows/release.yaml`
- **actions**: Identifier found in `.github/workflows/release.yaml`
- **add**: Identifier found in `.github/workflows/release.yaml`
- **append_body**: Identifier found in `.github/workflows/release.yaml`

### B

- **body_path**: Identifier found in `.github/workflows/release.yaml`
- **branches**: Identifier found in `.github/workflows/release.yaml`
- **build**: Identifier found in `.github/workflows/release.yaml`

### C

- **cache**: Identifier found in `.github/workflows/release.yaml`
- **cargo**: Identifier found in `.github/workflows/release.yaml`
- **cargo_registry_token**: Identifier found in `.github/workflows/release.yaml`
- **changelog**: Identifier found in `.github/workflows/release.yaml`
- **checkout**: Identifier found in `.github/workflows/release.yaml`
- **clippy**: Identifier found in `.github/workflows/release.yaml`
- **command**: Identifier found in `.github/workflows/release.yaml`
- **commit**: Identifier found in `.github/workflows/release.yaml`
- **completed**: Identifier found in `.github/workflows/release.yaml`
- **component**: Identifier found in `.github/workflows/release.yaml`
- **conclusion**: Identifier found in `.github/workflows/release.yaml`
- **crates**: Identifier found in `.github/workflows/release.yaml`
- **create**: Identifier found in `.github/workflows/release.yaml`

### D

- **depth**: Identifier found in `.github/workflows/release.yaml`
- **detect**: Identifier found in `.github/workflows/release.yaml`
- **doesn**: Identifier found in `.github/workflows/release.yaml`

### E

- **echo**: Identifier found in `.github/workflows/release.yaml`
- **env**: Identifier found in `.github/workflows/release.yaml`
- **error**: Identifier found in `.github/workflows/release.yaml`
- **event**: Identifier found in `.github/workflows/release.yaml`
- **exist**: Identifier found in `.github/workflows/release.yaml`

### F

- **false**: Identifier found in `.github/workflows/release.yaml`
- **fetch**: Identifier found in `.github/workflows/release.yaml`
- **force**: Identifier found in `.github/workflows/release.yaml`

### G

- **get_version**: Identifier found in `.github/workflows/release.yaml`
- **git**: Identifier found in `.github/workflows/release.yaml`
- **github**: Identifier found in `.github/workflows/release.yaml`
- **github_env**: Identifier found in `.github/workflows/release.yaml`

### H

- **hashfiles**: Identifier found in `.github/workflows/release.yaml`

### J

- **jobs**: Identifier found in `.github/workflows/release.yaml`

### K

- **key**: Identifier found in `.github/workflows/release.yaml`

### L

- **latest**: Identifier found in `.github/workflows/release.yaml`
- **library**: Identifier found in `.github/workflows/release.yaml`
- **lock**: Identifier found in `.github/workflows/release.yaml`

### M

- **main**: Identifier found in `.github/workflows/release.yaml`
- **minimal**: Identifier found in `.github/workflows/release.yaml`

### N

- **name**: Identifier found in `.github/workflows/release.yaml`
- **notes**: Identifier found in `.github/workflows/release.yaml`

### O

- **output**: Identifier found in `.github/workflows/release.yaml`
- **outputs**: Identifier found in `.github/workflows/release.yaml`

### P

- **path**: Identifier found in `.github/workflows/release.yaml`
- **prerelease**: Identifier found in `.github/workflows/release.yaml`
- **profile**: Identifier found in `.github/workflows/release.yaml`
- **publish**: Identifier found in `.github/workflows/release.yaml`

### R

- **registry**: Identifier found in `.github/workflows/release.yaml`
- **release**: Identifier found in `.github/workflows/release.yaml`
- **release_name**: Identifier found in `.github/workflows/release.yaml`
- **remove**: Identifier found in `.github/workflows/release.yaml`
- **repository**: Identifier found in `.github/workflows/release.yaml`
- **run**: Identifier found in `.github/workflows/release.yaml`
- **runner**: Identifier found in `.github/workflows/release.yaml`
- **runs**: Identifier found in `.github/workflows/release.yaml`
- **rust**: Identifier found in `.github/workflows/release.yaml`
- **rustfmt**: Identifier found in `.github/workflows/release.yaml`
- **rustup**: Identifier found in `.github/workflows/release.yaml`

### S

- **salsify**: Identifier found in `.github/workflows/release.yaml`
- **scripts**: Identifier found in `.github/workflows/release.yaml`
- **secrets**: Identifier found in `.github/workflows/release.yaml`
- **sed**: Identifier found in `.github/workflows/release.yaml`
- **set**: Identifier found in `.github/workflows/release.yaml`
- **setup**: Identifier found in `.github/workflows/release.yaml`
- **softprops**: Identifier found in `.github/workflows/release.yaml`
- **stable**: Identifier found in `.github/workflows/release.yaml`
- **steps**: Identifier found in `.github/workflows/release.yaml`
- **success**: Identifier found in `.github/workflows/release.yaml`

### T

- **tag**: Identifier found in `.github/workflows/release.yaml`
- **tag_name**: Identifier found in `.github/workflows/release.yaml`
- **target**: Identifier found in `.github/workflows/release.yaml`
- **token**: Identifier found in `.github/workflows/release.yaml`
- **toolchain**: Identifier found in `.github/workflows/release.yaml`
- **true**: Identifier found in `.github/workflows/release.yaml`
- **types**: Identifier found in `.github/workflows/release.yaml`

### U

- **ubuntu**: Identifier found in `.github/workflows/release.yaml`
- **upload_url**: Identifier found in `.github/workflows/release.yaml`
- **uses**: Identifier found in `.github/workflows/release.yaml`

### V

- **variables**: Identifier found in `.github/workflows/release.yaml`
- **vars**: Identifier found in `.github/workflows/release.yaml`
- **version**: Identifier found in `.github/workflows/release.yaml`

### W

- **with**: Identifier found in `.github/workflows/release.yaml`
- **workflow_dispatch**: Identifier found in `.github/workflows/release.yaml`
- **workflow_run**: Identifier found in `.github/workflows/release.yaml`
- **workflows**: Identifier found in `.github/workflows/release.yaml`
