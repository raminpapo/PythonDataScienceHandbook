# Index: .github/ISSUE_TEMPLATE

## Contents


### Files

- [bug_report.md](./bug_report.md_docs.md)
- [config.yml](./config.yml_docs.md)
- [feature_request.md](./feature_request.md_docs.md)
