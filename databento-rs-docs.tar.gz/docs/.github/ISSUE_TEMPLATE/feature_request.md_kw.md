# Keywords: feature_request.md

## Extracted Keywords

Total keywords extracted: 17


### A

- **about**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
- **added**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### D

- **description**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
- **detailed**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### E

- **enhancement**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
- **examples**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### F

- **feature**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### H

- **here**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### L

- **labels**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### N

- **name**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### P

- **please**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
- **proposal**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
- **provide**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### R

- **request**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### S

- **some**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### W

- **with**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`

### Y

- **your**: Identifier found in `.github/ISSUE_TEMPLATE/feature_request.md`
