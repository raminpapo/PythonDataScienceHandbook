# Documentation: .github/ISSUE_TEMPLATE

## Folder Overview

**Path**: `.github/ISSUE_TEMPLATE`
**Files**: 3
**Subdirectories**: 0

## Purpose

This folder is located at `.github/ISSUE_TEMPLATE`.

## Contents Summary


### Files:
- `bug_report.md` (269 bytes)
- `config.yml` (196 bytes)
- `feature_request.md` (196 bytes)
