# Documentation: .github

## Folder Overview

**Path**: `.github`
**Files**: 1
**Subdirectories**: 2

## Purpose

This folder is located at `.github`.

## Contents Summary

### Subdirectories:
- `ISSUE_TEMPLATE/`
- `workflows/`

### Files:
- `pull_request_template.md` (1341 bytes)
