# Keywords: pull_request_template.md

## Extracted Keywords

Total keywords extracted: 85


### A

- **added**: Identifier found in `.github/pull_request_template.md`
- **adds**: Identifier found in `.github/pull_request_template.md`
- **also**: Identifier found in `.github/pull_request_template.md`
- **any**: Identifier found in `.github/pull_request_template.md`
- **apache**: Identifier found in `.github/pull_request_template.md`
- **authority**: Identifier found in `.github/pull_request_template.md`

### B

- **been**: Identifier found in `.github/pull_request_template.md`
- **behalf**: Identifier found in `.github/pull_request_template.md`
- **breaking**: Identifier found in `.github/pull_request_template.md`
- **bug**: Identifier found in `.github/pull_request_template.md`
- **build**: Identifier found in `.github/pull_request_template.md`
- **builds**: Identifier found in `.github/pull_request_template.md`

### C

- **cause**: Identifier found in `.github/pull_request_template.md`
- **change**: Identifier found in `.github/pull_request_template.md`
- **changes**: Identifier found in `.github/pull_request_template.md`
- **checklist**: Identifier found in `.github/pull_request_template.md`
- **code**: Identifier found in `.github/pull_request_template.md`
- **configuration**: Identifier found in `.github/pull_request_template.md`
- **confirm**: Identifier found in `.github/pull_request_template.md`
- **context**: Identifier found in `.github/pull_request_template.md`
- **contribution**: Identifier found in `.github/pull_request_template.md`
- **copyright**: Identifier found in `.github/pull_request_template.md`
- **corresponding**: Identifier found in `.github/pull_request_template.md`

### D

- **declaration**: Identifier found in `.github/pull_request_template.md`
- **delete**: Identifier found in `.github/pull_request_template.md`
- **dependencies**: Identifier found in `.github/pull_request_template.md`
- **describe**: Identifier found in `.github/pull_request_template.md`
- **details**: Identifier found in `.github/pull_request_template.md`
- **documentation**: Identifier found in `.github/pull_request_template.md`

### E

- **effective**: Identifier found in `.github/pull_request_template.md`
- **existing**: Identifier found in `.github/pull_request_template.md`
- **expected**: Identifier found in `.github/pull_request_template.md`

### F

- **feature**: Identifier found in `.github/pull_request_template.md`
- **fix**: Identifier found in `.github/pull_request_template.md`
- **fixes**: Identifier found in `.github/pull_request_template.md`
- **follows**: Identifier found in `.github/pull_request_template.md`
- **format**: Identifier found in `.github/pull_request_template.md`
- **functionality**: Identifier found in `.github/pull_request_template.md`

### G

- **guidelines**: Identifier found in `.github/pull_request_template.md`

### H

- **have**: Identifier found in `.github/pull_request_template.md`

### I

- **include**: Identifier found in `.github/pull_request_template.md`
- **instructions**: Identifier found in `.github/pull_request_template.md`
- **issue**: Identifier found in `.github/pull_request_template.md`

### L

- **license**: Identifier found in `.github/pull_request_template.md`
- **lint**: Identifier found in `.github/pull_request_template.md`
- **list**: Identifier found in `.github/pull_request_template.md`
- **locally**: Identifier found in `.github/pull_request_template.md`

### M

- **made**: Identifier found in `.github/pull_request_template.md`
- **make**: Identifier found in `.github/pull_request_template.md`
- **motivation**: Identifier found in `.github/pull_request_template.md`

### N

- **necessary**: Identifier found in `.github/pull_request_template.md`
- **non**: Identifier found in `.github/pull_request_template.md`

### O

- **options**: Identifier found in `.github/pull_request_template.md`
- **owner**: Identifier found in `.github/pull_request_template.md`

### P

- **pass**: Identifier found in `.github/pull_request_template.md`
- **please**: Identifier found in `.github/pull_request_template.md`
- **prove**: Identifier found in `.github/pull_request_template.md`
- **provide**: Identifier found in `.github/pull_request_template.md`
- **pull**: Identifier found in `.github/pull_request_template.md`

### R

- **ran**: Identifier found in `.github/pull_request_template.md`
- **relevant**: Identifier found in `.github/pull_request_template.md`
- **reproduce**: Identifier found in `.github/pull_request_template.md`
- **request**: Identifier found in `.github/pull_request_template.md`
- **required**: Identifier found in `.github/pull_request_template.md`
- **requires**: Identifier found in `.github/pull_request_template.md`

### S

- **scripts**: Identifier found in `.github/pull_request_template.md`
- **style**: Identifier found in `.github/pull_request_template.md`
- **summary**: Identifier found in `.github/pull_request_template.md`

### T

- **test**: Identifier found in `.github/pull_request_template.md`
- **tested**: Identifier found in `.github/pull_request_template.md`
- **tests**: Identifier found in `.github/pull_request_template.md`
- **that**: Identifier found in `.github/pull_request_template.md`
- **this**: Identifier found in `.github/pull_request_template.md`
- **type**: Identifier found in `.github/pull_request_template.md`

### U

- **under**: Identifier found in `.github/pull_request_template.md`
- **unit**: Identifier found in `.github/pull_request_template.md`
- **update**: Identifier found in `.github/pull_request_template.md`

### V

- **verify**: Identifier found in `.github/pull_request_template.md`

### W

- **warnings**: Identifier found in `.github/pull_request_template.md`
- **which**: Identifier found in `.github/pull_request_template.md`
- **with**: Identifier found in `.github/pull_request_template.md`
- **work**: Identifier found in `.github/pull_request_template.md`
- **works**: Identifier found in `.github/pull_request_template.md`
- **would**: Identifier found in `.github/pull_request_template.md`

### Y

- **your**: Identifier found in `.github/pull_request_template.md`
