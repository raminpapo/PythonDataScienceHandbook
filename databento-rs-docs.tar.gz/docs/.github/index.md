# Index: .github

## Contents

### Subdirectories

- [ISSUE_TEMPLATE/](./ISSUE_TEMPLATE/index.md)
- [workflows/](./workflows/index.md)

### Files

- [pull_request_template.md](./pull_request_template.md_docs.md)
