# Binary File: test_data.mbo.dbn

- **Path**: `tests/data/test_data.mbo.dbn`
- **Size**: 318 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
