# Documentation: tests/data

## Folder Overview

**Path**: `tests/data`
**Files**: 24
**Subdirectories**: 0

## Purpose

This folder is located at `tests/data`.

## Contents Summary


### Files:
- `test_data.definition.dbn` (2756 bytes)
- `test_data.definition.dbn.zst` (673 bytes)
- `test_data.imbalance.dbn` (2320 bytes)
- `test_data.imbalance.dbn.zst` (637 bytes)
- `test_data.mbo.dbn` (318 bytes)
- `test_data.mbo.dbn.zst` (172 bytes)
- `test_data.mbp-1.dbn` (366 bytes)
- `test_data.mbp-1.dbn.zst` (190 bytes)
- `test_data.mbp-10.dbn` (942 bytes)
- `test_data.mbp-10.dbn.zst` (372 bytes)
- `test_data.ohlcv-1d.dbn` (206 bytes)
- `test_data.ohlcv-1d.dbn.zst` (99 bytes)
- `test_data.ohlcv-1h.dbn` (318 bytes)
- `test_data.ohlcv-1h.dbn.zst` (184 bytes)
- `test_data.ohlcv-1m.dbn` (318 bytes)
- `test_data.ohlcv-1m.dbn.zst` (162 bytes)
- `test_data.ohlcv-1s.dbn` (318 bytes)
- `test_data.ohlcv-1s.dbn.zst` (155 bytes)
- `test_data.statistics.dbn` (256 bytes)
- `test_data.statistics.dbn.zst` (140 bytes)
- `test_data.tbbo.dbn` (366 bytes)
- `test_data.tbbo.dbn.zst` (197 bytes)
- `test_data.trades.dbn` (302 bytes)
- `test_data.trades.dbn.zst` (171 bytes)
