# Binary File: test_data.trades.dbn

- **Path**: `tests/data/test_data.trades.dbn`
- **Size**: 302 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
