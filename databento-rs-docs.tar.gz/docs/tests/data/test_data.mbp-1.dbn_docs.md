# Binary File: test_data.mbp-1.dbn

- **Path**: `tests/data/test_data.mbp-1.dbn`
- **Size**: 366 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
