# Binary File: test_data.mbp-10.dbn

- **Path**: `tests/data/test_data.mbp-10.dbn`
- **Size**: 942 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
