# Binary File: test_data.imbalance.dbn

- **Path**: `tests/data/test_data.imbalance.dbn`
- **Size**: 2320 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
