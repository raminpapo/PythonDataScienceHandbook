# Binary File: test_data.statistics.dbn

- **Path**: `tests/data/test_data.statistics.dbn`
- **Size**: 256 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
