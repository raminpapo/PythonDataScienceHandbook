# Binary File: test_data.mbo.dbn.zst

- **Path**: `tests/data/test_data.mbo.dbn.zst`
- **Size**: 172 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
