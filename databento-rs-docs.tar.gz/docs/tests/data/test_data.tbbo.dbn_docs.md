# Binary File: test_data.tbbo.dbn

- **Path**: `tests/data/test_data.tbbo.dbn`
- **Size**: 366 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
