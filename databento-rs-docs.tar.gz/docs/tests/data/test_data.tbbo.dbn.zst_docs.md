# Binary File: test_data.tbbo.dbn.zst

- **Path**: `tests/data/test_data.tbbo.dbn.zst`
- **Size**: 197 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
