# Binary File: test_data.imbalance.dbn.zst

- **Path**: `tests/data/test_data.imbalance.dbn.zst`
- **Size**: 637 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
