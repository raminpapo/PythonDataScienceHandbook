# Binary File: test_data.mbp-10.dbn.zst

- **Path**: `tests/data/test_data.mbp-10.dbn.zst`
- **Size**: 372 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
