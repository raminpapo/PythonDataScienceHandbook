# Binary File: test_data.trades.dbn.zst

- **Path**: `tests/data/test_data.trades.dbn.zst`
- **Size**: 171 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
