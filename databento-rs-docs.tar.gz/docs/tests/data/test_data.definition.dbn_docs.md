# Binary File: test_data.definition.dbn

- **Path**: `tests/data/test_data.definition.dbn`
- **Size**: 2756 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: unknown

This file is binary and cannot be documented as text.
