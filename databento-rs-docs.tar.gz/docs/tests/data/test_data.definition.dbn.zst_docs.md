# Binary File: test_data.definition.dbn.zst

- **Path**: `tests/data/test_data.definition.dbn.zst`
- **Size**: 673 bytes
- **Type**: Binary file (not readable as text)
- **MIME**: application/zstd

This file is binary and cannot be documented as text.
