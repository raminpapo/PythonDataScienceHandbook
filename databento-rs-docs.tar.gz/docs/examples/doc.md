# Documentation: examples

## Folder Overview

**Path**: `examples`
**Files**: 5
**Subdirectories**: 0

## Purpose

This folder is located at `examples`.

## Contents Summary


### Files:
- `historical.rs` (1292 bytes)
- `live.rs` (1162 bytes)
- `live_smoke_test.rs` (4444 bytes)
- `reference.rs` (1775 bytes)
- `split_symbols.rs` (3627 bytes)
